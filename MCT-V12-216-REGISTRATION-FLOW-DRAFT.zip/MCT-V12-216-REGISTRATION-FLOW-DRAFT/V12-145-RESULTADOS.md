# V12-145 — Endpoint privado de consulta (desactivado por defecto)

## Cambio real
Se añadió `functions/api/founding/status.js`, una ruta GET de solo lectura. Usa el mismo token de sesión PRO existente (cookie HttpOnly) y consulta la membresía del usuario autenticado. Devuelve únicamente fechas, número de extensiones y días restantes; **nunca datos de otra cuenta**. Requiere `FOUNDING_MEMBERS_STATUS_ENABLED=true` y la migración 0009 aplicada en un entorno de pruebas. Sin ese indicador devuelve 404; sin D1 o sin tabla devuelve error controlado. No concede membresías, no permite modificar registros ni registra usuarios.

## Seguridad y limitaciones
- No ejecutar migraciones en producción ni activar el indicador todavía.
- No está integrada la pantalla de Founding Members con esta API.
- Las extensiones y límites de proyectos aún no se aplican desde el backend.
- Reutilizar el inicio de sesión PRO requiere pruebas de extremo a extremo en entorno de pruebas y revisar la seguridad de las sesiones.
- El ZIP conserva el diseño V12-144. Las funciones Pages solo se ejecutan en Cloudflare, no al abrir HTML localmente.

## Próximo bloque
Implementar alta voluntaria y concesiones idempotentes mediante transacciones seguras, pruebas de aislamiento, permisos de administrador y límites de proyectos. Mantener producción intacta hasta la aprobación.
