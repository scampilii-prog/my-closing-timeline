# V12-205 · Validación local de arquitectura de registro

**Estado:** documentación y pruebas locales, **no** registro funcional ni despliegue Cloudflare.

## Verificado
- Esquema SQLite compatible con las restricciones básicas de D1: email normalizado único, una prueba introductoria por cuenta, cuatro preferencias de actividad.
- `plans.html` y `founding-members.html` anuncian 90 días, pero expresamente identifican el registro y pagos como no activados.
- La página de pagos es una vista previa; no debe simular un cobro.

## Riesgos que aún impiden publicar el registro
1. El índice `one_intro_trial_per_account` impide dos pruebas en **la misma cuenta**, no detecta a una persona que use dos emails.
2. Normalización del email, tokens de un solo uso, sesiones, límites de registro y Turnstile deben implementarse en Workers, validarse en servidor y probarse con concurrencia.
3. D1 no debe exponerse al navegador; las claves y el proveedor de correo aún necesitan configuración en Cloudflare.
4. Se debe aprobar la política de duración de prueba: esta versión muestra 90 días; documentación histórica contiene 21 días.
5. La retención mínima necesaria para prevenir recreación de cuentas requiere decisión de privacidad; no se debe usar IP permanente como identidad.
6. Studio y administración deben estar protegidos con autorización real en servidor antes de desplegar.

## Próxima fase técnica
Crear endpoints de registro/verificación y sesiones con tests; usar ambiente staging y credenciales de prueba. Mantener checkout deshabilitado hasta aprobar precios y configurar webhook firmado.
