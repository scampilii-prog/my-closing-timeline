V12-156: encabezado chocolate uniforme, filas alternadas crema/dorado suave y numeral integrado a su fila. Aplicado a Table 01, Table 02 y resúmenes. Sin modificar lógica de selección ni datos.
