# V12-188 — claridad comercial de planes (vista previa local)

- Los cuatro mensajes de confianza ahora tienen mayor contraste, tamaño y separación; no son botones.
- Tres formas de acceso: un proyecto (una categoría y 30/90 días), dos categorías (selección distinta, 1/3/6/12 meses) y todas las categorías (1/3/6/12 meses).
- Se explicita la diferencia entre categoría, plan y período.
- Se conservan las cuatro fotografías y se realzan visualmente los cuatro períodos.
- Los botones enlazan a payment.html con la opción elegida; payment.html muestra un resumen seguro sin cobro.
- Los precios y límites siguen sin aprobarse. No se ha activado checkout ni modificado producción.
- El resto del sitio se conserva.
