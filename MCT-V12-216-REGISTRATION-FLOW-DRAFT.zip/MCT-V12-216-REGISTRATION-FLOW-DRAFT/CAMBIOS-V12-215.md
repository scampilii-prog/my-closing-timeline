# V12-215 · Fundamentos aislados de autenticación

Se añadió `auth-draft/security.mjs`, biblioteca de referencia **sin conexión con las rutas públicas**. Contiene normalización básica de correo, generación criptográfica de tokens aleatorios, hash SHA-256, formato de cookie segura y comparación de caducidad. Prueba: `node tests/v12_auth_foundation_test.mjs`.

**No es un sistema de registro listo para producción.** Pendientes: validación de direcciones internacionales, verificación de email, CSRF, D1, transacciones, rate limiting distribuido, consentimiento, política de retención, sesiones persistentes, envío de correo y revisión de seguridad. No desplegar ni conectar a rutas sin esas protecciones.
