#!/usr/bin/env python3
"""Ejecuta pruebas de regresión V12 sin dependencias externas adicionales."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
files=sorted((root/'tests').glob('*.py'))+sorted((root/'tests').glob('*.js'))
failed=[]
for f in files:
    command=[sys.executable,str(f)] if f.suffix=='.py' else ['node',str(f)]
    p=subprocess.run(command,cwd=root,capture_output=True,text=True)
    print(('PASS' if p.returncode==0 else 'FAIL')+'  '+f.name)
    if p.returncode: failed.append(f.name);print(p.stdout[-1500:]);print(p.stderr[-1500:])
print(f"Resultado: {len(files)-len(failed)}/{len(files)} pruebas superadas")
sys.exit(bool(failed))
