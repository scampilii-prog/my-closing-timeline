V12-181: Overdue terracota y Full Table View permanece en flujo sin superposición. CSS añadido al final, sin modificar tablas ni lógica de plantillas. Requiere validación visual en Chrome.
