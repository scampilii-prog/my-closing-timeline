V12-166: encabezado lavanda claro uniforme y Select visible. Únicamente CSS de la tabla editable 02; resúmenes intactos. Revisión visual en Chrome pendiente.
