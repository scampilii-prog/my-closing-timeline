# V12-216 · Borrador aislado de registro

- Nuevo `auth-draft/registration-flow.mjs`: preparación de registro pendiente y verificación con adaptador transaccional obligatorio.
- Nueva prueba `tests/v12_registration_flow_draft_test.mjs` de normalización, token hash, caducidad, consumo único y 90 días.
- No hay endpoints públicos ni envío real de email. La simulación no prueba transacciones D1 ni concurrencia.
- No se modificaron páginas ni Functions existentes. Requiere diseño de adaptador D1, cookies/CSRF y rate limit antes de producción.
