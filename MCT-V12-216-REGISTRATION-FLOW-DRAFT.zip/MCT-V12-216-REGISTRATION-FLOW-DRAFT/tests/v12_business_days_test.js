'use strict';
const assert=require('node:assert/strict');
const fmt=(date)=>date?new Date(date+'T12:00:00'):null;
function daysBetween(base,target,counting){
 if(!base||!target)return 0;
 const a=fmt(base),b=fmt(target);
 if(!a||!b)return 0;
 const sign=b>a?1:b<a?-1:0;
 if(!sign)return 0;
 if(counting!=='business')return Math.round((b-a)/86400000);
 let days=0;
 while((sign>0&&a<b)||(sign<0&&a>b)){
  a.setDate(a.getDate()+sign);
  if(a.getDay()!==0&&a.getDay()!==6)days+=sign;
 }
 return days;
}

const cases=[
 ['2026-11-13','2026-11-16','business',1], // Fri to Mon
 ['2026-11-16','2026-11-13','business',-1], // Mon to Fri
 ['2026-11-13','2026-11-17','business',2],
 ['2026-11-13','2026-11-16','calendar',3],
 ['2026-11-13','2026-11-13','business',0],
 ['2026-11-16','2026-11-21','business',4],
 ['2026-11-16','2026-11-14','business',0],
];
for(const [a,b,mode,want] of cases)assert.equal(daysBetween(a,b,mode),want,`${a} to ${b} ${mode}`);
console.log(`PASS: ${cases.length} date conversion scenarios`);
