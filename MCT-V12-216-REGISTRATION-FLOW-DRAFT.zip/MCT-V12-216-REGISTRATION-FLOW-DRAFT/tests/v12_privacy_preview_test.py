from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=(r/'privacy.html').read_text()
assert 'not the final privacy policy' in p
assert "browser's local storage" in p
assert 'does not necessarily erase' in p
assert 'third-party personal details' in p
assert 'account registration, email verification' in p
assert 'help-contact.html' in p
print('PASS: privacy preview is transparent about local data and unlaunched services')
