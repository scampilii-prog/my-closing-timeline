const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'..','pages','real-estate.js'),'utf8');
const start=source.indexOf('/* V11-153: unified three-choice Communication Center wizard');
const end=source.indexOf('/* V11-139: custom relationship entry',start);
assert(start>0&&end>start);
const code=source.slice(start,end);
class Classes{constructor(){this.set=new Set()}add(...a){a.forEach(x=>this.set.add(x))}remove(...a){a.forEach(x=>this.set.delete(x))}contains(x){return this.set.has(x)}}
class Element{
 constructor(id){this.id=id;this.value='';this.checked=false;this.disabled=false;this.textContent='';this.classList=new Classes();this.handlers={};this.label={classList:new Classes()};}
 addEventListener(type,fn){(this.handlers[type]??=[]).push(fn)}
 dispatch(type){(this.handlers[type]||[]).forEach(h=>h({type,target:this}))}
 closest(tag){return tag==='label'?this.label:this}
 setAttribute(){}
}
const els={}; const $=id=>els[id]??(els[id]=new Element(id));
const section=$('communication');
section.querySelectorAll=(q)=>Object.values(els).flatMap(e=>[e,e.label]).filter(e=>e.classList?.contains('re-wizard-current')||e.classList?.contains('re-wizard-button'));
const listener={};const document={getElementById:$,addEventListener:(ev,fn)=>(listener[ev]??=[]).push(fn)};
const tables={contract:false,follow:false};
let complete=false;
const window={MCTCommunication:{
 ready:()=>complete&&Object.values(tables).some(Boolean),
 groups:()=>['contract','follow'].filter(k=>tables[k]).map(w=>({w,tasks:[{name:'A'}]}))
}};
const context={window,document,MutationObserver:class{observe(){}},setTimeout:(f)=>f(),confirm:()=>true};
vm.createContext(context);vm.runInContext(code,context);
for(const value of ['contract','follow','both']){
 const table=$('email-table');table.value=value;table.dispatch('change');
 assert($('contact-list').label.classList.contains('re-wizard-current'),'Saved contact must become yellow for '+value);
 assert(!$('email-table').label.classList.contains('re-wizard-current'),'Table to send must lose yellow '+value);
 assert($('email-wizard-note').textContent.includes('Choose a saved contact or enter a recipient email'));
 assert($('email-preview').disabled,'Preview should start disabled for '+value);
 assert($('email-preview-shortcut').disabled);
}
$('email-to').value='contact@example.com';$('email-to').dispatch('input');
$('email-role').value='Buyer';$('email-role').dispatch('change');
$('email-subject').value='Update';$('email-subject').dispatch('input');
$('email-message').value='Review';$('email-message').dispatch('input');
complete=true;tables.contract=true;tables.follow=true;
$('email-table').value='both';$('email-table').dispatch('change');
assert($('contact-list').label.classList.contains('re-wizard-current'),'New choice re-highlights Saved contact even with previous valid recipient');
$('email-to').dispatch('input');
assert(!$('email-preview').disabled,'Ready after complete tasks and recipient');
console.log('PASS: Table 01, Table 02, Both Tables move highlight to Saved contact; Preview locked until ready; re-choice resets highlight.');
