"""Browser round-trip without a local HTTP server; executes original inline and linked scripts."""
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
def html(name):
 soup=BeautifulSoup((root/name).read_text(),'html.parser')
 for s in soup.find_all('script',src=True):
  path=root/s['src'].split('?',1)[0]
  s.attrs.pop('src');s.string=path.read_text().replace('</script','<\\/script')
 return str(soup)
def show(page,name,query=''):
 # set_content avoids file:// and HTTP navigation, while preserving URLSearchParams
 page.goto('about:blank')
 page.evaluate('(q)=>history.replaceState(null,"","about:blank"+q)', '?'+query if query else '')
 page.set_content(html(name),wait_until='load')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 for plan,first,second,term in [('project','business',None,'90'),('two','real-estate','personal','6'),('all',None,None,'12')]:
  show(page,'plans.html')
  if plan=='project':
   page.select_option('#project-category',first);page.select_option('#project-term',term);selector='#project-link'
  elif plan=='two':
   page.select_option('#two-first',first);page.select_option('#two-second',second);page.select_option('#two-term',term);selector='#two-link'
  else:
   page.select_option('#all-term',term);selector='#all-link'
  href=page.locator(selector).get_attribute('href');assert href.startswith('payment.html?'),href
  query=urlparse(href).query
  show(page,'payment.html',query)
  assert 'Please select a valid' not in page.locator('#selected-details').inner_text()
  back=page.locator('#back-to-plans').get_attribute('href')
  assert back.startswith('plans.html?'),back
  show(page,'plans.html',urlparse(back).query)
  assert page.locator(selector).get_attribute('href')==href,(plan,href,page.locator(selector).get_attribute('href'))
  print('PASS offline Chromium roundtrip:',plan)
 show(page,'plans.html')
 page.select_option('#two-first','business');page.select_option('#two-second','business')
 assert page.locator('#two-link').get_attribute('aria-disabled')=='true'
 assert page.locator('#two-link').get_attribute('href')=='#two-error'
 print('PASS duplicate categories blocked')
 show(page,'payment.html','plan=project&category=invalid&days=90')
 assert page.locator('#back-to-plans').get_attribute('href')=='plans.html'
 print('PASS invalid payment parameters rejected')
 assert not errors,errors
 browser.close()
