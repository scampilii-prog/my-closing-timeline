import test from 'node:test';
import assert from 'node:assert/strict';
import {prepareRegistration,verifyAndActivate} from '../auth-draft/registration-flow.mjs';
const NOW=1770000000000;
function mockStore(row){
  return {async consumeAndActivateAtomically({tokenHash,now,trialDurationMs}){
    if(row.hash!==tokenHash)return 'invalid';
    if(row.used)return 'used';
    if(row.expiry<=now)return 'expired';
    if(row.status!=='pending')return 'inactive';
    if(row.trial)return 'already-trial';
    // Simulate a single transaction commit, not actual D1 concurrency.
    row.used=true;row.status='active';row.trial={start:now,end:now+trialDurationMs};return 'activated';
  }};
}
test('pending registration prepares normalized email and hashed token',async()=>{
  const p=await prepareRegistration({fullName:' Test User ',email:' USER@Example.COM ',now:NOW});
  assert.equal(p.emailNormalized,'user@example.com');assert.equal(p.fullName,'Test User');
  assert.equal(p.token.length,64);assert.notEqual(p.token,p.tokenHash);assert.equal(p.expiresAt,NOW+1800000);
});
test('valid activation creates one 90-day trial; replay rejected',async()=>{
  const p=await prepareRegistration({fullName:'A',email:'a@example.com',now:NOW});
  const row={hash:p.tokenHash,expiry:p.expiresAt,status:'pending',used:false,trial:null};
  assert.deepEqual(await verifyAndActivate({token:p.token,now:NOW,store:mockStore(row)}),{ok:true,reason:'activated'});
  assert.equal(row.trial.end-row.trial.start,90*86400000);
  assert.deepEqual(await verifyAndActivate({token:p.token,now:NOW,store:mockStore(row)}),{ok:false,reason:'used'});
});
test('expiry, inactive account and prior trial are rejected without mutation',async()=>{
  const p=await prepareRegistration({fullName:'A',email:'a@example.com',now:NOW});
  for(const [changes,reason,when] of [[{},'expired',p.expiresAt],[{status:'closed'},'inactive',NOW],[{trial:{}},'already-trial',NOW]]){
    const row={hash:p.tokenHash,expiry:p.expiresAt,status:'pending',used:false,trial:null,...changes};
    assert.equal((await verifyAndActivate({token:p.token,now:when,store:mockStore(row)})).reason,reason);
    assert.equal(row.used,false);
  }
});
test('bad input or absent transactional adapter cannot activate',async()=>{
  assert.deepEqual(await verifyAndActivate({token:'bad',now:NOW,store:mockStore({})}),{ok:false,reason:'invalid'});
  await assert.rejects(()=>verifyAndActivate({token:'a'.repeat(64),now:NOW,store:{}}),/Transactional adapter/);
  await assert.rejects(()=>prepareRegistration({fullName:' ',email:'a@example.com',now:NOW}),/Invalid name/);
});
