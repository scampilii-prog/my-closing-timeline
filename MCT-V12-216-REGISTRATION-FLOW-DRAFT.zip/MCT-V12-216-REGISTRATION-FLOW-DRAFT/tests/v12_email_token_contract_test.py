"""Local SQLite contract tests; NOT a production verification endpoint."""
import sqlite3, pathlib, hashlib, secrets
from datetime import datetime, timedelta, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
SCHEMA = (ROOT / 'ESQUEMA-REGISTRO-PROPUESTO.sql').read_text()

def db():
    con=sqlite3.connect(':memory:')
    con.executescript(SCHEMA)
    con.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES ('a1','Demo','demo@example.test')")
    return con

def issue(con, token, expires):
    digest=hashlib.sha256(token.encode()).hexdigest()
    con.execute('INSERT INTO verification_tokens(token_hash,account_id,expires_at) VALUES (?,?,?)',(digest,'a1',expires.isoformat()))
    return digest

def consume(con, token, now):
    # Conditional update is atomic; checks expiry and single-use in database.
    digest=hashlib.sha256(token.encode()).hexdigest()
    cur=con.execute("UPDATE verification_tokens SET consumed_at=? WHERE token_hash=? AND consumed_at IS NULL AND expires_at>? AND account_id IN (SELECT id FROM accounts WHERE status='pending')", (now.isoformat(),digest,now.isoformat()))
    if cur.rowcount == 1:
        con.execute("UPDATE accounts SET email_verified_at=?,status='active' WHERE id='a1' AND status='pending'",(now.isoformat(),))
    return cur.rowcount == 1

def main():
    now=datetime(2026,11,22,16,0,tzinfo=timezone.utc)
    c=db(); t=secrets.token_urlsafe(32); digest=issue(c,t,now+timedelta(minutes=15))
    assert t != digest and len(digest)==64
    assert not consume(c,'incorrect',now)
    assert consume(c,t,now)
    assert not consume(c,t,now), 'token replay accepted'
    assert c.execute("SELECT status FROM accounts WHERE id='a1'").fetchone()[0]=='active'
    c.close()
    c=db(); t=secrets.token_urlsafe(32); issue(c,t,now-timedelta(seconds=1))
    assert not consume(c,t,now), 'expired token accepted'
    c.close()
    c=db(); t=secrets.token_urlsafe(32); issue(c,t,now)
    assert not consume(c,t,now), 'token expiring exactly now accepted'
    c.close()
    c=db(); t=secrets.token_urlsafe(32); issue(c,t,now+timedelta(minutes=5))
    c.execute("UPDATE accounts SET status='closed' WHERE id='a1'")
    assert not consume(c,t,now), 'closed account verified'
    c.close()
    c=db(); t=secrets.token_urlsafe(32); issue(c,t,now+timedelta(minutes=5))
    c.execute("DELETE FROM accounts WHERE id='a1'")
    assert c.execute('SELECT COUNT(*) FROM verification_tokens').fetchone()[0]==0
    c.close()
    print('PASS token schema contract: hash, wrong token, one use, expiry, closed account, cascade')

if __name__=='__main__':main()
