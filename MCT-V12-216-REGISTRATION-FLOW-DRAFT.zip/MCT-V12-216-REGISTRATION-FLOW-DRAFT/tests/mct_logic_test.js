const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(require('path').join(__dirname,'..','pages','real-estate.js'),'utf8');
let start=source.indexOf('function emailConfirmedGroups(){');
let end=source.indexOf('const emailFields=',start);
assert(start>0&&end>start);
const logic=source.substring(start,end);
const fields={
 'email-table':{value:''},'contract-confirm':{checked:false},'follow-confirm':{checked:false},
 'email-to':{value:''},'email-role':{value:''},'role-other':{value:''},
 'email-subject':{value:''},'email-message':{value:''}
};
const state={contract:[{name:'Contract A',selected:false},{name:'Contract B',selected:false}],follow:[{name:'Follow A',selected:false},{name:'Follow B',selected:false}]};
const context={window:{},state,$:id=>fields[id]};
vm.createContext(context);
vm.runInContext(logic,context);
const groups=()=>JSON.parse(JSON.stringify(context.window.MCTCommunication.groups().map(g=>[g.w,g.tasks.map(x=>x.name)])));
const ready=()=>context.window.MCTCommunication.ready();
const setTable=(value)=>{fields['email-table'].value=value};
const setRecipients=(valid)=>{
 fields['email-to'].value=valid?'user@example.com':'bad';
 fields['email-role'].value=valid?'Buyer':'';
 fields['email-subject'].value=valid?'Subject':'';
 fields['email-message'].value=valid?'Message':'';
};
setRecipients(true);
for(const choice of ['contract','follow','both']){
 setTable(choice);assert(!ready(),choice+' must be locked initially');assert.equal(groups().length,0);
}
state.contract[0].selected=true;state.follow[0].selected=true;
for(const choice of ['contract','follow','both']){
 setTable(choice);assert(!ready(),choice+' must be locked until confirmation');
}
fields['contract-confirm'].checked=true;
setTable('contract');assert(ready());assert.deepStrictEqual(groups(),[['contract',['Contract A']]]);
setTable('follow');assert(!ready());
setTable('both');assert(!ready(),'Both cannot send one approved table');
fields['follow-confirm'].checked=true;
setTable('follow');assert(ready());assert.deepStrictEqual(groups(),[['follow',['Follow A']]]);
setTable('both');assert(ready());assert.deepStrictEqual(groups(),[['contract',['Contract A']],['follow',['Follow A']]]);
for(const choice of ['contract','follow','both']){
 setTable(choice);setRecipients(false);assert(!ready(),choice+' must lock for missing recipient fields');
 setRecipients(true);assert(ready(),choice+' must unlock after recipient fields complete');
}
setTable('both');fields['email-role'].value='Other';assert(!ready());fields['role-other'].value='Title coordinator';assert(ready());
state.follow[0].selected=false;assert(!ready(),'Both must lock when a confirmed table loses all tasks');
state.follow[0].selected=true;fields['follow-confirm'].checked=false;assert(!ready(),'Both must lock when approval changes');
console.log('PASS: 3 options; initial locked; independent confirmation; combined strictness; recipient/role validation; selected rows; 21 assertions.');
