from pathlib import Path
from html.parser import HTMLParser
import re
ROOT=Path(__file__).resolve().parents[1]
class Scanner(HTMLParser):
 def __init__(self):super().__init__();self.ids=set();self.attrs=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);self.attrs.append((tag,a))
  if a.get('id'):self.ids.add(a['id'])
page=Scanner();page.feed((ROOT/'real-estate.html').read_text(encoding='utf-8'))
js=(ROOT/'pages/real-estate.js').read_text(encoding='utf-8')
# Every literal DOM lookup in the primary controller must resolve to an element.
refs=set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)",js))
missing=sorted(refs-page.ids)
assert not missing,f'Controller references nonexistent DOM IDs: {missing}'
# The three stages, the independent task groups and the email controls remain present.
required=['ws-list','ws-open','ws-save','email-table','email-preview','email-open','email-save','email-clear-subject','email-clear-message']
assert set(required)<=page.ids,sorted(set(required)-page.ids)
assert "w+'-rows'" in js and "w+'-confirm'" in js, 'Dynamic task control references changed'
# Verify no duplicate ids and no broken fragment links for literal local anchors.
ids=[a['id'] for _,a in page.attrs if a.get('id')]
assert len(ids)==len(set(ids)),'Duplicate DOM IDs'
anchors=[a['href'][1:] for _,a in page.attrs if a.get('href','').startswith('#') and len(a['href'])>1]
missing_anchors=sorted(set(anchors)-page.ids)
assert not missing_anchors,f'Broken local anchors: {missing_anchors}'
print(f'PASS DOM contract: {len(refs)} JS ID lookups, {len(ids)} unique HTML IDs, {len(anchors)} anchors, 9 required controls')
