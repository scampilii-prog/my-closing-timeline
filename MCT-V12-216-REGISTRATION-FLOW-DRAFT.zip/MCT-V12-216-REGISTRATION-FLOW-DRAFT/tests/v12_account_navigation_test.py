from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
shell=(root/'shared/shell.js').read_text()
assert 'href="account-preview.html?action=sign-in"' in shell
assert 'href="account-preview.html?action=register"' in shell
assert 'href="https://myclosingtimeline.com/login.html"' not in shell
assert 'href="https://myclosingtimeline.com/pro-get-started.html"' not in shell
page=(root/'account-preview.html').read_text()
assert 'not available in this V12 preview' in page
assert '90-day free' in page and 'No credit card required' in page
print('PASS: Account navigation stays within V12 preview; no legacy production registration links')
