from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
assert not (root/'admin-founding-members.html').exists(), 'Private admin HTML must not be publicly deployed as a static file'
studio=(root/'studio.html').read_text()
assert 'href="/admin-founding-members"' in studio
assert 'href="admin-founding-members.html"' not in studio
route=(root/'functions/admin-founding-members.js').read_text()
assert "FOUNDING_MEMBERS_ADMIN_ENABLED!=='true'" in route
assert "mct_owner_session_v2=" in route
assert 'PERSONAL_PRACTICE_PASSWORD' in route
api=(root/'functions/api/founding/admin-summary.js').read_text()
assert "FOUNDING_MEMBERS_ADMIN_ENABLED!=='true'" in api
assert "mct_owner_session_v2=" in api
print('PASS: private admin HTML only through guarded Worker route; static public copy removed')
