from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'real-estate.html').read_text()
css=(ROOT/'pages/workflow-navigation-v12.css').read_text()
assert html.count('workflow-navigation-v12.css')==1
assert '===== SOURCE:' not in css
assert not (ROOT/'pages/legacy-navigation-v11').exists()
for name in ['setup','tasks','communication']:
 assert f'id="{name}"' in html
 assert f'data-step="{name}"' in html
for name in ['contract','follow']:
 assert f'id="{name}-rows"' in html
 assert f'id="{name}-summary"' in html
 assert f'id="{name}-confirm"' in html
print('PASS: V12 navigation, 3 steps, 2 tables, 2 summaries, 2 independent confirmations')
