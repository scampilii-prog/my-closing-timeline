from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'pages/real-estate.js').read_text()
block=s.split("$('ws-list').addEventListener('change',()=>{",1)[1].split("$('ws-delete').onclick=()=>{",1)[0]
assert "db.active=''" in block
assert "state=blank(" in block
assert 'cleanWorkspace(db.workspaces[selected])' not in block
assert 'write(K,db)' not in block
assert "$('ws-role').value=''" in block and "$('ws-ed').value=''" in block and "$('ws-cd').value=''" in block
open_block=s.split("$('ws-open').onclick=()=>{",1)[1].split('const setupSaveButton',1)[0]
assert 'state=cleanWorkspace(db.workspaces[id])' in open_block
assert "db.active=id" in open_block
print('PASS: selecting a workspace cannot load private project data; explicit Open restores saved workspace')
