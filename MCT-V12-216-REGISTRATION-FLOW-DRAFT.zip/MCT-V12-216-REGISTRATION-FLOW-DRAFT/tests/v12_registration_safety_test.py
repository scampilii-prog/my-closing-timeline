from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1]
def new_db():
 c=sqlite3.connect(':memory:'); c.executescript((root/'ESQUEMA-REGISTRO-PROPUESTO.sql').read_text()); return c
def rejected(c,sql,args=()):
 try: c.execute(sql,args)
 except sqlite3.IntegrityError: return
 raise AssertionError('Expected integrity constraint rejection: '+sql)
c=new_db()
c.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES('a','Fictitious','a@example.test')")
c.execute("INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('trial','a','intro_trial','2026-11-22','2027-02-20')")
rejected(c,"INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('trial2','a','intro_trial','2027-03-01','2027-05-30')")
rejected(c,"DELETE FROM accounts WHERE id='a'")
c.execute("UPDATE accounts SET status='closed' WHERE id='a'")
rejected(c,"INSERT INTO accounts(id,full_name,email_normalized) VALUES('b','Fictitious','a@example.test')")
rejected(c,"INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('orphan','missing','intro_trial','2026-11-22','2027-02-20')")
rejected(c,"INSERT INTO activity_preferences(account_id,category) VALUES('a','invalid-category')")
# Simulate competing writes on the same SQLite DB: the UNIQUE index remains the final arbiter.
import tempfile
with tempfile.TemporaryDirectory() as td:
 p=str(Path(td)/'db.sqlite'); db=sqlite3.connect(p); db.executescript((root/'ESQUEMA-REGISTRO-PROPUESTO.sql').read_text());db.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES('a','Fictitious','a@example.test')");db.commit()
 x=sqlite3.connect(p); y=sqlite3.connect(p)
 x.execute("INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('x','a','intro_trial','2026-11-22','2027-02-20')");x.commit()
 rejected(y,"INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('y','a','intro_trial','2026-11-22','2027-02-20')")
 x.close();y.close();db.close()
print('PASS: one trial/account, closed account retains history, delete restricted, FK and categories; sequential competing connections')
