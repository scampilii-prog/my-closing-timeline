from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
soup=BeautifulSoup((root/'real-estate-guided.html').read_text(),'html.parser')
for link in list(soup.find_all('link',href=True)):
 if link.get('rel')==['stylesheet']:
  style=soup.new_tag('style');style.string=(root/link['href']).read_text();link.replace_with(style)
for script in list(soup.find_all('script',src=True)):
 path=root/script['src'];script.attrs.pop('src');script.string=path.read_text().replace('</script','<\\/script')
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in (1440,1100,800,390):
   page=browser.new_page(viewport={'width':width,'height':850})
   page.set_content(str(soup),wait_until="load");page.wait_for_timeout(250)
   assert page.locator('#mct-guide-sidebar').count()==1
   assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),f'horizontal overflow {width}'
   assert page.locator('#mct-guide-sidebar').evaluate('(e)=>getComputedStyle(e).position')==('fixed' if width>950 else 'relative')
   header=page.locator('#shared-header').bounding_box()
   page.evaluate('scrollTo(0,250)');page.wait_for_timeout(250)
   assert abs(page.locator('#shared-header').bounding_box()['y'])<2
   assert page.locator('#shared-header').evaluate('(e)=>getComputedStyle(e).position')=='fixed'
   if width>950:
    side=page.locator('#mct-guide-sidebar').bounding_box();main=page.locator('main.re-main').bounding_box()
    assert side['x'] < main['x'] and side['x']+side['width'] <= main['x']
   page.close()
   print(f'PASS guided alignment {width}px')
  browser.close()

