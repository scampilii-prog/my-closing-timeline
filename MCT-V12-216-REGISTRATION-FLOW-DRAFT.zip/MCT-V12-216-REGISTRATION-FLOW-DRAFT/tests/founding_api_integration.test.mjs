import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {onRequestPost} from '../functions/api/founding/enroll.js';
import {onRequestGet} from '../functions/api/founding/status.js';
const users=new Map(), sessions=new Map(),members=new Map();
function db(){return {prepare(sql){return {bind(...args){return {async first(){if(sql.includes('FROM sessions s')){const uid=sessions.get(args[0]);return uid&&users.get(uid)?.verified?{user_id:uid}:null}if(sql.includes('FROM founding_members'))return members.get(args[0])||null;throw Error('Unexpected read '+sql)},async run(){if(sql.includes('INSERT OR IGNORE INTO founding_members')){const [id,start,end]=args;if(!members.has(id))members.set(id,{started_at:start,expires_at:end,extension_count:0,status:'active'});return {success:true}}throw Error('Unexpected write '+sql)}}}}}}}
function req(token,body={joinFoundingMembers:true,termsAccepted:true},origin='https://example.test'){return new Request('https://example.test/api/founding/enroll',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(token?{Cookie:'mct_pro_session='+token}:{})},body:JSON.stringify(body)})}
function getreq(token){return new Request('https://example.test/api/founding/status',{headers:token?{Cookie:'mct_pro_session='+token}:{}})}
const a='A'.repeat(43),b='B'.repeat(43),hash=s=>createHash('sha256').update(s).digest('hex');users.set('a',{verified:true});users.set('b',{verified:true});sessions.set(hash(a),'a');sessions.set(hash(b),'b');
const env={PRO_DB:db(),FOUNDING_MEMBERS_ENROLL_ENABLED:'true',FOUNDING_MEMBERS_STATUS_ENABLED:'true'};
let n=0;async function check(label,response,status){assert.equal(response.status,status,label);n++}
await check('off',await onRequestPost({request:req(a),env:{...env,FOUNDING_MEMBERS_ENROLL_ENABLED:'false'}}),404);
await check('no session',await onRequestPost({request:req(null),env}),401);
await check('cross-origin',await onRequestPost({request:req(a,undefined,'https://evil.test'),env}),403);
await check('no consent',await onRequestPost({request:req(a,{joinFoundingMembers:false,termsAccepted:true}),env}),400);
await check('first enroll',await onRequestPost({request:req(a),env}),200);
const first=members.get('a').started_at;
await check('repeat enroll',await onRequestPost({request:req(a),env}),200);assert.equal(members.get('a').started_at,first);
await check('other account enroll',await onRequestPost({request:req(b),env}),200);assert.equal(members.size,2);
const statusA=await onRequestGet({request:getreq(a),env});await check('status A',statusA,200);const dataA=await statusA.json();assert.equal(dataA.enrolled,true);assert.equal(dataA.extension_count,0);assert.equal('email' in dataA,false);assert.equal('user_id' in dataA,false);assert.equal('projects' in dataA,false);
const statusB=await onRequestGet({request:getreq(b),env});await check('status B',statusB,200);const dataB=await statusB.json();assert.equal(dataB.enrolled,true);assert.equal(dataB.extension_count,0);
members.get('a').extension_count=2;const separated=await (await onRequestGet({request:getreq(b),env})).json();assert.equal(separated.extension_count,0,'account B must not see account A extension count');
await check('status no cookie',await onRequestGet({request:getreq(null),env}),401);
await check('status disabled',await onRequestGet({request:getreq(a),env:{...env,FOUNDING_MEMBERS_STATUS_ENABLED:'false'}}),404);
users.set('b',{verified:false});await check('unverified blocked',await onRequestGet({request:getreq(b),env}),401);
console.log(`PASS ${n} integration checks (mock D1, no production access)`);
