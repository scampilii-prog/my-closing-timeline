from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'pages/real-estate.js').read_text()
cap=s.split('function capture(){',1)[1].split('function loadDraft(){',1)[0]
load=s.split('function loadDraft(){',1)[1].split("$('email-table').onchange",1)[0]
assert "state.drafts[w]=" in cap
assert "roleOther:$('email-role').value==='Other'?$('role-other').value:''" in cap
assert "$('role-other').value=d.role==='Other'?(d.roleOther||''):''" in load
assert "$('role-other-wrap').hidden=d.role!=='Other'" in load
assert "const emailFields=['email-to','email-role','role-other','email-subject','email-message']" in s
assert "const w=$('email-table').value;if(!w)return" in s
assert "if(!db.active)return false" in s
print('PASS: Other role saved per table, restored only for its draft, and cleared when another draft is chosen')
