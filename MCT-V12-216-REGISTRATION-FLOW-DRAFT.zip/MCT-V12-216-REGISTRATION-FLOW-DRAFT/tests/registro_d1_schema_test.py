from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1]
con=sqlite3.connect(':memory:')
con.executescript((root/'ESQUEMA-REGISTRO-PROPUESTO.sql').read_text())
con.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES('a','Test User','test@example.com')")
try:
 con.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES('b','Test User','test@example.com')")
 raise AssertionError('Email duplicado permitido')
except sqlite3.IntegrityError: pass
con.execute("INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('t1','a','intro_trial','2026-11-22','2027-02-20')")
try:
 con.execute("INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES('t2','a','intro_trial','2027-03-01','2027-05-30')")
 raise AssertionError('Segunda prueba permitida')
except sqlite3.IntegrityError: pass
for category in ('real-estate','business','services','personal'):
 con.execute('INSERT INTO activity_preferences(account_id,category) VALUES(?,?)',('a',category))
assert con.execute('SELECT count(*) FROM activity_preferences').fetchone()[0]==4
print('OK: email único, prueba única por cuenta y 4 categorías')
