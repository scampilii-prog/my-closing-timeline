from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'pages/real-estate.js').read_text()
assert "const confirmed=(window.MCTCommunication?.groups()?.length||0)>0;" in s
assert "if(window.MCTCommunication?.ready?.()&&!$('email-result').hidden){previewed=true;guideEmail()}" in s
assert "if(window.MCTCommunication?.ready?.()){emailOpened=true;setTimeout(guideEmail,0);}" in s
assert "['contract','follow'].some(k=>$(k+'-confirm')" not in s
assert "$(value('email-table')+'-confirm')?.checked" not in s
assert "if(!keys.length||keys.some(k=>!$(k+'-confirm')?.checked||!state[k].some(t=>t.selected)))return []" in s
print('PASS: preview, open and guide share confirmation authority; Both requires both confirmed')
