from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
soup=BeautifulSoup((root/'real-estate.html').read_text(),'html.parser')
for link in list(soup.find_all('link',href=True)):
 if link.get('rel')==['stylesheet']:
  style=soup.new_tag('style');style.string=(root/link['href'].split('?',1)[0]).read_text();link.replace_with(style)
for s in list(soup.find_all('script',src=True)):
 f=root/s['src'].split('?',1)[0];s.attrs.pop('src');s.string=f.read_text().replace('</script','<\\/script')
shim=soup.new_tag('script')
shim.string="""const __mctMemory={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>Object.prototype.hasOwnProperty.call(__mctMemory,k)?__mctMemory[k]:null,setItem:(k,v)=>{__mctMemory[k]=String(v)},removeItem:k=>delete __mctMemory[k],clear:()=>Object.keys(__mctMemory).forEach(k=>delete __mctMemory[k])}});"""
soup.head.insert(0,shim)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(4000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(str(soup),wait_until='load');page.wait_for_timeout(300)
 def test(name,fn):
  try:fn();page.wait_for_timeout(150);assert not errors,errors;print('PASS',name)
  except Exception as e: print('FAIL',name,str(e)[:500]);raise
 def create():
  page.locator('#ws-name').fill('TEST A');page.locator('#ws-role').select_option(label='Buyer Agent');page.locator('#ws-new').click();assert 'TEST A' in page.locator('#ws-status').inner_text()
 test('create workspace',create)
 def dates():
  page.locator('#ws-ed').fill('2026-11-13');page.locator('#ws-cd').fill('2026-12-15');page.locator('#ws-save').click();assert 'saved successfully' in page.locator('#ws-status').inner_text()
 test('save dates',dates)
 def tasks():
  check=page.locator('#contract-rows tr td:first-child input[type=checkbox]').first;check.check();assert page.locator('#contract-selected').inner_text().startswith('1 selected');page.locator('#contract-confirm').check();page.locator('#email-table').select_option('contract');assert page.locator('#email-selected-count').inner_text()
 test('select and confirm table 01',tasks)
 def email():
  page.locator('#email-to').fill('test@example.com');page.locator('#email-role').select_option('Other');page.locator('#role-other').fill('Coordinator');page.locator('#email-subject').fill('Test subject');page.locator('#email-message').fill('Test message');page.locator('#email-save').click();page.locator('#email-preview').click();assert 'Test message' in page.locator('#email-result').inner_text()
 test('draft and preview',email)
 def second():
  page.locator('#ws-list').select_option('__new__');page.locator('#ws-name').fill('TEST B');page.locator('#ws-new').click();assert 'TEST B' in page.locator('#ws-status').inner_text();assert page.locator('#email-to').input_value()=='';assert page.locator('#contract-rows tr td:first-child input[type=checkbox]:checked').count()==0
 test('new workspace isolation',second)
 def reopen():
  page.locator('#ws-list').select_option('TEST A');assert page.locator('#ws-ed').input_value()=='';page.locator('#ws-open').click();assert page.locator('#ws-ed').input_value()=='2026-11-13';assert page.locator('#contract-rows tr td:first-child input[type=checkbox]:checked').count()==0
 test('reopen saved workspace no old selections',reopen)
 print('PAGE ERRORS',errors)
 b.close()
