import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
if(!globalThis.crypto)globalThis.crypto=webcrypto;
import {onRequestGet} from '../functions/admin-founding-members.js';
const secret='a-strong-secret-for-tests';
const request=cookie=>new Request('https://example.test/admin-founding-members',{headers:{Cookie:cookie}});
const call=(cookie='',enabled='true')=>onRequestGet({request:request(cookie),env:{FOUNDING_MEMBERS_ADMIN_ENABLED:enabled,PERSONAL_PRACTICE_PASSWORD:secret}});
async function signed(exp){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);const sig=Buffer.from(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode('v2.'+exp))).toString('base64url');return `mct_owner_session_v2=v2.${exp}.${sig}`;}
assert.equal((await call('','false')).status,404);
assert.equal((await call()).status,401);
assert.equal((await call('mct_pro_session=other-user')).status,401);
assert.equal((await call(await signed(Date.now()-1000))).status,401);
const ok=await call(await signed(Date.now()+60000));
assert.equal(ok.status,200);
assert.match(await ok.text(),/Founding Members/);
assert.equal(ok.headers.get('Cache-Control'),'private, no-store');
console.log('PASS: private admin page requires valid owner cookie, refuses PRO and expired sessions');
