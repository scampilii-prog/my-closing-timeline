"""Reference-only tests: not a deployed authentication/session service."""
import sqlite3, hashlib, secrets
from datetime import datetime, timedelta, timezone
NOW=datetime(2026,11,22,18,0,tzinfo=timezone.utc)
db=sqlite3.connect(':memory:')
db.executescript("""
PRAGMA foreign_keys=ON;
CREATE TABLE accounts(id TEXT PRIMARY KEY,status TEXT NOT NULL);
CREATE TABLE sessions(token_hash TEXT PRIMARY KEY,account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,expires_at TEXT NOT NULL,revoked_at TEXT);
CREATE TABLE attempts(scope TEXT NOT NULL,subject_hash TEXT NOT NULL,occurred_at TEXT NOT NULL);
CREATE INDEX attempts_window ON attempts(scope,subject_hash,occurred_at);
""")
db.execute("INSERT INTO accounts VALUES('a1','active')")
def h(token):return hashlib.sha256(token.encode()).hexdigest()
def valid(token,now=NOW):
    return db.execute("SELECT 1 FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.revoked_at IS NULL AND s.expires_at>? AND a.status='active'",(h(token),now.isoformat())).fetchone() is not None
raw=secrets.token_urlsafe(32)
db.execute('INSERT INTO sessions VALUES(?,?,?,NULL)',(h(raw),'a1',(NOW+timedelta(hours=2)).isoformat()))
assert valid(raw) and not valid('wrong')
assert not valid(raw,NOW+timedelta(hours=2)), 'expiry boundary must reject'
db.execute("UPDATE accounts SET status='suspended' WHERE id='a1'")
assert not valid(raw), 'suspended accounts must not authenticate'
db.execute("UPDATE accounts SET status='active' WHERE id='a1'")
db.execute('UPDATE sessions SET revoked_at=? WHERE token_hash=?',(NOW.isoformat(),h(raw)))
assert not valid(raw), 'revocation must be effective'
raw2=secrets.token_urlsafe(32)
db.execute('INSERT INTO sessions VALUES(?,?,?,NULL)',(h(raw2),'a1',(NOW+timedelta(hours=2)).isoformat()))
assert valid(raw2)
db.execute("DELETE FROM accounts WHERE id='a1'")
assert not valid(raw2) and db.execute('SELECT COUNT(*) FROM sessions').fetchone()[0]==0

def allowed(scope,subject,now=NOW,limit=3,window=timedelta(minutes=15)):
    subject_hash=h(subject.lower().strip())
    db.execute('DELETE FROM attempts WHERE scope=? AND subject_hash=? AND occurred_at<=?',(scope,subject_hash,(now-window).isoformat()))
    count=db.execute('SELECT COUNT(*) FROM attempts WHERE scope=? AND subject_hash=?',(scope,subject_hash)).fetchone()[0]
    if count>=limit:return False
    db.execute('INSERT INTO attempts VALUES(?,?,?)',(scope,subject_hash,now.isoformat()))
    return True
assert [allowed('verify','demo@example.test') for _ in range(4)]==[True,True,True,False]
assert allowed('reset','demo@example.test'), 'separate scope'
assert allowed('verify','other@example.test'), 'separate subject'
assert allowed('verify','demo@example.test',NOW+timedelta(minutes=16)), 'window expires'
assert db.execute('SELECT subject_hash FROM attempts LIMIT 1').fetchone()[0]!='demo@example.test'
print('PASS reference session: hash, expiry, suspension, revoke, cascade; rate limit: window, scope, subject')
