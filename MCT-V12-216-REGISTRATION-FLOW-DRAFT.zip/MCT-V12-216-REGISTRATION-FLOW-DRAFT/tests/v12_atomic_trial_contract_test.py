"""SQLite reference contract only: not deployed registration or email service."""
import sqlite3, pathlib, hashlib
from datetime import datetime, timedelta, timezone

ROOT=pathlib.Path(__file__).resolve().parents[1]
SCHEMA=(ROOT/'ESQUEMA-REGISTRO-PROPUESTO.sql').read_text()
NOW=datetime(2026,11,22,17,0,tzinfo=timezone.utc)

def setup():
    db=sqlite3.connect(':memory:', isolation_level=None)
    db.executescript(SCHEMA)
    db.execute("INSERT INTO accounts(id,full_name,email_normalized) VALUES ('a1','Demo','demo@example.test')")
    db.execute('INSERT INTO verification_tokens(token_hash,account_id,expires_at) VALUES (?,?,?)',('hash1','a1',(NOW+timedelta(minutes=15)).isoformat()))
    return db

def activate(db, now=NOW, fail_after_consume=False):
    stamp=now.isoformat()
    db.execute('BEGIN IMMEDIATE')
    try:
        cur=db.execute("UPDATE verification_tokens SET consumed_at=? WHERE token_hash='hash1' AND consumed_at IS NULL AND expires_at>? AND account_id IN (SELECT id FROM accounts WHERE status='pending')",(stamp,stamp))
        if cur.rowcount!=1:
            db.execute('ROLLBACK'); return False
        if fail_after_consume: raise RuntimeError('simulated failure')
        cur=db.execute("UPDATE accounts SET email_verified_at=?,status='active' WHERE id='a1' AND status='pending'",(stamp,))
        if cur.rowcount!=1: raise RuntimeError('account state conflict')
        db.execute("INSERT INTO entitlements(id,account_id,kind,starts_at,ends_at) VALUES (?,?,?,?,?)",('intro-a1','a1','intro_trial',stamp,(now+timedelta(days=90)).isoformat()))
        db.execute('COMMIT'); return True
    except Exception:
        db.execute('ROLLBACK'); raise

def main():
    db=setup(); assert activate(db)
    assert db.execute("SELECT COUNT(*) FROM entitlements WHERE kind='intro_trial'").fetchone()[0]==1
    assert db.execute('SELECT status FROM accounts').fetchone()[0]=='active'
    assert not activate(db), 'replay granted another trial'
    assert db.execute('SELECT COUNT(*) FROM entitlements').fetchone()[0]==1
    db.close()
    db=setup()
    try: activate(db,fail_after_consume=True)
    except RuntimeError: pass
    else: raise AssertionError('failure not raised')
    assert db.execute('SELECT consumed_at FROM verification_tokens').fetchone()[0] is None
    assert db.execute('SELECT status FROM accounts').fetchone()[0]=='pending'
    assert db.execute('SELECT COUNT(*) FROM entitlements').fetchone()[0]==0
    assert activate(db), 'retry after rollback failed'
    db.close()
    db=setup(); assert not activate(db,NOW+timedelta(minutes=16))
    assert db.execute('SELECT COUNT(*) FROM entitlements').fetchone()[0]==0
    db.close()
    print('PASS atomic contract: token + account + 90-day entitlement, rollback, replay, expiry')
if __name__=='__main__':main()
