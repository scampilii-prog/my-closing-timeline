"""Real Chromium rendering without network/file navigation; tests inlined local assets."""
from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
soup=BeautifulSoup((root/'real-estate.html').read_text(),'html.parser')
for link in list(soup.find_all('link',href=True)):
 if link.get('rel')==['stylesheet']:
  style=soup.new_tag('style');style.string=(root/link['href'].split('?',1)[0]).read_text();link.replace_with(style)
for script in list(soup.find_all('script',src=True)):
 script_path=root/script['src'].split('?',1)[0];script.attrs.pop('src');script.string=script_path.read_text().replace('</script','<\\/script')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for width in (1440,390):
  page=browser.new_page(viewport={'width':width,'height':844})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(str(soup),wait_until='load');page.wait_for_timeout(250)
  assert not errors,errors
  assert page.locator('.re-progress-nav a[data-step]').count()==3
  assert page.locator('#contract-rows tr').count()>=6
  assert page.locator('#follow-rows tr').count()>=6
  assert page.locator('#ws-role').input_value()==''
  assert page.locator('#ws-ed').input_value()==''
  assert page.locator('#ws-cd').input_value()==''
  assert page.locator('#contract-rows input[type=checkbox]:checked').count()==0
  assert page.locator('#follow-rows input[type=checkbox]:checked').count()==0
  print(f'PASS Chromium {width}px: no page errors, navigation, tables, blank setup')
  page.close()
 browser.close()
