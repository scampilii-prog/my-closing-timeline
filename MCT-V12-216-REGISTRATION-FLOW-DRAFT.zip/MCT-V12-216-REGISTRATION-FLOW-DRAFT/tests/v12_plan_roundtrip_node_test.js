const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const root=path.resolve(__dirname,'..');
const plans=fs.readFileSync(path.join(root,'plans.html'),'utf8');
const script=fs.readFileSync(path.join(root,'pages/pricing-v188.js'),'utf8');
const payment=fs.readFileSync(path.join(root,'payment.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
function elements(html){const ids=['project-category','project-term','project-link','two-first','two-second','two-term','two-link','two-error','all-term','all-link','selected-plan','selected-details','back-to-plans'];const out={};for(const id of ids){const el=html.match(new RegExp('<(?:select|a|p|h1|div)\\b[^>]*\\bid="'+id+'"[^>]*>','i'));if(!el)continue;const options=html.slice(el.index+el[0].length).split('</select>')[0];const opt=options.match(/<option value="([^"]+)"/);out[id]={value:opt?.[1]||'',href:(el[0].match(/href="([^"]+)"/)||[])[1]||'',textContent:'',attrs:{},listeners:{},classList:{toggle(){}},addEventListener(event,cb){this.listeners[event]=cb},setAttribute(k,v){this.attrs[k]=v},getAttribute(k){return this.attrs[k]}};}return out;}
function runPlans(query){const els=elements(plans),ctx={document:{getElementById:id=>els[id]},location:{search:query?'?'+query:''},URLSearchParams,encodeURIComponent};vm.runInNewContext(script,ctx);return els;}
function runPayment(query){const els=elements(fs.readFileSync(path.join(root,'payment.html'),'utf8'));els['back-to-plans'].href='plans.html';const ctx={document:{getElementById:id=>els[id]},location:{search:'?'+query},URLSearchParams};vm.runInNewContext(payment,ctx);return els;}
for(const [plan,values,selector] of [
 ['project',{'project-category':'business','project-term':'90'},'project-link'],
 ['two',{'two-first':'real-estate','two-second':'personal','two-term':'6'},'two-link'],
 ['all',{'all-term':'12'},'all-link']]){
 const a=runPlans('');Object.entries(values).forEach(([k,v])=>{a[k].value=v;a[k].listeners.change()});const href=a[selector].href;assert(href.startsWith('payment.html?'),href);const p=runPayment(href.split('?')[1]);assert(!p['selected-details'].textContent.includes('Please select a valid'),plan);const back=p['back-to-plans'].href;assert(back.startsWith('plans.html?'),back);const b=runPlans(back.split('?')[1]);assert.strictEqual(b[selector].href,href,plan);console.log('PASS roundtrip',plan);
}
const d=runPlans('');d['two-second'].value=d['two-first'].value;d['two-second'].listeners.change();assert.strictEqual(d['two-link'].href,'#two-error');assert.strictEqual(d['two-link'].attrs['aria-disabled'],'true');console.log('PASS duplicate category blocked');
const invalid=runPayment('plan=project&category=invalid&days=90');assert.strictEqual(invalid['back-to-plans'].href,'plans.html');console.log('PASS invalid parameters rejected');
