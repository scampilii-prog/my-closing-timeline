from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'pages/real-estate.js').read_text()
open_block=s.split('async function openTemplate(w){',1)[1].split('async function saveTemplate(w){',1)[0]
save_block=s.split('async function saveTemplate(w){',1)[1].split("['contract','follow'].forEach(w=>{",1)[0]
picker=s.split("picker.addEventListener('change',async()=>{",1)[1].split("document.querySelector('[data-template-save',",1)[0]
assert 'if(!db.active)' not in open_block
assert 'if(!db.active)' not in save_block
assert 'if(choice&&!db.active)' not in picker
assert 'if(!await confirmTemplateReplacement(w)){' in open_block
assert "$(w+'-template-select').value=''" in open_block
assert 'state[w]=templateRows(source)' in open_block
assert open_block.index('if(!await confirmTemplateReplacement(w))') < open_block.index('state[w]=templateRows(source)')
assert 'selected:false,done:false,notes:' in s.split('function templateRows(rows)',1)[1].split('function refreshTemplateChoices',1)[0]
assert 'async function confirmTemplateReplacement(w)' in s
assert 'confirmTemplateAction({title:\'Replace Current Table' in s
print('PASS: personal templates independent of workspace; replacement waits for custom confirmation; transaction-specific data cleared')
