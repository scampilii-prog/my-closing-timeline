from pathlib import Path
import re, subprocess
root=Path(__file__).resolve().parents[1]
for name in ('index.html','real-estate.html','real-estate-guided.html'):
    s=(root/name).read_text()
    for ref in re.findall(r'(?:src|href)=["\']([^"\']+)["\']',s):
        if ref.startswith(('http:','https:','#','mailto:','tel:')):continue
        assert (root/ref.split('#')[0].split('?')[0]).is_file(),(name,ref)
for js in list((root/'pages').glob('*.js'))+list((root/'shared').glob('*.js')):
    subprocess.run(['node','--check',str(js)],check=True,capture_output=True)
print('PASS: local assets and JavaScript syntax')
