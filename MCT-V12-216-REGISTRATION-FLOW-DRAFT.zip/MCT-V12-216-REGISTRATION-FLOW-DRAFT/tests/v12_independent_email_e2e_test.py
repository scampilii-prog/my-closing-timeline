from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
soup=BeautifulSoup((root/'real-estate.html').read_text(),'html.parser')
for link in list(soup.find_all('link',href=True)):
 if link.get('rel')==['stylesheet']:
  style=soup.new_tag('style');style.string=(root/link['href'].split('?',1)[0]).read_text();link.replace_with(style)
for s in list(soup.find_all('script',src=True)):
 f=root/s['src'].split('?',1)[0];s.attrs.pop('src');s.string=f.read_text().replace('</script','<\\/script')
shim=soup.new_tag('script')
shim.string="""const __mctMemory={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>Object.prototype.hasOwnProperty.call(__mctMemory,k)?__mctMemory[k]:null,setItem:(k,v)=>{__mctMemory[k]=String(v)},removeItem:k=>delete __mctMemory[k],clear:()=>Object.keys(__mctMemory).forEach(k=>delete __mctMemory[k])}});"""
soup.head.insert(0,shim)
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900});errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(str(soup),wait_until='load');page.wait_for_timeout(350)
 page.locator('#ws-name').fill('CASE A');page.locator('#ws-role').select_option(label='Buyer Agent');page.locator('#ws-new').click()
 page.locator('#ws-ed').fill('2026-11-13');page.locator('#ws-cd').fill('2026-12-15');page.locator('#ws-save').click()
 c=page.locator('#contract-rows tr td:first-child input[type=checkbox]').first;c.check();page.locator('#contract-confirm').check()
 page.locator('#email-table').select_option('contract')
 assert len(page.evaluate('window.MCTCommunication.groups()'))==1
 page.locator('#email-to').fill('contract@example.com');page.locator('#email-role').select_option('Other');page.locator('#role-other').fill('Contract manager');page.locator('#email-subject').fill('Contract only');page.locator('#email-message').fill('Contract message');page.locator('#email-save').click()
 page.locator('#email-preview').click();assert 'Contract message' in page.locator('#email-result').inner_text()
 page.locator('#email-table').select_option('follow')
 assert len(page.evaluate('window.MCTCommunication.groups()'))==0
 f=page.locator('#follow-rows tr td:first-child input[type=checkbox]').first;f.check();page.locator('#follow-confirm').check()
 assert len(page.evaluate('window.MCTCommunication.groups()'))==1
 page.locator('#email-to').fill('follow@example.com');page.locator('#email-role').select_option(label='Title Company');page.locator('#email-subject').fill('Follow only');page.locator('#email-message').fill('Follow message');page.locator('#email-save').click()
 page.locator('#email-preview').click();assert 'Follow message' in page.locator('#email-result').inner_text()
 page.locator('#email-table').select_option('contract')
 assert page.locator('#email-to').input_value()=='contract@example.com'
 assert page.locator('#role-other').input_value()=='Contract manager'
 assert page.locator('#email-subject').input_value()=='Contract only'
 page.locator('#email-table').select_option('follow')
 assert page.locator('#email-to').input_value()=='follow@example.com'
 assert page.locator('#email-subject').input_value()=='Follow only'
 page.locator('#email-table').select_option('both')
 assert len(page.evaluate('window.MCTCommunication.groups()'))==2
 page.locator('#contract-confirm').uncheck()
 assert len(page.evaluate('window.MCTCommunication.groups()'))==0
 page.locator('#email-table').select_option('follow')
 assert len(page.evaluate('window.MCTCommunication.groups()'))==1
 page.locator('#contract-confirm').check()
 page.locator('#ws-list').select_option(label='+ Create a New Project');page.locator('#ws-name').fill('CASE B');page.locator('#ws-new').click()
 assert page.locator('#contract-rows tr td:first-child input[type=checkbox]:checked').count()==0
 assert page.locator('#follow-rows tr td:first-child input[type=checkbox]:checked').count()==0
 page.locator('#email-table').select_option('contract')
 assert page.locator('#email-to').input_value()==''
 page.locator('#ws-list').select_option('CASE A');page.locator('#ws-open').click()
 page.locator('#email-table').select_option('contract')
 assert page.locator('#email-to').input_value()=='contract@example.com'
 assert page.locator('#contract-rows tr td:first-child input[type=checkbox]:checked').count()==0
 assert not errors,errors
 print('PASS independent Table 01, Table 02, Both; separate drafts; confirmation; workspace isolation')
 b.close()
