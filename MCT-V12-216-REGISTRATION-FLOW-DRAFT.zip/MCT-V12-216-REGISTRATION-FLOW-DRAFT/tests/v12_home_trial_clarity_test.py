from pathlib import Path
s=(Path(__file__).resolve().parents[1]/"index.html").read_text()
assert "90 DAYS FREE · FOR EVERY NEW USER" in s
assert "Every new user will be eligible" in s
assert "Founding Members is a separate, optional program" in s
assert "registration and free-trial activation are not yet available" in s
assert "90 DAYS FREE · FOUNDING MEMBERS" not in s
print("PASS: universal 90-day trial distinguished from optional Founding Members")
