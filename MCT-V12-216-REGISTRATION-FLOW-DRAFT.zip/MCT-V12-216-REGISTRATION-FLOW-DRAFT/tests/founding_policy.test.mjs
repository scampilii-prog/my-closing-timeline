import test from 'node:test';
import assert from 'node:assert/strict';
import {DAY,initialTrial,evaluateAccess,nextExtension} from '../founding-members-policy.mjs';

test('90 days exactly',()=>{const t=initialTrial(1700000000);assert.equal(t.expires_at-t.started_at,90*DAY);});
test('invalid timestamp refused',()=>assert.throws(()=>initialTrial(NaN)));
test('access at boundary expires',()=>{const t=initialTrial(1700000000);assert.equal(evaluateAccess(t,t.expires_at-1).canEdit,true);assert.equal(evaluateAccess(t,t.expires_at).canEdit,false);});
test('suspended cannot edit',()=>{const t={...initialTrial(1700000000),status:'suspended'};assert.equal(evaluateAccess(t,t.started_at).canEdit,false);});
test('first and second extensions',()=>{let t=initialTrial(1700000000);t={...t,...nextExtension(t,1,[1],[])};t={...t,...nextExtension(t,2,[1,2],[1])};assert.equal(t.expires_at-t.started_at,150*DAY);assert.equal(t.extension_count,2);});
test('no extension without approved round',()=>assert.throws(()=>nextExtension(initialTrial(1700000000),1,[],[])));
test('no duplicate round',()=>assert.throws(()=>nextExtension(initialTrial(1700000000),1,[1],[1])));
test('no third extension',()=>assert.throws(()=>nextExtension({...initialTrial(1700000000),extension_count:2},2,[2],[])));
test('invalid round refused',()=>assert.throws(()=>nextExtension(initialTrial(1700000000),3,[3],[])));
