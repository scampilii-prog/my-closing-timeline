import assert from 'node:assert/strict';
import {webcrypto} from 'node:crypto';
if(!globalThis.crypto)globalThis.crypto=webcrypto;
import {onRequestGet} from '../functions/api/founding/admin-summary.js';
const secret='a-strong-secret-for-tests';
const db={prepare(sql){assert.match(sql,/FROM founding_members/);return {bind(...v){assert.equal(v.length,2);return {async first(){return {total:4,active:2,expired:2,suspended:0,extended:1,fully_extended:0}}}}}}};
const call=(cookie='',enabled='true',password=secret)=>onRequestGet({request:new Request('https://example.test/api/founding/admin-summary',{headers:{Cookie:cookie}}),env:{FOUNDING_MEMBERS_ADMIN_ENABLED:enabled,PERSONAL_PRACTICE_PASSWORD:password,PRO_DB:db}});
assert.equal((await call('','false')).status,404);
assert.equal((await call()).status,401);
assert.equal((await call('mct_pro_session=not-an-owner')).status,401);
const enc=new TextEncoder();
async function signed(exp){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);const bytes=new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode('v2.'+exp)));const sig=Buffer.from(bytes).toString('base64url');return `mct_owner_session_v2=v2.${exp}.${sig}`;}
assert.equal((await call(await signed(Date.now()-10000))).status,401);
assert.equal((await call(await signed(Date.now()+60_000),'true','wrong-password-long')).status,401);
const ok=await call(await signed(Date.now()+60_000));assert.equal(ok.status,200);
assert.deepEqual((await ok.json()).summary,{total:4,active:2,expired:2,suspended:0,extended:1,fully_extended:0});
assert.equal(ok.headers.get('Cache-Control'),'private, no-store');
console.log('PASS: admin summary flag, unauthenticated, PRO cookie, expired, wrong secret, owner session, aggregates, no-store');
