from pathlib import Path
from html.parser import HTMLParser
import re, subprocess
ROOT=Path(__file__).resolve().parents[1]
class Scan(HTMLParser):
 def __init__(self): super().__init__(); self.ids=[]; self.refs=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if 'id' in a:self.ids.append(a['id'])
  if tag=='script' and a.get('src'):self.refs.append(a['src'])
  if tag=='link' and a.get('href') and a.get('rel')=='stylesheet':self.refs.append(a['href'])
for page in ['real-estate.html','index.html']:
 s=Scan();s.feed((ROOT/page).read_text())
 assert len(s.ids)==len(set(s.ids)),f'Duplicate IDs in {page}'
 for ref in s.refs:
  assert (ROOT/ref.split("?",1)[0]).is_file(),f'Missing dependency {page}: {ref}'
  if ref.endswith('.js'):
   subprocess.run(['node','--check',str(ROOT/ref.split("?",1)[0])],check=True,capture_output=True)
 print('PASS',page,len(s.ids),'unique IDs;',len(s.refs),'dependencies exist; JS syntax valid')
html=(ROOT/'real-estate.html').read_text()
assert html.count('workflow-navigation-v12.css')==1
for name in ['navigation-195.css','navigation-196.css','navigation-197.css','navigation-198.css','navigation-199.css','navigation-200.css','navigation-204.css','navigation-205.css','section-headings-201.css']:
 assert name not in html,f'Legacy CSS loaded: {name}'
assert (ROOT/'pages/workflow-navigation-v12.css').is_file()
print('PASS: one consolidated navigation CSS loaded; no legacy navigation CSS links')
