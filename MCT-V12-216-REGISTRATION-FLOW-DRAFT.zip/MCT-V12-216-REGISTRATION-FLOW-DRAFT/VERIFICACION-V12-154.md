V12-154: Estilos de contraste chocolate/dorado en Table 01, Table 02 y ambos resúmenes. Sin cambios de JavaScript ni de lógica. Verificación pendiente en navegador real.
