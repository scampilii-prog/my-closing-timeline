# V12-142 — Base verificada para Founding Members

Esta entrega conserva las páginas y el diseño de V12-141. **No activa cuentas ni el programa Founding Members.**

## Confirmaciones
- Cloudflare Pages tiene el binding D1 `PRO_DB` a `myclosingtimeline-pro` (confirmado por captura).
- Cloudflare D1 Studio muestra 22 tablas, incluidas `users`, `sessions`, `email_verifications`, `password_resets` y `mpt_projects`.
- La tabla `users` ya tiene cuentas; no se deben modificar ni copiar sus datos para probar.
- El backend PRO existente en GitHub ofrece una base para reutilizar autenticación, pero requiere pruebas independientes.

## Antes de habilitar Founding Members
1. Crear migración **aditiva** de membresías, rondas y extensiones, sin alterar las cuentas existentes.
2. Implementar autorización y control de días en servidor; 90 + 30 + 30, máximo una cuenta por correo verificado.
3. Probar proyectos profesional y personal, aislamiento entre cuentas y protección de datos.
4. Verificar correo y recuperación de acceso, protección contra abuso y revisión legal.
5. Probar en entorno separado antes de publicar; no habilitar pagos ni cargos automáticos.

No introducir datos personales de clientes ni compañías en proyectos o feedback.
