# V12-147 — Your Closing Workspace

Se conserva la base V12-146. Corrección del procedimiento automatizado de prueba: seleccionar «+ Create a New Project» antes de crear CASE B. No se modificó la lógica de la página para resolver el bloqueo.

Pruebas ejecutadas localmente:
- v12_independent_email_e2e_test.py: PASS (Table 01, Table 02, Both, drafts, confirmations, isolation)
- v12_workspace_isolation_test.py: PASS
- v12_draft_isolation_test.py: PASS
- v12_integrity_test.py: PASS

No desplegado en Cloudflare; no probado con datos reales de D1.
