# V12-211 · Registration safety tests

Se añaden pruebas de restricciones de D1/SQLite **sin modificar el esquema ni activar registro**. Se comprueba que una cuenta con historial de prueba no puede borrarse físicamente bajo el esquema actual, que el estado `closed` conserva el correo y la restricción de una sola prueba, y que las claves foráneas y categorías se respetan. Se simulan escrituras consecutivas desde conexiones distintas; **no** es una prueba de concurrencia simultánea ni de autenticación.

Pendiente: definir retención/borrado de datos y mecanismo proporcionado de prevención de abuso con asesoramiento de privacidad; implementar verificación de email, expiración/consumo atómico de tokens y sesiones del lado servidor. No habilitar Cloudflare, pagos o registro real.
