# V12-212 — Pruebas locales de tokens de verificación

Se añadió `tests/v12_email_token_contract_test.py` sin alterar páginas ni APIs. Comprueba el contrato SQL propuesto para hash de token, rechazo de token incorrecto, consumo único, vencimiento, cuenta cerrada y borrado en cascada. **No es un endpoint real** ni demuestra envío de email, sesiones seguras, resistencia a ataques o activación de 90 días. La prueba usa una implementación de referencia aislada en SQLite para identificar las condiciones que debe implementar posteriormente el Worker.
