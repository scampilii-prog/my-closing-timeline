# V12-140 — Navegación local unificada

- Home, Real Estate Guided, Business & Projects, Services & Contractors, Personal & Home, Plans, Help & Contact y Privacy enlazan a archivos de este mismo paquete.
- Las categorías sin funcionalidad real se muestran como vistas informativas claramente identificadas; no se envía a páginas antiguas de producción.
- Las páginas nuevas utilizan el header, footer y controles compartidos de `shared/shell.js`.
- Se conserva Real Estate Guided sin modificar su lógica interna.
- No se ha implementado registro, cobros, proyectos de otras categorías ni envío de mensajes.
- Las pruebas aquí son de integridad de archivos y referencias; falta la prueba interactiva en Chrome.
