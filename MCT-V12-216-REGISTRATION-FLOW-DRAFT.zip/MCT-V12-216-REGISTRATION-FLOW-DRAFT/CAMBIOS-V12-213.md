# V12-213 · Contrato transaccional de activación

Se añade una prueba local SQLite de transacción única para consumo de token, activación de cuenta y concesión de 90 días. Comprueba rollback tras error, reintento, replay y vencimiento. No es un endpoint real, no prueba concurrencia simultánea ni envío de correo. No se modifican páginas ni Cloudflare.
