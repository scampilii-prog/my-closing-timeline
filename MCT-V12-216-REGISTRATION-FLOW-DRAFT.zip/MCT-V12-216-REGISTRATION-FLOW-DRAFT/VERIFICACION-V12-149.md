V12-149 · Progress synchronization

Fix: Review & Finish now becomes Completed after a successful Finish action; progress counter updates from actual step status.
Communication Center remains Ready to review unless its own work is completed; pressing Finish does not imply sending email.
No production deployment.
