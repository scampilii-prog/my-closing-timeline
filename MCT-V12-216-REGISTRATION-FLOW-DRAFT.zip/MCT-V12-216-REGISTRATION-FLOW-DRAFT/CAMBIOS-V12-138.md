# V12-138 — Identidad del asistente y menú

- Botón exterior y atributos accesibles: **Ask Timeline**, en vez de Ask Lía.
- Encabezado del panel: **Ask Timeline**, sin nombre alternativo.
- Menú de Services & Contractors y Personal & Home: **Preview · Not available**, sin referencias a una versión anterior.
- Se conserva el diseño Home de cuatro categorías, el programa Founding Members como vista informativa y las funciones de V12-137.
- Sin cambios en GitHub ni producción.
