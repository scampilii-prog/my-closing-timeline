V12-189: Aumentado el tamaño de las respuestas de FAQ a 17–19px. Sin cambios en preguntas, planes ni funciones.
