/* V12-105 · Selection review cue. Presentation only; does not change task data. */
(() => {
  function init(kind, number) {
    const section = document.getElementById(kind + '-section');
    const count = document.getElementById(kind + '-count');
    const summary = document.getElementById(kind + '-summary');
    if (!section || !count || !summary) return;
    const cue = document.createElement('div');
    cue.className = 'mct-review-cue';
    cue.hidden = true;
    cue.setAttribute('role', 'status');
    cue.innerHTML = '<div class="mct-review-cue-message"><strong></strong><span>Your Closing Timeline Summary is ready below. Select more tasks or review now.</span></div><button type="button" class="mct-review-cue-action">↓ Review Selected Tasks</button>';
    const navigation = section.querySelector('.re-table-navigation');
    const heading = section.querySelector('.mct-table-mode-heading');
    (navigation || heading || section.querySelector('.re-table-wrap')).before(cue);
    cue.querySelector('button').addEventListener('click', () => {
      if (summary.hidden) {
        const toggle = section.querySelector('[data-summary-toggle="' + kind + '"]');
        if (toggle) toggle.click();
      }
      if (!summary.hidden) {
        // Align the summary heading, not merely the summary container.
        // Full View scrolls inside its own panel; the compact view scrolls the page.
        const title = summary.querySelector('.re-summary-heading') || summary;
        const panel = section.classList.contains('mct-expanded-table') ? section : null;
        if (panel) {
          const top = title.getBoundingClientRect().top - panel.getBoundingClientRect().top + panel.scrollTop;
          panel.scrollTo({top: Math.max(0, top - 36), behavior: 'smooth'});
        } else {
          const dock = document.getElementById('mct-persistent-dashboard');
          const header = document.getElementById('shared-header');
          const offset = Math.max(header?.getBoundingClientRect().bottom || 0, dock?.getBoundingClientRect().bottom || 0) + 28;
          const y = window.scrollY + title.getBoundingClientRect().top - offset;
          window.scrollTo({top:Math.max(0,y),behavior:'smooth'});
        }
        summary.setAttribute('tabindex','-1');
        summary.focus({preventScroll:true});
      }
    });
    function refresh() {
      const selected = [...section.querySelectorAll('#' + kind + '-rows > tr > td:first-child input[type="checkbox"]')].filter(x => x.checked).length;
      cue.hidden = selected === 0;
      if (selected) cue.querySelector('strong').textContent = selected + (selected === 1 ? ' task selected · Table ' : ' tasks selected · Table ') + number;
    }
    const observer = new MutationObserver(refresh);
    observer.observe(count, {childList:true, characterData:true, subtree:true});
    section.addEventListener('change', e => {if (e.target.matches('input[type="checkbox"]')) queueMicrotask(refresh)});
    refresh();
  }
  function start() {init('contract','01');init('follow','02')}
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
