/* V11-140: visual guide only. Existing application handlers remain unchanged. */
(()=>{
 const $=id=>document.getElementById(id);
 const descriptions={
 'ws-open':'Load the selected saved workspace, including its role, dates and task records. Selecting a name alone does not open it.',
 'ws-new':'Create a separate workspace with the name entered in Workspace / project name. Your other projects remain unchanged.',
 'ws-save':'Save the workspace settings and recalculate task deadlines from the effective and closing dates. Continue to MY TASKS after saving.',
 'ws-clear-dates':'Clear the effective and closing dates in the form. This does not delete the workspace; save to keep changes.',
 'ws-delete':'Delete the selected saved workspace and its records after confirmation. This cannot be undone.',
 'contact-new':'Start entering a new contact without deleting existing saved contacts.',
 'contact-library-toggle':'Show or hide your saved contact list and management controls.',
 'contact-save':'Save this contact in the local browser contact library for reuse.',
 'contact-remove':'Delete the selected contact from the local browser contact library.',
 'email-save':'Save the subject and message as a draft for later editing.',
 'email-clear-subject':'Clear the subject field only; leave the message unchanged.',
 'email-clear-message':'Clear the message body only; leave the subject unchanged.',
 'email-preview':'Preview the selected confirmed task table and the message before preparing an email.',
 'email-copy':'Copy the selected tasks in a formatted table to paste into your email application.',
 'email-open':'Open an email draft in your email application. You must review and send it yourself.',
 'email-pdf':'Open your browser print dialog to save a PDF copy for your private records.',
 'follow-skip':'Skip the optional follow-up table and proceed to Communication Center.',
 'contract-select-all':'Check or uncheck all tasks in Table 01.',
 'follow-select-all':'Check or uncheck all tasks in Table 02.'
 };
 const byAction={
 'add':'Add a custom task to this table; fill in its details before using it.',
 'select':'Select all available tasks in this table for review.',
 'clear':'Clear task selections without deleting the tasks.',
 'sort':'Sort this table by its task due dates.',
 'restore':'Restore the original task template for this table. Review before replacing edits.',
 'save-table':'Save this table as a reusable local table version.',
 'load-table':'Load a previously saved table version.',
 'delete-table':'Delete a saved table version; this does not delete the entire workspace.',
 'summary-toggle':'Open or close the summary showing the tasks selected in this table.',
 'continue':'Continue to the next section after confirming the selected tasks.'
 };

 document.querySelectorAll('.re-main button').forEach(b=>{
  const action=Object.keys(byAction).find(k=>b.hasAttribute('data-'+k));
  const description=descriptions[b.id] || (action ? byAction[action] : '');
  if(description){b.title=description;b.setAttribute('aria-description',description)}
 });
 document.querySelectorAll('#contract-confirm,#follow-confirm').forEach(el=>{el.title='Confirm the selected tasks in this table before continuing or preparing an email.'});
 const setup=$('setup'),communication=$('communication');
 const fieldHelp={
 'ws-list':'Select an existing workspace, then click Open Workspace, or click Create New Workspace.',
 'ws-name':'Displays the selected workspace name. Enter or edit the name when creating a new project.',
 'ws-role':'Choose your role in this transaction.',
 'ws-ed':'Choose the effective date stated in the signed contract.',
 'ws-cd':'Choose the closing date stated in the signed contract.',
 'ws-counting':'Choose how deadlines are counted under your contract.',
 'email-table':'Choose which confirmed table to prepare for this email.',
 'contact-list':'Choose a saved contact, or + Create New Contact.',
 'contact-name':'Enter the contact name if creating a new contact.',
 'contact-email':'Enter the contact email address.',
 'email-to':'Confirm the email recipient before opening the draft.',
 'email-role':'Choose the recipient’s relationship to this transaction.',
 'role-other':'Describe the custom relationship.',
 'email-subject':'Review or edit the email subject.',
 'email-message':'Review or edit the message before sending.'
 };
 Object.entries(fieldHelp).forEach(([id,help])=>{const field=$(id);if(field&&!field.title)field.title=help;});
 function setActive(control){
  document.querySelectorAll('.re-main .v140-active').forEach(el=>el.classList.remove('v140-active'));
  document.querySelectorAll('.re-main .v140-active-field').forEach(el=>el.classList.remove('v140-active-field'));
  if(!control||control.disabled||control.hidden)return;
  if(control.matches('input,select,textarea'))control.closest('label')?.classList.add('v140-active-field');
  else control.classList.add('v140-active');
 }
 function update(){
  const wizard=communication?.querySelector('.re-email label.re-wizard-current input, .re-email label.re-wizard-current select, .re-email label.re-wizard-current textarea');
  const guided=setup?.querySelector('label.re-guided-field input,label.re-guided-field select');
  const wizardButton=communication?.querySelector('button.re-wizard-button:not(:disabled)');
  const setupButton=setup?.querySelector('button.re-guide-action:not(:disabled)');
  const communicationVisible=location.hash==='#communication'||(document.activeElement&&communication?.contains(document.activeElement));
  const setupVisible=location.hash==='#setup'||(document.activeElement&&setup?.contains(document.activeElement));
  let target;
  if(communicationVisible)target=wizard||wizardButton||$('email-table');
  else if(setupVisible)target=guided||setupButton;
  else {
   const pending=[...document.querySelectorAll('.re-continue button.re-next-action:not(:disabled),.re-review-bar button.re-next-action:not(:disabled)')];
   target=pending[0]||guided||setupButton||wizard||wizardButton;
  }
  setActive(target||null);
  const activeSection=target?.closest('#setup,#contract-section,#follow-section,#communication');
  document.querySelectorAll('#setup,#contract-section,#follow-section,#communication').forEach(section=>section.classList.toggle('v141-current-section',section===activeSection));
 }
 document.addEventListener('click',()=>setTimeout(update,100));
 document.addEventListener('change',()=>setTimeout(update,100));
 document.addEventListener('input',()=>setTimeout(update,130));
 window.addEventListener('hashchange',()=>setTimeout(update,100));
 setTimeout(update,350);
})();
