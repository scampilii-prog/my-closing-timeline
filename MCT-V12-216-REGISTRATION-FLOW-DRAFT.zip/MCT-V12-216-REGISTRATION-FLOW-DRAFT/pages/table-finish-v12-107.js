/* V12-107: confirming in expanded view closes it and returns to the same table. */
(function(){'use strict';
 function onConfirm(kind){
   var box=document.getElementById(kind+'-confirm');
   var section=document.getElementById(kind+'-section');
   if(!box||!section)return;
   box.addEventListener('change',function(){
     if(!box.checked||!section.classList.contains('mct-expanded-table'))return;
     /* Let the existing confirmation and summary listeners finish first. */
     setTimeout(function(){
       if(!box.checked)return;
       if(typeof window.MCTCloseFullTableView==='function')window.MCTCloseFullTableView(kind);
       var bar=section.querySelector('.re-review-bar');
       if(bar)bar.scrollIntoView({behavior:'smooth',block:'center'});
     },30);
   });
 }
 function init(){onConfirm('contract');onConfirm('follow');}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
