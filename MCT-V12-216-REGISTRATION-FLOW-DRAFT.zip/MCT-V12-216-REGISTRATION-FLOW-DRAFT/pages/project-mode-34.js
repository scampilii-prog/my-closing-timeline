/* V12-34: one selector determines existing vs new workspace. */
(()=>{
 const list=document.getElementById('ws-list'),name=document.getElementById('ws-name');
 const naming=document.querySelector('#setup .mct-setup-naming');
 const chooser=document.querySelector('#setup .mct-setup-chooser');
 const open=document.getElementById('ws-open'),del=document.getElementById('ws-delete');
 if(!list||!name||!naming||!chooser)return;
 const update=()=>{
   const isNew=list.value==='__new__',isExisting=!!list.value&&!isNew;
   naming.hidden=!isNew;
   open.hidden=!isExisting;
   del.hidden=!isExisting;
   name.readOnly=!isNew;
   name.classList.toggle('mct-name-locked',!isNew);
   if(isNew){name.placeholder='Enter a unique project name';}
   chooser.classList.toggle('mct-choose-new',isNew);
 };
 list.addEventListener('change',()=>{update();if(list.value==='__new__')setTimeout(()=>name.focus(),20)});
 document.getElementById('ws-new')?.addEventListener('click',()=>setTimeout(update,50));
 del?.addEventListener('click',()=>setTimeout(update,100));
 update();
})();
