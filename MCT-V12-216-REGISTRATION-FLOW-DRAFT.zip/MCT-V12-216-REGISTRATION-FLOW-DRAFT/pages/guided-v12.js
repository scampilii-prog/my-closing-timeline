(function(){
'use strict';
document.body.classList.add('mct-guided');
// Reserve the exact header height while pinning the header to the viewport.
const siteHeader=document.getElementById('shared-header');
if(siteHeader){
 const syncSiteHeader=()=>document.documentElement.style.setProperty('--mct-site-header-height',Math.ceil(siteHeader.getBoundingClientRect().height)+'px');
 syncSiteHeader();
 window.addEventListener('resize',syncSiteHeader);
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(syncSiteHeader).observe(siteHeader);
}

const names=['Workspace','Contract Tasks','Follow-Up Tasks','Communication Center','Review & Continue'];
const descriptions=['Create or open a project and enter the contract dates.','Select contract deadlines and confirm the tasks you want to share.','Organize follow-ups independently. This table is optional.','Choose a table, recipient and message; review before sending.','Your project remains available in this browser. You can return to any step.'];
let step=0;
const sidebar=document.createElement('aside');sidebar.id='mct-guide-sidebar';sidebar.setAttribute('aria-label','Workflow steps');
sidebar.innerHTML='<h2>Real Estate & Closing</h2><div class="mct-status-legend" aria-label="Step status legend"><span><i class="mct-dot complete"></i>Completed</span><span><i class="mct-dot current"></i>Current step</span></div><div class="mct-guide-items">'+names.map((n,i)=>'<button type="button" class="mct-guide-item" data-guide-item="'+i+'"><span class="mct-guide-num">'+(i+1)+'</span><div><strong>'+n+'</strong><small>'+descriptions[i]+'</small></div></button>').join('')+'</div><div id="mct-guide-note"></div>';
const main=document.querySelector('.re-main');
// V12-68: one title element, one location, for all five stages.
const sharedStageTitle=document.createElement('h2');
sharedStageTitle.id='mct-unified-stage-title';
sharedStageTitle.setAttribute('aria-live','polite');
sharedStageTitle.textContent='Manage Your Workspaces';
const firstStage=main.querySelector('#setup');
if(firstStage)main.insertBefore(sharedStageTitle,firstStage);
const stageTitles=['Manage Your Workspaces','Contract Tasks & Deadlines','Follow-Up Tasks','Communication Center','Review & Continue'];

// Keep the five live indicators in one persistent, project-aware toolbar.
// Move the ORIGINAL nodes (not copies), so the existing counters and popovers remain wired.
const dashboard=document.querySelector('#setup .re-dual-days');
if(dashboard){
  const strip=document.createElement('section');
  strip.id='mct-persistent-dashboard';
  strip.setAttribute('aria-label','Live closing status for the active workspace');
  strip.append(dashboard);
  main.querySelector('.re-muted').after(strip);
  const explanations={
    'ws-calendar-days':'Calendar days between the Effective Date and Closing Date, including weekends.',
    'ws-business-days':'Weekdays (Monday–Friday) between the Effective Date and Closing Date; holidays are not excluded.',
    'today':'View incomplete tasks due today in both tables.',
    'tomorrow':'View incomplete tasks due tomorrow in both tables.',
    'overdue':'View incomplete tasks past their due date in both tables.'
  };
  dashboard.querySelectorAll('.re-day-tile').forEach((tile,i)=>{
    tile.title=explanations[i===0?'ws-calendar-days':'ws-business-days'];
    tile.setAttribute('aria-label',tile.title);
  });
  dashboard.querySelectorAll('[data-daily-open]').forEach(button=>{
    button.title=explanations[button.dataset.dailyOpen];
    button.setAttribute('aria-haspopup','dialog');
  });
  const updateHeaderGap=()=>{
    const header=document.getElementById('shared-header');
    document.documentElement.style.setProperty('--mct-guide-header-height',
      (header ? Math.ceil(header.getBoundingClientRect().height) : 72)+'px');
  };
  window.addEventListener('resize',updateHeaderGap);
  requestAnimationFrame(updateHeaderGap);
  dashboard.querySelectorAll('[data-daily-open]').forEach(button=>{
    button.setAttribute('aria-expanded','false');
    button.setAttribute('aria-label',button.dataset.dailyOpen+' tasks: open details');
  });

}
// V12-21: pin title and all five live indicators together to the viewport.
// A reserved spacer prevents content jumping or disappearing beneath the toolbar.
const breadcrumb=main.querySelector('.re-breadcrumb');
const heading=main.querySelector('.mct-workspace-heading');
const persistent=document.getElementById('mct-persistent-dashboard');
if(heading && persistent){
  const dock=document.createElement('div');dock.id='mct-fixed-status-dock';
  const spacer=document.createElement('div');spacer.id='mct-fixed-status-spacer';
  main.insertBefore(spacer,breadcrumb || heading);
  if(breadcrumb) dock.append(breadcrumb);
  dock.append(heading,persistent);
  document.body.append(dock);
  function placeDock(){
    const header=document.getElementById('shared-header');
    const rect=main.getBoundingClientRect();
    const h=header?header.getBoundingClientRect().height:72;
    dock.style.top=Math.ceil(h+12)+'px';
    dock.style.left=Math.round(rect.left)+'px';
    dock.style.width=Math.round(rect.width)+'px';
    spacer.style.height=Math.ceil(dock.getBoundingClientRect().height+5)+'px';
  }
  window.addEventListener('resize',placeDock);
  window.addEventListener('orientationchange',placeDock);
  requestAnimationFrame(placeDock);
  document.fonts?.ready?.then(placeDock);
  // Recalculate after the two-column layout is actually mounted.
  window.addEventListener('load',placeDock);
}
const layout=document.createElement('div');layout.className='mct-guide-layout';
main.before(layout);layout.append(sidebar,main);
const refreshDock=()=>{const dock=document.getElementById('mct-fixed-status-dock');const spacer=document.getElementById('mct-fixed-status-spacer');if(!dock||!spacer)return;const header=document.getElementById('shared-header');const r=main.getBoundingClientRect();const h=header?header.getBoundingClientRect().height:72;dock.style.top=Math.ceil(h+12)+'px';dock.style.left=Math.round(r.left)+'px';dock.style.width=Math.round(r.width)+'px';spacer.style.height=Math.ceil(dock.getBoundingClientRect().height+5)+'px';document.documentElement.style.setProperty('--mct-dock-bottom',Math.ceil(h+12+dock.getBoundingClientRect().height+16)+'px');};
requestAnimationFrame(refreshDock);window.addEventListener('resize',refreshDock);window.addEventListener('load',refreshDock);
// V12-24: measure the actual counter strip and anchor the left guide to it.
const alignSidebarToCounters=()=>{
  if(window.innerWidth<=950)return;
  const grid=document.querySelector('.mct-guide-layout');
  const counters=document.querySelector('#mct-persistent-dashboard');
  if(!grid||!counters)return;
  const gr=grid.getBoundingClientRect(), cr=counters.getBoundingClientRect();
  const gridStyles=getComputedStyle(grid);
  const leftPad=parseFloat(gridStyles.paddingLeft)||0;
  const cols=gridStyles.gridTemplateColumns.split(' ');
  const width=parseFloat(cols[0])||232;
  document.documentElement.style.setProperty('--mct-counter-top',Math.round(cr.top)+'px');
  document.documentElement.style.setProperty('--mct-sidebar-left',Math.round(gr.left+leftPad)+'px');
  document.documentElement.style.setProperty('--mct-sidebar-width',Math.round(width)+'px');
};
requestAnimationFrame(alignSidebarToCounters);
window.addEventListener('resize',()=>requestAnimationFrame(alignSidebarToCounters));
window.addEventListener('load',()=>requestAnimationFrame(alignSidebarToCounters));

if(typeof ResizeObserver!=='undefined'){new ResizeObserver(refreshDock).observe(main);}
const finish=document.createElement('section');finish.id='mct-guide-finish';finish.innerHTML='<h1>Review & Continue</h1><p>Your workspace, contract tasks, follow-up tasks and Communication Center are available in this guided layout. Use the steps on the left to review or edit any information.</p><p><strong>Important:</strong> This is a local prototype. Email opens in your own mail app; it does not send messages automatically. Dates and deadlines must follow the signed contract.</p><div id="mct-finish-status" role="status" aria-live="polite"></div>';
document.querySelector('.re-main').append(finish);
const bottom=document.createElement('div');bottom.id='mct-guide-bottom';bottom.innerHTML='<span id="mct-guide-feedback" aria-live="polite"></span><button class="mct-guide-back" type="button" id="mct-guide-back">Back</button><button class="mct-guide-primary" type="button" id="mct-guide-next">Next →</button>';
document.getElementById('shared-footer').before(bottom);
function go(n){const previousStep=step;step=Math.max(0,Math.min(4,n));sharedStageTitle.textContent=stageTitles[step];const stageHeading=document.querySelector('#tasks > h2');if(stageHeading){stageHeading.textContent=step===2?'Follow-Up Tasks':'Contract Tasks & Deadlines';} document.body.dataset.guideStep=step;sidebar.querySelectorAll('[data-guide-item]').forEach((el,i)=>{const complete=i===0&&setupComplete();el.classList.toggle('active',i===step);el.classList.toggle('done',complete);el.setAttribute('aria-current',i===step?'step':'false');el.setAttribute('aria-label',(i+1)+'. '+names[i]+': '+(complete?'Completed':i===step?'Current step':'Not completed'));});document.getElementById('mct-guide-note').textContent=descriptions[step];document.getElementById('mct-guide-back').disabled=step===0;document.getElementById('mct-guide-next').textContent=step===4?'Finish':'Next →';document.getElementById('mct-guide-feedback').textContent='Step '+(step+1)+' of 5 · '+names[step];window.scrollTo({top:0,behavior:'instant'});requestAnimationFrame(()=>{refreshDock();window.scrollTo(0,0);});if(typeof updateNextAvailability==='function')updateNextAvailability();if(step===3&&previousStep!==3)document.dispatchEvent(new Event('mct-communication-entry'));}
document.getElementById('mct-guide-back').addEventListener('click',()=>go(step-1));
const nextButton=document.getElementById('mct-guide-next');
const setupComplete=()=>{
 const saved=document.getElementById('ws-save');
 const list=document.getElementById('ws-list');
 const name=document.getElementById('ws-name');
 const role=document.getElementById('ws-role');
 const ed=document.getElementById('ws-ed');
 const cd=document.getElementById('ws-cd');
 // The saved button is set only after a successful save or loading an unchanged saved workspace.
 // The selector can be reset independently by refreshSetup(), so it is not a reliable
 // source of completion status. Never mark complete on navigation alone.
 const savedAndApplied=!!saved?.classList.contains('re-setup-saved');
 const hasValidFields=!!(name?.value.trim() && role?.value && ed?.value && cd?.value && cd.value>=ed.value);
 const selectedOtherWorkspace=!!(list?.value && list.value!=='__new__' && list.value!==name?.value.trim());
 return savedAndApplied && hasValidFields && !selectedOtherWorkspace;
};
function updateNextAvailability(){
 nextButton.disabled=false;
 nextButton.setAttribute('aria-disabled','false');
 nextButton.title='View the next step. Saving and sending still require the necessary project information.';
}
// Every section can be explored; data-changing actions remain governed by the original workspace validation.

// The first step is not completed merely by selecting a project name.
nextButton.addEventListener('click',()=>{
 if(step!==4){go(step+1);return;}
 const status=document.getElementById('mct-finish-status');
 if(!setupComplete()){
  status.innerHTML='<strong>Workspace incomplete.</strong> Create or open a project, choose your role, enter valid contract dates, and save/apply the setup before finishing. You may still explore every step.';
  status.className='mct-finish-warning';
  status.scrollIntoView({block:'nearest',behavior:'smooth'});
  return;
 }
 status.innerHTML='<strong>✓ Review finished.</strong> Your saved workspace remains available. This confirms your review, not the real-estate closing or the sending of any email.';
 status.className='mct-finish-success';
 nextButton.textContent='Finished ✓';
 nextButton.disabled=true;
 status.scrollIntoView({block:'nearest',behavior:'smooth'});
});
['click','change','input'].forEach(type=>document.getElementById('setup')?.addEventListener(type,()=>setTimeout(updateNextAvailability,60)));
const setupObserver=new MutationObserver(updateNextAvailability);
setupObserver.observe(document.getElementById('ws-save'),{attributes:true,attributeFilter:['class']});
updateNextAvailability();
const refreshStepStates=()=>{sidebar.querySelectorAll('[data-guide-item]').forEach((el,i)=>{const complete=i===0&&setupComplete();el.classList.toggle('done',complete);el.setAttribute('aria-label',(i+1)+'. '+names[i]+': '+(complete?'Completed':i===step?'Current step':'Not completed'));});};
['click','change','input'].forEach(type=>document.getElementById('setup')?.addEventListener(type,()=>setTimeout(refreshStepStates,70)));
setupObserver.disconnect();setupObserver.observe(document.getElementById('ws-save'),{attributes:true,attributeFilter:['class']});

sidebar.querySelectorAll('[data-guide-item]').forEach(el=>{el.style.cursor='pointer';el.addEventListener('click',()=>{const destination=Number(el.dataset.guideItem);go(destination)})});
document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(!a)return;const id=a.getAttribute('href');const map={'#setup':0,'#tasks':1,'#contract-section':1,'#follow-section':2,'#communication':3};if(id in map){e.preventDefault();go(map[id]);}});
// Reflect changes made in either task table immediately in the three daily indicators.
// The application already recalculates them in render(); also refresh after edits
// and when the browser resumes, without changing or saving user data here.
const counterNodes=['daily-total-today','daily-total-tomorrow','daily-total-overdue'];
const counters=document.getElementById('mct-persistent-dashboard');
if(counters){
 const announce=document.createElement('span');announce.id='mct-live-counter-note';announce.className='mct-sr-only';announce.setAttribute('role','status');announce.setAttribute('aria-live','polite');counters.append(announce);
 let previous=counterNodes.map(id=>document.getElementById(id)?.textContent||'0').join('|');
 const observer=new MutationObserver(()=>{
   const now=counterNodes.map(id=>document.getElementById(id)?.textContent||'0').join('|');
   if(now!==previous){previous=now;announce.textContent='Task status updated: '+counterNodes.map((id,i)=>['Today','Tomorrow','Overdue'][i]+' '+(document.getElementById(id)?.textContent||'0')).join(', ');}
 });
 counterNodes.forEach(id=>{const el=document.getElementById(id);if(el)observer.observe(el,{childList:true,characterData:true,subtree:true});});
}
// Do not imply that merely visiting a step completes it.
const hint=document.getElementById('mct-guide-note');
if(hint)hint.setAttribute('aria-live','polite');
go(0);
})();
