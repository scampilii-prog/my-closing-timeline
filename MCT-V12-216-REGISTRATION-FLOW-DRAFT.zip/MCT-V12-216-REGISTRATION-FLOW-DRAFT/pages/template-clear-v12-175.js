/* V12-176: visible, functional library controls; templates are independent of workspaces. */
(function(){function init(){['contract','follow'].forEach(function(w){
 const panel=document.getElementById(w+'-template-library');if(!panel)return;
 const picker=document.getElementById(w+'-template-select');
 const form=document.getElementById(w+'-template-new');
 const input=document.getElementById(w+'-template-name');
 const save=form.querySelector('[data-template-save]');
 const rename=panel.querySelector('.mct-template-rename');
 const renameSave=panel.querySelector('.mct-template-rename-save');
 const label=form.querySelector('label');label.firstChild.textContent='Template Name';
 function sync(){
   const value=picker.value, saved=value.startsWith('saved:'),creating=value==='create';
   form.hidden=!(saved||creating);
   input.disabled=!(saved||creating);
   if(creating){input.placeholder='Enter a name for your template';}
   if(saved){input.placeholder='Template name';}
   if(rename){rename.disabled=!saved;rename.title=saved?'Rename this saved template':'Select a saved template to rename';}
   if(!saved&&!creating){if(renameSave)renameSave.hidden=true;}
   if(save&&creating)save.textContent='Save New Template';
   if(save&&saved)save.textContent='Save Template Changes';
 }
 picker.addEventListener('change',()=>{sync();setTimeout(sync,0);});
 save.addEventListener('click',()=>setTimeout(sync,0));
 renameSave?.addEventListener('click',()=>setTimeout(sync,0));
 sync();
 });}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
