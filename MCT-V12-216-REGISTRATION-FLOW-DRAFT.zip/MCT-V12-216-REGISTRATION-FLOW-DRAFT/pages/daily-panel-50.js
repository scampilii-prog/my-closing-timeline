(()=>{
'use strict';
const pop=document.getElementById('daily-popover');
if(!pop)return;
const printBtn=document.getElementById('daily-print');
const emailBtn=document.getElementById('daily-email');
printBtn?.addEventListener('click',()=>{
 const title=document.getElementById('daily-popover-title')?.textContent||'Daily tasks';
 const entries=[...pop.querySelectorAll('.re-daily-entry')].map(e=>e.innerText.trim());
 const lines=entries.length?entries:['No pending tasks in this category.'];
 const w=window.open('','_blank');
 if(!w){window.alert('Please allow pop-ups to print this task list.');return;}
 const d=w.document;d.title=title;
 const style=d.createElement('style');style.textContent='body{font:15px Arial,sans-serif;color:#183449;margin:32px}h1{font-size:23px;border-bottom:2px solid #36757c;padding-bottom:12px}li{margin:15px 0;white-space:pre-line}';d.head.append(style);
 const h=d.createElement('h1');h.textContent=title;d.body.append(h);const ul=d.createElement('ul');
 lines.forEach(line=>{const li=d.createElement('li');li.textContent=line;ul.append(li)});d.body.append(ul);
 const note=d.createElement('p');note.textContent='Verify all dates against the signed contract.';d.body.append(note);
 w.focus();w.print();
});
emailBtn?.addEventListener('click',()=>{
 const close=document.getElementById('daily-popover-close');close?.click();
 const target=document.getElementById('communication');
 if(target){target.scrollIntoView({behavior:'smooth',block:'start'});}
 const select=document.getElementById('email-table');select?.focus({preventScroll:true});
});
})();
