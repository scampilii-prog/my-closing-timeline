/* V12-135: contextual note within Table 02 library, preserving original controls. */
(function(){
  function arrange(){
    var library=document.getElementById('follow-template-library');
    var note=document.querySelector('#follow-section > .re-optional-note');
    if(!library || !note)return;
    var utilities=library.querySelector('.re-library-utilities');
    if(utilities) utilities.insertAdjacentElement('afterend',note);
    else library.appendChild(note);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',arrange);
  else arrange();
})();
