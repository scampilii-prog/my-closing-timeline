/* V12-103: expand one table temporarily without cloning or rebuilding task rows. */
(function(){'use strict';
var active=null;
function close(){if(!active)return;var section=document.getElementById(active+'-section');if(section)section.classList.remove('mct-expanded-table');document.body.classList.remove('mct-table-fullview');var btn=document.querySelector('[data-fullview="'+active+'"]');if(btn){btn.textContent='⛶ Full Table View';btn.setAttribute('aria-pressed','false');btn.focus()}active=null;}
document.querySelectorAll('[data-fullview]').forEach(function(btn){btn.addEventListener('click',function(){var kind=btn.dataset.fullview;if(active===kind){close();return;}close();var section=document.getElementById(kind+'-section');if(!section)return;active=kind;section.classList.add('mct-expanded-table');document.body.classList.add('mct-table-fullview');btn.textContent='✕ Close Full View';btn.setAttribute('aria-pressed','true');section.scrollTop=0;var wrap=section.querySelector('.re-table-wrap');if(wrap)wrap.scrollLeft=0;});});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&active)close()});
/* Public close hook for the completion flow; the original button remains the single source of truth. */
window.MCTCloseFullTableView=function(kind){if(active && (!kind||kind===active)){close();return true;}return false;};
})();
