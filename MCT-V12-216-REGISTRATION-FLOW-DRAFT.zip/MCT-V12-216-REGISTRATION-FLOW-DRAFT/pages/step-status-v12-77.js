/* V12-77: truthful, three-line step summaries; no persistence or workflow mutation. */
(()=>{'use strict';
const sidebar=document.getElementById('mct-guide-sidebar');if(!sidebar)return;
const steps=[...sidebar.querySelectorAll('[data-guide-item]')];
const $=id=>document.getElementById(id);
const selected=key=>document.querySelectorAll('#'+key+'-rows input[type="checkbox"]:checked').length;
const workspaceReady=()=>{const name=$('ws-name'),role=$('ws-role'),ed=$('ws-ed'),cd=$('ws-cd'),saved=$('ws-save'),list=$('ws-list');return !!(name?.value.trim()&&role?.value&&ed?.value&&cd?.value&&cd.value>=ed.value&&saved?.classList.contains('re-setup-saved')&&!(list?.value&&list.value!=='__new__'&&list.value!==name.value.trim()));};
const data=[
 {todo:'Create or open a project and enter the dates.',missing:'Select a project, role and dates; save the setup.'},
 {todo:'Select and confirm contract deadlines.',missing:'Complete Workspace before confirming deadlines.'},
 {todo:'Organize follow-up tasks, if needed.',missing:'Optional: select and confirm follow-up tasks.'},
 {todo:'Prepare a recipient and email message.',missing:'Choose a confirmed table and prepare the email.'},
 {todo:'Review your work before continuing.',missing:'Review the project and prepared information.'}
];
steps.forEach((item,i)=>{const label=item.querySelector('.mct-step-label');if(!label)return;label.setAttribute('aria-live','off');const hint=document.createElement('span');hint.className='mct-step-hint';label.after(hint);});
function paint(){
 const ready=workspaceReady(),contractN=selected('contract'),followN=selected('follow');
 const contractDone=ready&&contractN>0&&!!$('contract-confirm')?.checked;
 const followDone=ready&&followN>0&&!!$('follow-confirm')?.checked;
 const emailTable=$('email-table')?.value||'';
 const emailHasTable=emailTable==='contract'?contractDone:emailTable==='follow'?followDone:emailTable==='both'?contractDone&&followDone:false;
 const emailFields=!!($('email-to')?.value.trim()&&$('email-role')?.value&&$('email-subject')?.value.trim()&&$('email-message')?.value.trim());
 const emailReady=ready&&emailHasTable&&emailFields;
 const reviewFinished=ready&&!!$('mct-finish-status')?.classList.contains('mct-finish-success');
 const statuses=[
 ready?['Completed','Workspace saved and dates applied.','done']:['Incomplete',data[0].missing,'incomplete'],
 contractDone?['Completed',contractN+' contract task(s) confirmed.','done']:contractN?['In progress',contractN+' selected · Review and confirm Table 01.','progress']:['Not started',ready?data[1].todo:data[1].missing,'pending'],
 followDone?['Completed',followN+' follow-up task(s) confirmed.','done']:followN?['In progress',followN+' selected · Confirm Table 02 if needed.','progress']:['Not started',data[2].missing,'pending'],
 emailReady?['Ready to review','Recipient and message prepared; preview before sending.','progress']:emailTable?['In progress',emailHasTable?'Complete recipient, role, subject and message.':'Confirm the selected table first.','progress']:['Not started',data[3].missing,'pending'],
 reviewFinished?['Completed','Review finished; this does not send an email or close a transaction.','done']:['Not completed','Review the setup, tasks and email before proceeding.','pending']
 ];
 steps.forEach((item,i)=>{
  const [labelText,hintText,status]=statuses[i],active=item.classList.contains('active');
  const label=item.querySelector('.mct-step-label'),hint=item.querySelector('.mct-step-hint');
  if(!label||!hint)return;
  label.textContent=labelText;
  label.className='mct-step-label mct-v77-'+status;
  hint.textContent=hintText;
  item.classList.toggle('mct-v77-complete',status==='done');
  item.setAttribute('aria-label',(i+1)+'. '+item.querySelector('strong').textContent+'. '+labelText+'. '+hintText);
  // This label represents actual work status, independently of which step is open.
  const num=item.querySelector('.mct-guide-num');if(num)num.textContent=status==='done'?'✓':String(i+1);
 });
}
let scheduled=false;function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;paint()});}
['click','change','input'].forEach(event=>document.addEventListener(event,()=>setTimeout(schedule,90),true));
const obs=new MutationObserver(schedule);
['ws-save','contract-confirm','follow-confirm','email-preview-shortcut','mct-finish-status'].forEach(id=>{const el=$(id);if(el)obs.observe(el,{attributes:true,attributeFilter:['class','disabled','checked']});});
const activeObserver=new MutationObserver(schedule);steps.forEach(el=>activeObserver.observe(el,{attributes:true,attributeFilter:['class']}));
paint();
})();