/* Size sidebar to the active content card, never beyond the bottom navigation. */
(function(){
  function align(){
    if(window.innerWidth<=950)return;
    const side=document.getElementById('mct-guide-sidebar');
    if(!side)return;
    const main=document.querySelector('.mct-guide-layout main');
    if(!main)return;
    const panels=Array.from(main.querySelectorAll('.re-panel'));
    const visible=panels.find(p=>!p.hidden && getComputedStyle(p).display!=='none' && p.getClientRects().length);
    if(!visible)return;
    const sideTop=parseFloat(getComputedStyle(side).top)||side.getBoundingClientRect().top;
    const panelBottom=visible.getBoundingClientRect().bottom;
    const available=window.innerHeight-sideTop-98;
    const desired=Math.max(390,Math.min(available,panelBottom-sideTop));
    if(Number.isFinite(desired)&&desired>0)side.style.setProperty('--mct-sidebar-panel-height',Math.round(desired)+'px');
  }
  function init(){
    align();
    const main=document.querySelector('.mct-guide-layout main');
    if(main && 'ResizeObserver' in window){new ResizeObserver(align).observe(main);}
    if(main && 'MutationObserver' in window){new MutationObserver(align).observe(main,{subtree:true,attributes:true,attributeFilter:['hidden','class','style']});}
    window.addEventListener('resize',align,{passive:true});
    document.addEventListener('click',()=>requestAnimationFrame(align));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
