/* V12-41 · Clear next-field guidance for the workspace step. */
(()=>{
 const root=document.getElementById('setup');
 const list=document.getElementById('ws-list'),open=document.getElementById('ws-open'),create=document.getElementById('ws-new');
 const role=document.getElementById('ws-role'),ed=document.getElementById('ws-ed'),cd=document.getElementById('ws-cd');
 const save=document.getElementById('ws-save'),next=document.getElementById('mct-guide-next');
 if(!root||!list||!role||!ed||!cd||!save||!next)return;
 const banner=document.createElement('p');banner.id='mct-workspace-next-field';banner.setAttribute('aria-live','polite');
 const intro=root.querySelector('.re-help');
 if(intro){intro.after(banner);intro.hidden=true;}
 const targets=[list,role,ed,cd,save];
 function update(){
  targets.concat(next,open).forEach(el=>{el?.classList.remove('mct-current-field','mct-guide-pulse')});
  const isNew=list.value==='__new__';
  const statusText=document.getElementById('ws-status')?.textContent||'';
  const opened=!!document.getElementById('ws-name')?.value &&
    (statusText.startsWith('Active workspace:') || statusText.includes(' is open.') || statusText.includes('saved successfully') || save.classList.contains('re-setup-saved'));
  let target,message;
  if(!list.value){target=list;message='Start here · Select a saved workspace or choose + Create a New Project.';}
  else if(isNew){target=document.getElementById('ws-name');message='New project · Enter its name and select + Create Workspace.';}
  else if(!opened){target=open;message='Next · Click Open Workspace to load the selected project.';}
  else if(!role.value){target=role;message='Next · Choose My role.';}
  else if(!ed.value){target=ed;message='Next · Enter the Effective Date.';}
  else if(!cd.value){target=cd;message='Next · Enter the Closing Date.';}
  else if(cd.value<ed.value){target=cd;message='Check the dates · Closing Date cannot be before Effective Date.';}
  else if(!save.classList.contains('re-setup-saved')){target=save;message='Next · Select Save Setup / Apply Dates.';}
  else {target=next;message='✓ Setup completed · Select the blue Next → button to continue to Contract Tasks.';}
  if(target && !target.classList.contains('mct-current-field'))target.classList.add('mct-current-field');
  // Pulse only the next actionable button; never animate date controls or steal calendar focus.
  if(target && target.tagName==='BUTTON' && !target.disabled)target.classList.add('mct-guide-pulse');
  targets.concat(next,open).forEach(el=>{if(el!==target)el?.classList.remove('mct-guide-pulse')});
  if(banner.textContent!==message)banner.textContent=message;
 }
 function guideToRole(){setTimeout(()=>{update();if(!role.value&&list.value&&list.value!=='__new__'){
   const status=document.getElementById('ws-status')?.textContent||'';
   if(open?.classList.contains('mct-workspace-open')||status.includes(' is open.')||status.startsWith('Active workspace:')){
     role.scrollIntoView({block:'center',behavior:'smooth'});role.focus({preventScroll:true});
   }
 }},130);}
 open?.addEventListener('click',guideToRole);
 open?.addEventListener('click',()=>setTimeout(update,200));
 create?.addEventListener('click',guideToRole);
 [list,role,ed,cd,save].forEach(el=>['change','input'].forEach(ev=>el?.addEventListener(ev,()=>setTimeout(update,100))));
 // Observe only the saved-state class; defer updates to avoid recursive DOM mutations.
 let lastSaved=save.classList.contains('re-setup-saved');
 let pending=false;
 new MutationObserver(mutations=>{
   if(!mutations.some(m=>m.attributeName==='class' && m.target.classList.contains('re-setup-saved')!==lastSaved)){return;}
   lastSaved=save.classList.contains('re-setup-saved');
   if(!pending){pending=true;setTimeout(()=>{pending=false;update();},0);}
 }).observe(save,{attributes:true,attributeFilter:['class']});
 update();
})();
