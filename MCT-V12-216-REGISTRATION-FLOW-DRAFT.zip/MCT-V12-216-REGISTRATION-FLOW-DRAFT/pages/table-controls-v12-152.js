/* V12-152: One primary review action below each table. Existing behavior retained. */
(()=>{'use strict';function start(){for(const kind of ['contract','follow']){
const section=document.getElementById(kind+'-section');if(!section)continue;
const wrap=section.querySelector('.re-table-wrap'),cue=section.querySelector('.mct-review-cue'),button=section.querySelector('.mct-review-cue-action'),bar=section.querySelector('.re-review-bar');
const toggle=section.querySelector('[data-summary-toggle="'+kind+'"]');
const progress=document.getElementById(kind+'-progress');const selected=document.getElementById(kind+'-selected');
if(!wrap||!cue||!button||!bar||!toggle||!progress||!selected)continue;
const actions=document.createElement('div');actions.className='mct-v152-after-table';
const hint=document.createElement('span');hint.className='mct-v152-hint';hint.textContent='Select tasks above to review the tasks you want to share.';
actions.append(hint,button);wrap.after(actions);
button.textContent='↓ Review Selected Tasks';button.classList.add('mct-v152-review');
button.removeAttribute('hidden');
// The original summary navigation remains in the DOM for its handlers, but is not duplicated visually.
toggle.classList.add('mct-v152-original-toggle');toggle.tabIndex=-1;toggle.setAttribute('aria-hidden','true');
const status=document.createElement('div');status.className='mct-v152-task-status';
const statusTitle=document.createElement('span');statusTitle.textContent='Task status';statusTitle.className='mct-v152-status-label';
status.append(statusTitle,progress);bar.after(status);
const update=()=>{const n=section.querySelectorAll('#'+kind+'-rows > tr > td:first-child input[type="checkbox"]:checked').length;
button.disabled=n===0;hint.textContent=n?(n+' selected to share · Review the selected tasks below.'):'Select tasks above to enable review.';};
const count=document.getElementById(kind+'-count');if(count)new MutationObserver(update).observe(count,{childList:true,subtree:true,characterData:true});
section.addEventListener('change',e=>{if(e.target.matches('input[type="checkbox"]'))queueMicrotask(update)});update();
}}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();})();
