/* V11-198: one reliable location indicator for the three workflow stages. */
(()=>{'use strict';
const nav=document.querySelector('.re-progress-nav');if(!nav)return;
// The shared header owns its height; sticky navigation follows its actual rendered size.
const sharedHeader=document.getElementById('shared-header');
function syncHeaderHeight(){if(sharedHeader)document.documentElement.style.setProperty('--mct-header-height',sharedHeader.getBoundingClientRect().height+'px');}
syncHeaderHeight();
if(sharedHeader&&typeof ResizeObserver!=='undefined')new ResizeObserver(syncHeaderHeight).observe(sharedHeader);
window.addEventListener('resize',syncHeaderHeight,{passive:true});
const ids=['setup','tasks','communication'];
const links=Object.fromEntries(ids.map(id=>[id,nav.querySelector('[data-step="'+id+'"]')]));
const $=id=>document.getElementById(id);
let active='setup', lockedUntil=0, pendingFrame=0;
function completed(){
 const ed=$('ws-ed'),cd=$('ws-cd');
 return {setup:!!(ed?.value&&cd?.value&&$('ws-save')?.classList.contains('re-setup-saved')),
 tasks:!!($('contract-confirm')?.checked||$('follow-confirm')?.checked),communication:false};
}
function paint(id){
 active=id;const states=completed();
 ids.forEach(step=>{
  const link=links[step],status=link?.querySelector('.re-step-state');if(!link||!status)return;
  link.classList.toggle('re-is-current',step===id);
  link.classList.toggle('re-is-done',states[step]);
  if(step===id){link.setAttribute('aria-current','location');status.textContent='● YOU ARE HERE'+(states[step]?' · ✓':'');}
  else{link.removeAttribute('aria-current');status.textContent=states[step]?'✓ Done':'To do';}
 });
 nav.classList.toggle('re-tasks-current',id==='tasks');
}
function detected(){
 // The top of the visible content is the bottom of the sticky navigation.
 // Compare viewport coordinates (not a mixed document/viewport offset).
 const edge=nav.getBoundingClientRect().bottom+22;
 let found='setup';
 for(const id of ids){const section=$(id);if(section&&section.getBoundingClientRect().top<=edge)found=id;}
 return found;
}
function update(){if(performance.now()<lockedUntil){paint(active);return;}paint(detected());}
function schedule(){if(pendingFrame)return;pendingFrame=requestAnimationFrame(()=>{pendingFrame=0;update()});}
function navigate(id){
 const target=$(id);if(!target)return;
 // Keep the clicked stage active while the browser finishes scrolling.
 lockedUntil=performance.now()+650;paint(id);
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  // The nav starts in document flow and becomes sticky during scrolling.
  // Its CURRENT bottom is therefore not the final sticky bottom.
  // Use the stable header height plus the nav's own height instead.
  const header=document.getElementById('shared-header');
  const stickyTop=header?.getBoundingClientRect().height||0;
  const desiredTop=stickyTop+nav.getBoundingClientRect().height+(id==='tasks'?10:2);
  const delta=target.getBoundingClientRect().top-desiredTop;
  if(Math.abs(delta)>3)window.scrollBy({top:delta,behavior:'instant'});
  // On pages shorter than the viewport, the target may not reach the top;
  // the explicit user choice still wins until another section is reached.
  paint(id);
 }));
}
nav.querySelectorAll('a[data-step]').forEach(link=>link.addEventListener('click',e=>{
 const id=link.dataset.step;if(!$(id))return;e.preventDefault();
 history.replaceState(null,'','#'+id);navigate(id);
}));
window.addEventListener('load',()=>{
 const id=location.hash.slice(1);
 if(ids.includes(id))navigate(id);else paint(detected());
});
window.addEventListener('scroll',schedule,{passive:true});
window.addEventListener('resize',schedule,{passive:true});
document.addEventListener('change',schedule);
document.addEventListener('click',()=>setTimeout(schedule,80));
const observer=new MutationObserver(schedule);
['ws-status','contract-count','follow-count'].forEach(id=>{const el=$(id);if(el)observer.observe(el,{childList:true,subtree:true,characterData:true})});
paint(detected());
})();
