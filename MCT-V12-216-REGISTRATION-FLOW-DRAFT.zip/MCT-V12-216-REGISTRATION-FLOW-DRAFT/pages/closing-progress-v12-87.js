/* V12-87 — presentation only; existing status calculations and navigation remain authoritative. */
(()=>{'use strict';
const sidebar=document.getElementById('mct-guide-sidebar');if(!sidebar)return;
const title=sidebar.querySelector('h2');if(title)title.textContent='Your Closing Progress';
const legend=sidebar.querySelector('.mct-status-legend');
if(legend){legend.innerHTML='<span class="mct87-subtitle">Stay organized. Stay on track.</span><div class="mct87-progress-row"><div class="mct87-track" role="progressbar" aria-label="Completed workflow stages" aria-valuemin="0" aria-valuemax="5" aria-valuenow="0"><div class="mct87-fill"></div></div><span class="mct87-count">0 of 5</span></div>';}
const steps=[...sidebar.querySelectorAll('[data-guide-item]')];
const titles=['Workspace','Contract Tasks','Follow-Up Tasks','Communication Center','Review & Finish'];
steps.forEach((button,i)=>{const heading=button.querySelector('strong');if(heading)heading.textContent=titles[i];const hint=button.querySelector('.mct-step-hint');if(hint)hint.setAttribute('aria-hidden','true');});
const note=document.getElementById('mct-guide-note');if(note)note.setAttribute('aria-hidden','true');
const motto=document.createElement('div');motto.className='mct87-motto';motto.textContent='Your Clients. Your Records. Your Privacy.';sidebar.append(motto);
const bar=sidebar.querySelector('.mct87-track'),fill=sidebar.querySelector('.mct87-fill'),count=sidebar.querySelector('.mct87-count');
function refresh(){const done=steps.filter((b,i)=>i<4&&b.classList.contains('mct-v77-complete')).length;const completed=Math.min(5,done);bar?.setAttribute('aria-valuenow',String(completed));if(fill)fill.style.width=(completed/5*100)+'%';if(count)count.textContent=completed+' of 5';}
const obs=new MutationObserver(refresh);steps.forEach(b=>obs.observe(b,{attributes:true,attributeFilter:['class']}));
// Status is computed by the existing V12-77 script. Listen to the same input events.
['change','input','click'].forEach(event=>document.addEventListener(event,()=>requestAnimationFrame(refresh),false));
refresh();
})();
