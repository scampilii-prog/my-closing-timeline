/* V12-85: fixed sidebar geometry based on Workspace title + content card.
   Height is measured once from Workspace and remains constant across all five stages. */
(()=>{
 const root=document.documentElement;let raf=0;
 function measure(){
  if(window.innerWidth<=950)return;
  const grid=document.querySelector('.mct-guide-layout');
  const side=document.getElementById('mct-guide-sidebar');
  const heading=document.getElementById('mct-unified-stage-title');
  const setup=document.getElementById('setup');
  if(!grid||!side||!heading||!setup)return;
  const gr=grid.getBoundingClientRect(),hr=heading.getBoundingClientRect();
  const style=getComputedStyle(grid),cols=style.gridTemplateColumns.split(' ');
  const left=Math.round(gr.left+(parseFloat(style.paddingLeft)||0));
  const width=Math.round(parseFloat(cols[0])||232);
  // Sidebar dimensions are independent of the height of any right-hand stage.
  root.style.setProperty('--mct85-height','495px');
  root.style.setProperty('--mct86-workspace-card-height','427px');
  root.style.setProperty('--mct85-left',left+'px');
  root.style.setProperty('--mct85-width',width+'px');
  // Keep the sidebar at its original viewport position when the page scrolls.
  // hr.top alone changes on scroll and made the fixed panel jump upward.
  const stableTop=Math.round(hr.top+window.scrollY);
  root.style.setProperty('--mct85-top',stableTop+'px');

 }
 function schedule(){if(raf)return;raf=requestAnimationFrame(()=>{raf=0;measure()})}
 window.addEventListener('resize',schedule,{passive:true});
 window.addEventListener('load',schedule);
 document.addEventListener('DOMContentLoaded',schedule);
 document.addEventListener('click',schedule);
 if(document.readyState!=='loading')schedule();
})();
