/* V12-113: replace text-only help marks with accessible vector icons. */
(()=>{'use strict';
const vector='<svg aria-hidden="true" viewBox="0 0 24 24"><path d="M9.1 9a3 3 0 0 1 5.8 1.1c0 2-2.9 2.5-2.9 4.6"/><path d="M12 18h.01"/></svg>';
function update(root){(root||document).querySelectorAll('#contract-section .mct-help-button,#follow-section .mct-help-button').forEach(b=>{if(b.dataset.mctIcon113)return;b.dataset.mctIcon113='1';b.innerHTML=vector;b.setAttribute('title',b.getAttribute('aria-label')||'Help');});}
let scheduled=false;const schedule=()=>{if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;update(document);});};
function start(){update(document);const target=document.getElementById('tasks');if(target)new MutationObserver(schedule).observe(target,{childList:true,subtree:true});}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();