/* V12-26 · Presentation only: preserve existing workspace handlers and IDs. */
(()=>{
 const setup=document.getElementById('setup');if(!setup)return;
 const heading=setup.querySelector('h2');
 if(heading){heading.textContent='Manage Your Workspaces';heading.classList.add('mct-elegant-heading');}
 const labels=[['#tasks','02','MY TASKS'],['#contract-section','02A','Contract Tasks & Deadlines'],['#follow-section','02B','Follow-Up Tasks'],['#communication','03','Communication Center']];
 labels.forEach(([sel,num,title])=>{const el=document.querySelector(sel+' > h2, '+sel+' > h3');if(el){el.innerHTML='<span class="mct-step-chip">'+num+'</span><span>'+title+'</span>';el.classList.add('mct-elegant-heading');}});
 const help=setup.querySelector('.re-help');if(help){help.classList.add('mct-setup-intro');help.innerHTML='<strong>Start here</strong> · Select an existing workspace or create a new one. Enter the contract dates and save to continue.';}
 const fields=setup.querySelector('.re-setup-compact');
 const picker=fields?.querySelector('.re-project-picker');
 const name=fields?.querySelector('.re-ws-name');
 const actions=setup.querySelector('.re-actions');
 const open=document.getElementById('ws-open'),create=document.getElementById('ws-new');
 const clear=document.getElementById('ws-clear-dates'),del=document.getElementById('ws-delete');
 const save=document.getElementById('ws-save');
 if(picker&&name&&actions&&open&&create&&clear&&del&&save){
  const chooser=document.createElement('div');chooser.className='mct-setup-chooser';
  picker.before(chooser);chooser.append(picker,open,del);
  const naming=document.createElement('div');naming.className='mct-setup-naming';
  chooser.before(naming);naming.append(name,create);
  const dateRow=fields.querySelector('.re-dates-priorities-row');
  if(dateRow){const dateButtons=document.createElement('div');dateButtons.className='mct-date-actions';dateRow.append(dateButtons);dateButtons.append(clear,save);}
  actions.classList.add('mct-delete-actions');
  del.title='Permanently delete the selected saved workspace (requires two confirmations)';
  open.textContent='Open Workspace';create.textContent='+ Create Workspace';clear.textContent='Clear Dates';
  del.textContent='Delete Workspace';
 }
 const status=document.getElementById('ws-status');if(status)status.classList.add('mct-setup-status');
 const activeText=()=>status?.textContent?.match(/^Active workspace: (.+)$/)?.[1]||'';
 const openButton=document.getElementById('ws-open'),select=document.getElementById('ws-list');
 const updateOpen=()=>{
  if(!openButton||!select)return;
  const selected=select.value;
  const active=activeText();
  const isOpen=!!selected&&selected===active;
  openButton.textContent=isOpen?'✓ Workspace Open':'Open Workspace';
  openButton.classList.toggle('mct-workspace-open',isOpen);
  openButton.setAttribute('aria-label',isOpen?'Workspace already open':'Open selected workspace');
  if(isOpen&&status)status.textContent='✓ '+selected+' is open. Your saved information is ready.';
 };
 select?.addEventListener('change',()=>setTimeout(updateOpen,30));
 openButton?.addEventListener('click',()=>setTimeout(()=>{
  const selected=select?.value;
  if(selected&&status?.textContent==='Active workspace: '+selected){
   status.textContent='✓ '+selected+' is open. Your saved information is ready.';
   openButton.textContent='✓ Workspace Open';openButton.classList.add('mct-workspace-open');
  }
 },90));
 const dialog=document.createElement('dialog');dialog.className='mct-delete-dialog';
 dialog.innerHTML='<div class="mct-delete-dialog-inner"><div class="mct-dialog-icon" aria-hidden="true">!</div><h3 id="mct-delete-title">Delete workspace?</h3><p id="mct-delete-detail"></p><div class="mct-delete-dialog-actions"><button type="button" data-mct-cancel>Cancel</button><button type="button" data-mct-confirm>Continue</button></div></div>';
 document.body.append(dialog);
 let pending=null,phase=0;
 const cancel=()=>{pending=null;phase=0;dialog.close()};
 dialog.querySelector('[data-mct-cancel]').addEventListener('click',cancel);
 dialog.addEventListener('cancel',e=>{e.preventDefault();cancel()});
 dialog.addEventListener('click',e=>{if(e.target===dialog)cancel()});
 dialog.querySelector('[data-mct-confirm]').addEventListener('click',()=>{
  if(!pending)return;
  if(phase===1){phase=2;dialog.querySelector('#mct-delete-title').textContent='Final confirmation';dialog.querySelector('#mct-delete-detail').textContent='This cannot be undone. All saved tasks, dates and drafts for this workspace will be lost.';dialog.querySelector('[data-mct-confirm]').textContent='Yes, Delete Permanently';return;}
  const fn=pending;cancel();fn();setTimeout(updateOpen,40);
 });
 window.mctConfirmDelete=(name,fn)=>{
  pending=fn;phase=1;
  dialog.querySelector('#mct-delete-title').textContent='Delete this workspace?';
  dialog.querySelector('#mct-delete-detail').textContent='You are about to delete “'+name+'”.';
  dialog.querySelector('[data-mct-confirm]').textContent='Continue';
  dialog.showModal();
 };

})();
