(()=>{
"use strict";
const $=id=>document.getElementById(id);
// Confirmation dialog: centered, accessible, no native browser confirm.
function confirmRestoreTasks(which){
 return new Promise(resolve=>{
  const previous=document.activeElement;
  const overlay=document.createElement('div');overlay.className='mct-restore-overlay';
  overlay.innerHTML=`<section class="mct-restore-dialog" role="alertdialog" aria-modal="true" aria-labelledby="mct-restore-title" aria-describedby="mct-restore-description">
   <header class="mct-restore-header"><span class="mct-restore-icon" aria-hidden="true">↻</span><h2 id="mct-restore-title">Restore My Default · ${which==='follow'?'Follow-Up':'Contract'} Tasks</h2><button type="button" class="mct-restore-x" aria-label="Close dialog">×</button></header>
   <div class="mct-restore-body"><p id="mct-restore-description">This will replace the current ${which==='follow'?'Table 02':'Table 01'} tasks with your saved personal Default template.</p><p class="mct-restore-muted">Any changes you made in this table will be lost.</p><div class="mct-restore-question">ⓘ &nbsp; Do you want to continue?</div><footer class="mct-restore-actions"><button type="button" class="mct-restore-cancel">Cancel</button><button type="button" class="mct-restore-accept">↻ &nbsp; Restore Tasks</button></footer></div></section>`;
  const finish=(answer)=>{document.removeEventListener('keydown',onKey,true);overlay.remove();previous?.focus?.();resolve(answer)};
  const onKey=(event)=>{if(event.key==='Escape'){event.preventDefault();finish(false)}else if(event.key==='Tab'){const a=[overlay.querySelector('.mct-restore-x'),overlay.querySelector('.mct-restore-cancel'),overlay.querySelector('.mct-restore-accept')];const i=a.indexOf(document.activeElement);if(event.shiftKey&&i<=0){event.preventDefault();a[2].focus()}else if(!event.shiftKey&&i===2){event.preventDefault();a[0].focus()}}};
  overlay.querySelector('.mct-restore-x').onclick=()=>finish(false);
  overlay.querySelector('.mct-restore-cancel').onclick=()=>finish(false);
  overlay.querySelector('.mct-restore-accept').onclick=()=>finish(true);
  overlay.addEventListener('click',event=>{if(event.target===overlay)finish(false)});
  document.body.append(overlay);document.addEventListener('keydown',onKey,true);overlay.querySelector('.mct-restore-cancel').focus();
 });
}

// Shared custom confirmation for personal template actions.
function confirmPersonalDefault(name,which){
 return new Promise(resolve=>{
  const previous=document.activeElement;
  const overlay=document.createElement('div');overlay.className='mct-restore-overlay';
  const dialog=document.createElement('section');dialog.className='mct-restore-dialog';dialog.setAttribute('role','alertdialog');dialog.setAttribute('aria-modal','true');
  const header=document.createElement('header');header.className='mct-restore-header';
  const title=document.createElement('h2');title.textContent='Set as My Default · '+(which==='follow'?'Table 02':'Table 01');
  const close=document.createElement('button');close.type='button';close.className='mct-restore-x';close.textContent='×';close.setAttribute('aria-label','Close dialog');header.append(title,close);
  const body=document.createElement('div');body.className='mct-restore-body';
  const message=document.createElement('p');message.textContent='Do you want to set “'+name+'” as your personal Default template?';
  const detail=document.createElement('p');detail.className='mct-restore-muted';detail.textContent='You can change My Default later. Your saved template will remain available.';
  const footer=document.createElement('footer');footer.className='mct-restore-actions';
  const cancel=document.createElement('button');cancel.type='button';cancel.className='mct-restore-cancel';cancel.textContent='Cancel';
  const accept=document.createElement('button');accept.type='button';accept.className='mct-restore-accept';accept.textContent='★ Set as My Default';footer.append(cancel,accept);body.append(message,detail,footer);dialog.append(header,body);overlay.append(dialog);
  const finish=(value)=>{document.removeEventListener('keydown',onKey,true);overlay.remove();previous?.focus?.();resolve(value)};
  const onKey=(event)=>{if(event.key==='Escape'){event.preventDefault();finish(false)}else if(event.key==='Tab'){const items=[close,cancel,accept];const i=items.indexOf(document.activeElement);if(event.shiftKey&&i<=0){event.preventDefault();accept.focus()}else if(!event.shiftKey&&i===2){event.preventDefault();close.focus()}}};
  close.onclick=cancel.onclick=()=>finish(false);accept.onclick=()=>finish(true);overlay.onclick=e=>{if(e.target===overlay)finish(false)};
  document.body.append(overlay);document.addEventListener('keydown',onKey,true);cancel.focus();
 });
}

// Reusable confirmation: template replacement and deletion, no native browser dialogs.
function confirmTemplateAction({title,message,detail,action,danger=false}){
 return new Promise(resolve=>{
  const previous=document.activeElement;
  const overlay=document.createElement('div');overlay.className='mct-restore-overlay';
  const dialog=document.createElement('section');dialog.className='mct-restore-dialog';dialog.setAttribute('role','alertdialog');dialog.setAttribute('aria-modal','true');
  const header=document.createElement('header');header.className='mct-restore-header';
  const heading=document.createElement('h2');heading.textContent=title;
  const close=document.createElement('button');close.type='button';close.className='mct-restore-x';close.textContent='×';close.setAttribute('aria-label','Close dialog');header.append(heading,close);
  const body=document.createElement('div');body.className='mct-restore-body';
  const question=document.createElement('p');question.textContent=message;
  const explanation=document.createElement('p');explanation.className='mct-restore-muted';explanation.textContent=detail;
  const footer=document.createElement('footer');footer.className='mct-restore-actions';
  const cancel=document.createElement('button');cancel.type='button';cancel.className='mct-restore-cancel';cancel.textContent='Cancel';
  const accept=document.createElement('button');accept.type='button';accept.className='mct-restore-accept';accept.textContent=action;
  if(danger){accept.classList.add('mct-restore-danger');}
  footer.append(cancel,accept);body.append(question,explanation,footer);dialog.append(header,body);overlay.append(dialog);
  let closed=false;
  const finish=value=>{if(closed)return;closed=true;document.removeEventListener('keydown',onKey,true);overlay.remove();previous?.focus?.();resolve(value)};
  const onKey=e=>{if(e.key==='Escape'){e.preventDefault();finish(false)}else if(e.key==='Tab'){const items=[close,cancel,accept];const i=items.indexOf(document.activeElement);if(e.shiftKey&&i<=0){e.preventDefault();accept.focus()}else if(!e.shiftKey&&i===2){e.preventDefault();close.focus()}}};
  close.onclick=cancel.onclick=()=>finish(false);accept.onclick=()=>finish(true);
  overlay.onclick=e=>{if(e.target===overlay)finish(false)};
  document.body.append(overlay);document.addEventListener('keydown',onKey,true);cancel.focus();
 });
}

const defaults={"contract": [["1st Deposit", 3, "ed"], ["2nd Deposit", 5, "ed"], ["Loan Application", 5, "ed"], ["Condo Application", 5, "ed"], ["Property Inspection deadline w/right to cancel", 7, "ed"], ["LOAN APPROVAL - Notify seller if NO LOAN APPROVAL", 30, "ed"]], "follow": [["Confirm Deposit", 3, "ed"], ["Schedule Inspection", 5, "ed"], ["Confirm Financing", 7, "ed"], ["Review Closing Documents", -3, "cd"], ["Confirm Walkthrough", -1, "cd"], ["Confirm Closing", 0, "cd"]]};
const D='mct-personal-defaults-v12-170';
let personalDefaults=readPersonalDefaults();
function readPersonalDefaults(){try{return JSON.parse(localStorage.getItem(D))||{contract:null,follow:null}}catch{return {contract:null,follow:null}}}
function persistPersonalDefaults(){try{localStorage.setItem(D,JSON.stringify(personalDefaults));return true}catch{return false}}
const K='mct-v11-real-estate-v49',T='mct-v11-tables-v49',C='mct-v11-contacts-v49';
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))||fallback}catch{return fallback}};
const write=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true}catch{status('Browser storage unavailable');return false}};
const fresh=(x)=>({id:Math.random().toString(36).slice(2),name:x[0],days:x[1],basis:x[2],selected:false,done:false,notes:''});
const blank=(name='')=>({name,role:'',ed:'',cd:'',counting:'calendar',contract:defaults.contract.map(fresh),follow:defaults.follow.map(fresh),drafts:{contract:{},follow:{}}});
let db=read(K,{active:'',workspaces:{}}),library=read(T,{contract:{},follow:{}}),contacts=read(C,{});
if(!db.workspaces)db={active:'',workspaces:{}};
// Opening this page never automatically reopens an old project. Saved projects remain in storage.
db.active='';
let state=blank();
// Task selection and table confirmation are temporary per-session UI state.
// They must never be persisted or inherited from another workspace.
function cleanWorkspace(saved){
 const copy=JSON.parse(JSON.stringify(saved));
 ['contract','follow'].forEach(w=>{
  copy[w]=(Array.isArray(copy[w])?copy[w]:defaults[w].map(fresh)).map(t=>({...t,selected:false}));
 });
 return copy;
}
function resetTableConfirmations(){
 ['contract','follow'].forEach(w=>{const check=$(w+'-confirm');if(check)check.checked=false;});
}
const status=t=>{const el=$('ws-status');el.textContent=t;el.classList.toggle('mct-save-confirmed',/saved successfully\. Dates applied to both tables\./i.test(t));};
const save=()=>{
 if(!db.active)return false;
 // Keep task definitions and completed status, but never save checkmarks used for email.
 db.workspaces[db.active]=cleanWorkspace(state);
 return write(K,db);
};
function markTableEdited(which){const check=$(which+'-confirm');if(check)check.checked=false;}
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e};
const fmt=(date)=>date?new Date(date+'T12:00:00'):null;
const due=t=>{const base=fmt(t.basis==='cd'?state.cd:state.ed);if(!base)return '';if(state.counting==='business'){let left=Math.abs(Number(t.days||0)),step=Number(t.days||0)<0?-1:1;while(left>0){base.setDate(base.getDate()+step);if(base.getDay()!==0&&base.getDay()!==6)left--}}else base.setDate(base.getDate()+Number(t.days||0));return [base.getFullYear(),String(base.getMonth()+1).padStart(2,'0'),String(base.getDate()).padStart(2,'0')].join('-')};
// V12: inverse of business-day date addition for manually edited due dates.
// Count weekdays strictly after the base for future dates, and strictly before
// the base for past dates. Weekends are skipped in both directions.
function daysBetween(base,target,counting){
 if(!base||!target)return 0;
 const a=fmt(base),b=fmt(target);
 if(!a||!b)return 0;
 const sign=b>a?1:b<a?-1:0;
 if(!sign)return 0;
 if(counting!=='business')return Math.round((b-a)/86400000);
 let days=0;
 while((sign>0&&a<b)||(sign<0&&a>b)){
  a.setDate(a.getDate()+sign);
  if(a.getDay()!==0&&a.getDay()!==6)days+=sign;
 }
 return days;
}
const diff=date=>{if(!date)return null;const today=new Date();today.setHours(12,0,0,0);return Math.round((fmt(date)-today)/86400000)};
const alert=t=>{if(t.done)return 'Completed';const n=diff(due(t));return n===null?'Set dates':n<0?'Overdue':n===0?'Today':n===1?'Tomorrow':'Upcoming'};
function input(type,value,onchange){const e=el('input');e.type=type;if(type==='checkbox')e.checked=!!value;else e.value=value??'';e.addEventListener('change',()=>onchange(type==='checkbox'?e.checked:e.value));if(type==='text')e.addEventListener('input',()=>onchange(e.value));return e}
function cell(tr,child){const td=el('td');if(typeof child==='string'||typeof child==='number')td.textContent=child;else td.append(child);tr.append(td);return td}
const pendingDaysApply={contract:false,follow:false};
function updateDaysApply(which){
 const button=document.querySelector('[data-sort="'+which+'"]');
 if(!button)return;
 const pending=pendingDaysApply[which];
 button.textContent=pending?'Apply':'Days';
 button.classList.toggle('re-days-pending',pending);
 button.title=pending?'Reorder by Due Date (or by Days within each Date Basis when dates are unset)':'Change Days or Due Date to enable Apply';
 button.setAttribute('aria-label',pending?'Apply changes and reorder '+which+' tasks by due date':'Days column');
}
function render(which){const body=$(which+'-rows');body.replaceChildren();updateDaysApply(which);state[which].forEach((t,i)=>{const tr=el('tr');tr.classList.toggle('re-task-selected',!!t.selected);const priority=alert(t).toLowerCase();if(['today','tomorrow','overdue'].includes(priority))tr.classList.add('re-row-'+priority);tr.dataset.taskId=t.id;cell(tr,input('checkbox',t.selected,v=>{t.selected=v;tr.classList.toggle('re-task-selected',!!v);$(which+'-confirm').checked=false;save();summary(which)}));cell(tr,String(i+1));cell(tr,input('text',t.name,v=>{t.name=v;markTableEdited(which);save();summary(which)}));cell(tr,input('number',t.days,v=>{t.days=Number(v)||0;pendingDaysApply[which]=true;markTableEdited(which);save();render(which)}));const basis=el('select');[['ed','After Effective Date'],['cd','Before/After Closing Date']].forEach(([v,label])=>{const o=el('option',label);o.value=v;basis.append(o)});basis.value=t.basis;basis.addEventListener('change',()=>{t.basis=basis.value;pendingDaysApply[which]=true;markTableEdited(which);save();render(which)});cell(tr,basis);const date=input('date',due(t),v=>{const base=fmt(t.basis==='cd'?state.cd:state.ed);if(!base){status('Set Effective Date and Closing Date first');render(which);return}if(v){t.days=daysBetween(t.basis==='cd'?state.cd:state.ed,v,state.counting);pendingDaysApply[which]=true;markTableEdited(which);save();render(which)}});cell(tr,date);cell(tr,t.done?'Done':'Pending');const a=cell(tr,alert(t));a.className='re-alert '+(alert(t)==='Overdue'?'re-overdue':alert(t)==='Today'?'re-today':alert(t)==='Tomorrow'?'re-tomorrow':'');cell(tr,input('checkbox',t.done,v=>{t.done=v;markTableEdited(which);save();render(which)}));cell(tr,input('text',t.notes||'',v=>{t.notes=v;markTableEdited(which);save();summary(which)}));const remove=el('button','Delete');remove.type='button';remove.addEventListener('click',()=>{state[which].splice(i,1);markTableEdited(which);save();render(which)});cell(tr,remove);body.append(tr)});summary(which);refreshDailyCounters()}
const summaryLabels=['#','TASK / MILESTONE','DAYS','DATE BASIS','DUE DATE','STATUS','ALERT','DONE','NOTES'];
const summaryColumns={contract:[true,true,true,false,true,false,false,false,false],follow:[true,true,true,false,true,false,false,false,false]};
const summaryValues=(t,i)=>[i+1,t.name,t.days,t.basis==='cd'?'Before/After Closing':'After Effective Date',due(t)||'Set dates',t.done?'Completed':'Pending',alert(t),t.done?'Yes':'No',t.notes||'—'];
function summary(which){
 refreshDailyCounters();
 const headerSelect=$(which+'-select-all');
 if(headerSelect){const count=state[which].filter(t=>t.selected).length;headerSelect.checked=state[which].length>0&&count===state[which].length;headerSelect.indeterminate=count>0&&count<state[which].length;}
 const selected=state[which].filter(t=>t.selected);
 $(which+'-count').textContent=selected.length+' selected / '+state[which].length+' total';
 const box=$(which+'-summary');box.hidden=!selected.length;
 document.querySelector('[data-summary-toggle="'+which+'"]').textContent=selected.length?'Hide Results ↑':'Review Results →';
 box.replaceChildren();
 const done=state[which].filter(t=>t.done).length;
 $(which+'-progress').textContent=(state[which].length-done)+' pending · '+done+' completed';
 $(which+'-selected').textContent=selected.length+' selected to share';
 const confirm=$(which+'-confirm');if(!selected.length)confirm.checked=false;
 document.querySelector('[data-continue="'+which+'"]').disabled=!selected.length||!confirm.checked;
 $(which+'-continue-note').textContent=!selected.length?'Select at least one task in this table.':confirm.checked?'Ready for Communication Center.':'Review and confirm this table to continue.';
 if(!selected.length)return;
 const heading=el('div');heading.className='re-summary-heading';
 const title=el('h4',which==='contract'?'Closing Timeline Summary':'Follow-Up Summary');
 const brand=el('span','▣ MyClosingTimeline.com');brand.className='re-summary-brand';heading.append(title,brand);box.append(heading);
 const reviewNote=el('p',confirm.checked?'✓ Table confirmed. Continue to the Communication Center.':'Review your selected tasks before confirming.');reviewNote.className='re-summary-review-note';box.append(reviewNote);
 const chooser=el('details');chooser.className='re-column-chooser';chooser.open=true;
 const toggle=el('summary','Choose Columns · '+summaryColumns[which].filter(Boolean).length+' of '+summaryLabels.length+' visible');chooser.append(toggle);
 const controls=el('div');controls.className='re-column-options';
 const allLabel=el('label');allLabel.className='re-column-all';const allCheck=el('input');allCheck.type='checkbox';allCheck.title='Select or clear all columns';
 const checks=[];
 function updateColumnControls(){const n=summaryColumns[which].filter(Boolean).length;toggle.textContent='Choose Columns · '+n+' of '+summaryLabels.length+' visible';allCheck.checked=n===summaryLabels.length;allCheck.indeterminate=n>0&&n<summaryLabels.length;checks.forEach((c,i)=>{c.checked=summaryColumns[which][i]});fillTable()}
 allCheck.addEventListener('change',()=>{summaryColumns[which]=summaryLabels.map(()=>allCheck.checked);markTableEdited(which);updateColumnControls();summary(which)});
 allLabel.append(allCheck,document.createTextNode(' Select All'));controls.append(allLabel);
 summaryLabels.forEach((label,i)=>{
  const item=el('label');const check=el('input');check.type='checkbox';check.checked=summaryColumns[which][i];checks.push(check);
  check.addEventListener('change',()=>{summaryColumns[which][i]=check.checked;markTableEdited(which);updateColumnControls();summary(which)});
  item.append(check,document.createTextNode(' '+label));controls.append(item);
 });;chooser.append(controls);box.append(chooser);
 const table=el('table');table.className='re-summary-table';const tableWrap=el('div');tableWrap.className='re-summary-table-wrap';tableWrap.append(table);box.append(tableWrap);
 function fillTable(){
  table.replaceChildren();
  const classes=['re-sum-num','re-sum-task','re-sum-days','re-sum-basis','re-sum-date','re-sum-status','re-sum-alert','re-sum-done','re-sum-notes'];
  const active=summaryColumns[which].map((v,i)=>v?i:-1).filter(i=>i>=0);
  // Keep natural proportions for any combination of columns, including all nine.
  // Browser sizes columns from headers and cell content, without fixed percentages.
  const head=el('tr');summaryLabels.forEach((h,i)=>{if(summaryColumns[which][i]){const th=el('th',h);th.className=classes[i];head.append(th)}});const thead=el('thead');thead.append(head);table.append(thead);
  const body=el('tbody');selected.forEach((t,i)=>{const tr=el('tr');tr.className='re-summary-selected';summaryValues(t,i).forEach((v,j)=>{if(summaryColumns[which][j]){const td=el('td',String(v));td.className=classes[j];tr.append(td)}});body.append(tr)});table.append(body);
 }
 fillTable();box.append(el('p','Dates and deadlines must follow the signed contract.'));
}

// V11-178: compact daily reminders. Read current task state, never move rows.
const dailyTypes=['today','tomorrow','overdue'];
function dailyItems(kind,scope){
 const groups=scope?[scope]:['contract','follow'];
 return groups.flatMap(w=>state[w].map((t,i)=>({t,w,i})).filter(x=>alert(x.t).toLowerCase()===kind));
}
function refreshDailyCounters(){
 for(const kind of dailyTypes){
  const total=$('daily-total-'+kind);
  if(total)total.textContent=String(dailyItems(kind).length);
  for(const w of ['contract','follow']){
   const node=$(w+'-daily-'+kind);
   if(node)node.textContent=String(dailyItems(kind,w).length);
  }
 }
 if($('daily-popover')&&!$('daily-popover').hidden&&dailyCurrent)drawDailyPopover();
}
let dailyCurrent=null;
function closeDailyPopover(){
 const p=$('daily-popover');if(p)p.hidden=true;
 dailyCurrent=null;
 document.querySelectorAll('[data-daily-open]').forEach(b=>b.setAttribute('aria-expanded','false'));
}
function drawDailyPopover(){
 if(!dailyCurrent)return;
 const {kind,scope}=dailyCurrent,items=dailyItems(kind,scope);
 $('daily-popover-title').textContent=({today:'Today',tomorrow:'Tomorrow',overdue:'Overdue'})[kind]+' · '+(scope==='contract'?'Table 01':scope==='follow'?'Table 02':'Both Tables')+' · '+items.length;
 const box=$('daily-popover-body');box.replaceChildren();
 if(!items.length){const msg=el('p','No pending tasks in this category.');msg.className='re-daily-empty';box.append(msg);return}
 items.forEach(({t,w,i})=>{
  const btn=el('button');btn.type='button';btn.className='re-daily-entry';
  const id=el('strong',(w==='contract'?'Table 01':'Table 02')+' · #'+(i+1));
  const name=el('span',t.name||'Untitled task');
  const date=el('small',due(t)||'Set dates');
  btn.append(id,name,date);
  btn.addEventListener('click',()=>{
   closeDailyPopover();
   const rows=$(w+'-rows');
   const target=[...rows.querySelectorAll('tr')].find(row=>row.dataset.taskId===t.id);
   if(!target)return;
   target.scrollIntoView({behavior:'smooth',block:'center'});
   target.classList.add('re-daily-located');
   setTimeout(()=>target.classList.remove('re-daily-located'),2300);
  });
  box.append(btn);
 });
}
document.addEventListener('click',event=>{
 const trigger=event.target.closest('[data-daily-open]');
 if(trigger){
  const kind=trigger.dataset.dailyOpen,scope=trigger.dataset.dailyTable||null;
  if(dailyCurrent&&dailyCurrent.kind===kind&&dailyCurrent.scope===scope){closeDailyPopover();return}
  dailyCurrent={kind,scope};
  const pop=$('daily-popover');pop.hidden=false;
  drawDailyPopover();
  const rect=trigger.getBoundingClientRect(),width=Math.min(385,innerWidth-24);
  pop.style.width=width+'px';
  pop.style.left=Math.max(12,Math.min(rect.right-width,innerWidth-width-12))+'px';
  pop.style.top=Math.max(12,Math.min(rect.bottom+8,innerHeight-Math.min(pop.offsetHeight,400)-12))+'px';
  document.querySelectorAll('[data-daily-open]').forEach(b=>b.setAttribute('aria-expanded',String(b===trigger)));
  return;
 }
 if(event.target.closest('#daily-popover-close')){closeDailyPopover();return}
 if(!event.target.closest('#daily-popover'))closeDailyPopover();
});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeDailyPopover()});
window.addEventListener('resize',closeDailyPopover);
document.addEventListener('visibilitychange',()=>{if(!document.hidden){refreshDailyCounters();renderAll()}});

function renderAll(){['contract','follow'].forEach(render)}
function refreshList(){const list=$('ws-list');list.replaceChildren();const o=el('option','Select');o.value='';list.append(o);Object.keys(db.workspaces).forEach(id=>{const opt=el('option',id);opt.value=id;list.append(opt)});const newOpt=el('option','+ Create a New Project');newOpt.value='__new__';list.append(newOpt);list.value=''}
function refreshSetup(){resetTableConfirmations();refreshList();$('ws-name').value=state.name||'';$('ws-role').value=state.role||'';$('ws-ed').value=state.ed||'';$('ws-cd').value=state.cd||'';$('ws-counting').value=state.counting||'calendar';updateDays();loadDraft();renderAll()}
function syncFields(){state.name=$('ws-name').value;state.role=$('ws-role').value;state.ed=$('ws-ed').value;state.cd=$('ws-cd').value;state.counting=$('ws-counting').value}
$('ws-new').onclick=()=>{
 const id=$('ws-name').value.trim();
 if(!id){status('Enter a workspace / project name before creating it.');$('ws-name').focus();return}
 if(db.workspaces[id]){status('Workspace already exists: '+id+'. Select it under Saved workspaces and choose Open Selected Workspace.');return}
 const values={role:$('ws-role').value,ed:$('ws-ed').value,cd:$('ws-cd').value,counting:$('ws-counting').value||'calendar'};
 db.active=id;
 state=blank(id);
 Object.assign(state,values);
 save();refreshSetup();$('ws-list').value=id;resetSetupSaveButton();
 status('Active workspace: '+id);
};
$('ws-open').onclick=()=>{const id=$('ws-list').value;if(!id||!db.workspaces[id]){status('Select a saved workspace');return}db.active=id;state=cleanWorkspace(db.workspaces[id]);write(K,db);refreshSetup();$('ws-list').value=id;resetSetupSaveButton();status('Active workspace: '+id)};
const setupSaveButton=$('ws-save');
const setupOriginalLabel='Save Setup / Apply Dates';
function setupNeedsSaving(){setupSaveButton.classList.remove('re-setup-saved');setupSaveButton.textContent=setupOriginalLabel;status('Unsaved changes — select Save Setup / Apply Dates.');}
['ws-name','ws-role','ws-ed','ws-cd','ws-counting'].forEach(id=>{
 $(id).addEventListener('input',setupNeedsSaving);
 $(id).addEventListener('change',setupNeedsSaving);
});
function resetSetupSaveButton(){
 // A saved workspace loaded without edits is already saved: never request a redundant save.
 const existing=!!db.active && !!db.workspaces[db.active];
 const matching=existing && !!state.role && !!state.ed && !!state.cd && state.cd>=state.ed && ['name','role','ed','cd','counting'].every(k=>String(state[k]||'')===String(k==='name'?$('ws-name').value:k==='role'?$('ws-role').value:k==='ed'?$('ws-ed').value:k==='cd'?$('ws-cd').value:$('ws-counting').value));
 setupSaveButton.classList.toggle('re-setup-saved',!!matching);
 setupSaveButton.textContent=matching?'✓ Saved & Dates Applied':setupOriginalLabel;
}
$('ws-save').onclick=()=>{
 if(!db.active || $('ws-list').value==='__new__' || ($('ws-list').value && $('ws-list').value!==db.active)){status('Open the selected workspace or create your new project before saving.');return}
 const ed=$('ws-ed').value,cd=$('ws-cd').value;
 if(!$('ws-role').value){status('Choose My role before saving.');$('ws-role').focus();return}if(!ed||!cd){status('Enter both Effective Date and Closing Date before applying dates.');return}if(!$('ws-counting').value){status('Choose Deadline Counting before saving.');$('ws-counting').focus();return}
 if(cd<ed){status('Closing Date must not be earlier than Effective Date.');return}
 syncFields();
 if(!save()){status('Could not save workspace. Please check browser storage.');return}
 updateDays();renderAll();
 setupSaveButton.classList.add('re-setup-saved');
 setupSaveButton.textContent='✓ Saved & Dates Applied';
 status('✓ Workspace '+db.active+' saved successfully. Dates applied to both tables.');
 const libraryPanel=$('contract-template-library');libraryPanel?.classList.add('re-template-attention');
 // Guided workflow stays on Workspace until the user selects Next.
};
$('ws-clear-dates').onclick=()=>{state.ed='';state.cd='';$('ws-ed').value='';$('ws-cd').value='';save();updateDays();renderAll();resetSetupSaveButton();status('Dates cleared')};
$('ws-list').addEventListener('change',()=>{
 const selected=$('ws-list').value;
 // Selection is a preview of the NAME only. Never activate a workspace or
 // expose its saved dates, tasks, notes, or drafts until explicit Open.
 db.active='';
 state=blank(selected && selected!=='__new__'?selected:'');
 resetTableConfirmations();
 $('ws-name').value=selected==='__new__'?'':state.name;
 $('ws-role').value='';
 $('ws-ed').value='';
 $('ws-cd').value='';
 $('ws-counting').value='calendar';
 resetSetupSaveButton();
 updateDays();
 loadDraft();
 renderAll();
 status(selected && selected!=='__new__'
  ?'Selected project: '+selected+' · Click Open Workspace to load its saved information.'
  :'Select a saved workspace.');
});
$('ws-delete').onclick=()=>{
 const id=$('ws-list').value;
 if(!id||!Object.prototype.hasOwnProperty.call(db.workspaces,id)){
  status('Select a workspace under Saved workspaces before deleting.');
  $('ws-list').focus();return;
 }
 const performDeletion=()=>{
 const wasActive=db.active===id;
 const nextDb={...db,workspaces:{...db.workspaces}};
 delete nextDb.workspaces[id];
 if(wasActive)nextDb.active='';
 if(!write(K,nextDb)){status('Could not delete workspace. Browser storage unavailable.');return;}
 db=nextDb;
 if(wasActive)state=blank();
 refreshSetup();resetSetupSaveButton();
 status('✓ Deleted selected workspace: '+id+'.'+(wasActive?' No workspace is active.':' Active workspace remains: '+db.active+'.'));
 };
 if(typeof window.mctConfirmDelete==='function')window.mctConfirmDelete(id,performDeletion);
 else if(confirm('Permanently delete workspace "'+id+'" and all saved work?'))performDeletion();
};
['contract','follow'].forEach(w=>{
 const head=$(w+'-select-all');
 if(head)head.addEventListener('change',()=>{const checked=head.checked;state[w].forEach(t=>t.selected=checked);$(w+'-confirm').checked=false;save();render(w)});
 document.querySelector('[data-add="'+w+'"]').onclick=()=>{const task=fresh(['New task',0,'ed']);state[w].push(task);save();render(w)};if(document.querySelector('[data-select="'+w+'"]'))document.querySelector('[data-select="'+w+'"]').onclick=()=>{state[w].forEach(t=>t.selected=true);$(w+'-confirm').checked=false;save();render(w)};if(document.querySelector('[data-clear="'+w+'"]'))document.querySelector('[data-clear="'+w+'"]').onclick=()=>{state[w].forEach(t=>t.selected=false);$(w+'-confirm').checked=false;save();render(w)};document.querySelector('[data-restore="'+w+'"]').onclick=async()=>{const mine=personalDefaults[w];if(!mine){templateMessage(w,'You have not set My Default yet. Save a named template and select Set as My Default.');return;}if(!await confirmRestoreTasks(w))return;state[w]=templateRows(mine.rows);pendingDaysApply[w]=false;markTableEdited(w);templateBaseline[w]=templateSignature(w);save();render(w);templateMessage(w,'Restored My Default: '+mine.name);};document.querySelector('[data-sort="'+w+'"]').onclick=()=>{
  // Deliberate action only: editing Days, Date Basis or Due Date never moves a row.
  const hasDates=!!state.ed&&!!state.cd;
  // With both contract dates, order all tasks by real due date.
  // Without both dates, keep the Date Basis groups in their existing order
  // and order by Days *within* each group only. This avoids comparing
  // days relative to different dates and still makes Apply useful in Table 02.
  const basisOrder=new Map();
  state[w].forEach(t=>{if(!basisOrder.has(t.basis))basisOrder.set(t.basis,basisOrder.size)});
  const indexed=state[w].map((task,index)=>({task,index,date:hasDates?due(task):'',days:Number(task.days)||0}));
  indexed.sort((a,b)=>{
    if(hasDates)return a.date.localeCompare(b.date)||a.index-b.index;
    return (basisOrder.get(a.task.basis)-basisOrder.get(b.task.basis))||a.days-b.days||a.index-b.index;
  });
  const changed=indexed.some((entry,index)=>entry.index!==index);
  if(!changed){pendingDaysApply[w]=false;updateDaysApply(w);status('Tasks are already in the correct order.');return;}
  state[w]=indexed.map(entry=>entry.task);
  pendingDaysApply[w]=false;
  markTableEdited(w);
  save();render(w);
  status((w==='contract'?'Table 01':'Table 02')+' reordered '+(hasDates?'by Due Date':'by Days within each Date Basis group')+'. Review and confirm the updated table before sending.');
};document.querySelector('[data-save-table="'+w+'"]').onclick=()=>{const name=prompt('Name this table:');if(!name?.trim())return;library[w][name.trim()]=state[w].map(t=>({...t,selected:false}));write(T,library);$(w+'-saved').textContent='Saved: '+name;status('Table saved: '+name)};document.querySelector('[data-load-table="'+w+'"]').onclick=()=>{const names=Object.keys(library[w]);if(!names.length){status('No saved tables for '+w);return}const name=prompt('Load table (enter exact name):\n'+names.join('\n'));if(!name||!library[w][name])return;if(!confirm('Replace current '+w+' table with '+name+'?'))return;state[w]=library[w][name].map(t=>({...t,selected:false}));$(w+'-saved').textContent='Loaded: '+name;$(w+'-confirm').checked=false;save();render(w)};document.querySelector('[data-delete-table="'+w+'"]').onclick=()=>{const names=Object.keys(library[w]);if(!names.length){status('No saved tables');return}const name=prompt('Delete saved table (exact name):\n'+names.join('\n'));if(!name||!library[w][name]||!confirm('Delete saved table '+name+'?'))return;delete library[w][name];write(T,library);status('Saved table deleted')}});
// V11-192: Protect every template edit, including task names and Days.
const templateBaseline={contract:null,follow:null};
function templateSignature(w){return JSON.stringify(state[w].map(t=>[String(t.name||''),Number(t.days)||0,t.basis==='cd'?'cd':'ed']));}
function templateDirty(w){return templateBaseline[w]!==null&&templateSignature(w)!==templateBaseline[w];}
async function confirmTemplateReplacement(w){
 const dirty=templateDirty(w);
 const work=state[w].some(t=>t.selected||t.done||String(t.notes||'').trim());
 return !(dirty||work)||confirmTemplateAction({title:'Replace Current Table · '+(w==='follow'?'Table 02':'Table 01'),message:'Replace the current table with the selected template?',detail:(dirty?'You have unsaved changes to task definitions. ':'')+'Notes, selections and completion marks in this table may be lost.',action:'Replace Table',danger:true});
}
function refreshTemplateSaveControl(w){
 const button=document.querySelector('[data-template-save="'+w+'"]');
 if(!button)return;
 const name=$(w+'-template-name').value.trim();
 button.textContent=($(w+'-template-select').value.startsWith('saved:')?'Save Changes':'Name & Save');
 button.disabled=!name;
}
// V11-188 · Reusable named templates, independent for each table.
// Templates intentionally exclude transaction-specific notes, done flags and selections.
function templateRows(rows){return rows.map(t=>({id:Math.random().toString(36).slice(2),name:String(t.name||''),days:Number(t.days)||0,basis:t.basis==='cd'?'cd':'ed',selected:false,done:false,notes:''}));}
function refreshTemplateChoices(w,preferred){
 const select=$(w+'-template-select');const current=preferred||select.value;
 select.replaceChildren();
 const add=(value,label)=>{const option=el('option',label);option.value=value;select.append(option)};
 add('','Select a template');add('create','+ Create a New Template');if(personalDefaults[w])add('mydefault','★ My Default · '+personalDefaults[w].name);add('original','MyClosingTimeline · Starter 6 Tasks');/* Creation is offered only in this selector. */
 Object.keys(library[w]||{}).sort((a,b)=>a.localeCompare(b)).forEach(name=>add('saved:'+name,name));
 if(w==='contract'){const option=el('option','Complete 40+ Tasks · import pending');option.disabled=true;option.value='unavailable';select.append(option)}
 select.value=[...select.options].some(o=>o.value===current)?current:'';
}
function templateMessage(w,message){$(w+'-template-note').textContent=message;}
async function openTemplate(w){
 
 const selection=$(w+'-template-select').value;
 if(!selection){templateMessage(w,'Choose a table from the menu first.');return}
 const name=selection.startsWith('saved:')?selection.slice(6):'';
 const source=selection==='original'?defaults[w].map(fresh):selection==='mydefault'?personalDefaults[w]?.rows:library[w]?.[name];
 if(!source){templateMessage(w,'This template is not available.');return}
 if(!await confirmTemplateReplacement(w)){
  $(w+'-template-select').value='';
  templateMessage(w,'Table unchanged. Choose a table when you are ready.');
  return;
 }
 state[w]=templateRows(source);pendingDaysApply[w]=false;markTableEdited(w);
 $(w+'-template-name').value=name;
 templateBaseline[w]=templateSignature(w);refreshTemplateSaveControl(w);
 save();render(w);templateMessage(w,'Opened: '+(name||(selection==='mydefault'?'My Default':'Starter 6 Tasks'))+'. Edit tasks and select columns as usual.');
 $(w+'-template-new').hidden=selection==='original'||selection==='mydefault';
 $(w+'-template-library').classList.remove('re-template-attention');
 
}
async function saveTemplate(w){
 
 const name=$(w+'-template-name').value.trim();
 if(!name){templateMessage(w,'Enter a name for your table before saving.');$(w+'-template-name').focus();return}
 if(name.length>70){templateMessage(w,'Use a shorter name.');return}
 if(!library[w])library[w]={};
 if(Object.prototype.hasOwnProperty.call(library[w],name)){
  const yes=await confirmTemplateAction({title:'Save Template Changes · '+(w==='follow'?'Table 02':'Table 01'),message:'Replace the saved template “'+name+'” with the current task definitions?',detail:'The previous saved version will be replaced. Your current workspace tasks will remain unchanged.',action:'Save Template Changes'});
  if(!yes)return;
 }
 const next={...library,[w]:{...library[w],[name]:templateRows(state[w])}};
 if(!write(T,next))return;
 library=next;refreshTemplateChoices(w,'saved:'+name);templateBaseline[w]=templateSignature(w);
 if(personalDefaults[w]?.name===name){personalDefaults[w]={name,rows:templateRows(state[w])};persistPersonalDefaults();const n=$(w+'-personal-default-note');if(n)n.textContent='My Default: '+name;}
 $(w+'-saved').textContent='Saved template: '+name;
 templateMessage(w,'Saved: '+name+'. You may reuse it in other workspaces.');
 $(w+'-template-new').hidden=false;refreshTemplateSaveControl(w);
 $(w+'-template-library').classList.remove('re-template-attention');
}
['contract','follow'].forEach(w=>{
 refreshTemplateChoices(w);
 const picker=$(w+'-template-select');
 const deleteVisible=document.querySelector('[data-template-delete="'+w+'"]');
 const setDefault=document.querySelector('[data-set-default="'+w+'"]');
 const defaultNote=document.getElementById(w+'-personal-default-note');
 function refreshDefaultLabel(){if(defaultNote)defaultNote.textContent=personalDefaults[w]?'My Default: '+personalDefaults[w].name:'My Default: not set';}
 refreshDefaultLabel();
 document.addEventListener('click',async(event)=>{if(!event.target.closest('[data-set-default="'+w+'"]'))return;const name=$(w+'-template-name').value.trim();if(!name){templateMessage(w,'Name your template and save it before setting My Default.');return;}if(!library[w]?.[name]){templateMessage(w,'Save this template first, then set it as My Default.');return;}if(!await confirmPersonalDefault(name,w))return;personalDefaults[w]={name,rows:templateRows(library[w][name])};if(!persistPersonalDefaults()){templateMessage(w,'Could not save My Default in this browser.');return;}refreshDefaultLabel();refreshTemplateChoices(w,'saved:'+name);templateMessage(w,'My Default saved: '+name+'. Restore My Default will now use this version.');});
 deleteVisible.onclick=()=>document.querySelector('[data-delete-table="'+w+'"]').click();
 picker.addEventListener('change',async()=>{
  const choice=picker.value;
  // Templates are personal reusable definitions, independent of workspace setup.
  deleteVisible.hidden=!choice.startsWith('saved:');
  if(choice==='create'){
   if(!await confirmTemplateReplacement(w)){picker.value='';deleteVisible.hidden=true;templateMessage(w,'Table unchanged.');return}
   templateBaseline[w]=templateSignature(w);
   $(w+'-template-new').hidden=false;$(w+'-template-name').value='';
   templateMessage(w,'Enter a name, edit the tasks if needed, then select Save Template.');
   refreshTemplateSaveControl(w);$(w+'-template-name').focus();return;
  }
  $(w+'-template-new').hidden=true;
  if(choice)openTemplate(w);
 });
 document.querySelector('[data-template-save="'+w+'"]').onclick=()=>saveTemplate(w);
 $(w+'-template-name').addEventListener('input',()=>refreshTemplateSaveControl(w));
 // Existing Save/Load controls use the same visible library rather than a text prompt.
 document.querySelector('[data-save-table="'+w+'"]').onclick=()=>{saveTemplate(w)};
 document.querySelector('[data-load-table="'+w+'"]').onclick=async()=>{await openTemplate(w)};
 document.querySelector('[data-delete-table="'+w+'"]').onclick=async()=>{
  const selection=$(w+'-template-select').value;
  if(!selection.startsWith('saved:')){templateMessage(w,'Select a saved custom table to delete. Original templates are protected.');return}
  const name=selection.slice(6);
  if(!await confirmTemplateAction({title:'Delete Saved Template · '+(w==='follow'?'Table 02':'Table 01'),message:'Permanently delete the saved template “'+name+'”?',detail:'This cannot be undone. Your current workspace tasks will not be deleted.',action:'Delete Saved Template',danger:true}))return;
  const next={...library,[w]:{...library[w]}};delete next[w][name];
  if(!write(T,next))return;
  library=next;refreshTemplateChoices(w);deleteVisible.hidden=true;$(w+'-template-new').hidden=true;templateBaseline[w]=null;
  templateMessage(w,'Deleted saved template: '+name+'. Current workspace tasks were not changed.');
 };
});


// V12-174 · Inline rename: no browser prompts and no duplicate create/load controls.
['contract','follow'].forEach(w=>{
 const panel=$(w+'-template-library');if(!panel)return;
 const picker=$(w+'-template-select');
 const form=$(w+'-template-new');
 const input=$(w+'-template-name');
 const save=form.querySelector('[data-template-save]');
 const rename=document.createElement('button');rename.type='button';rename.className='mct-template-rename';rename.textContent='Rename Template';
 const renameSave=document.createElement('button');renameSave.type='button';renameSave.className='mct-template-rename-save';renameSave.textContent='Save Renamed Template';renameSave.hidden=true;
 const controls=panel.querySelector('.re-template-controls');
 controls.insertBefore(rename,form);
 form.appendChild(renameSave);
 let previousName='';
 function sync(){
  const choice=picker.value;
  const saved=choice.startsWith('saved:');
  rename.disabled=!saved;
  rename.title=saved?'Change the selected template name without changing tasks':'Select one of your own saved templates to rename';
  if(!saved&&previousName){previousName='';renameSave.hidden=true;save.hidden=false;}
 }
 picker.addEventListener('change',()=>{previousName='';renameSave.hidden=true;save.hidden=false;sync();});
 sync();
 rename.onclick=()=>{
  
  if(!picker.value.startsWith('saved:')){templateMessage(w,'Select a saved personal template.');return;}
  previousName=picker.value.slice(6);
  form.hidden=false;input.value=previousName;
  save.hidden=true;renameSave.hidden=false;
  templateMessage(w,'Edit the name, then click Save Renamed Template. The tasks will not change.');
  input.focus();input.select();
 };
 renameSave.onclick=()=>{
  const old=previousName;
  const nextName=input.value.trim();
  if(!old||!library[w]?.[old]){templateMessage(w,'Select a saved template first.');return;}
  if(!nextName||nextName.length>70){templateMessage(w,'Enter a name between 1 and 70 characters.');input.focus();return;}
  if(nextName!==old&&Object.prototype.hasOwnProperty.call(library[w],nextName)){templateMessage(w,'That name already exists. Choose another.');return;}
  if(nextName!==old){
   const next={...library,[w]:{...library[w]}};
   next[w][nextName]=next[w][old];delete next[w][old];
   if(!write(T,next)){templateMessage(w,'Could not save the new name.');return;}
   library=next;
   if(personalDefaults[w]?.name===old){personalDefaults[w]={...personalDefaults[w],name:nextName};persistPersonalDefaults();const label=$(w+'-personal-default-note');if(label)label.textContent='My Default: '+nextName;}
  }
  previousName='';renameSave.hidden=true;save.hidden=false;
  refreshTemplateChoices(w,'saved:'+nextName);sync();refreshTemplateSaveControl(w);
  templateMessage(w,'Template renamed to "'+nextName+'". Its tasks were preserved.');
 };
});

document.querySelectorAll('[data-target]').forEach(b=>b.onclick=()=>$(b.dataset.target).scrollIntoView({behavior:'smooth',block:'start'}));
// V11-153 · One validation authority for Table 01 / Table 02 / Both Tables.
// Table choice and confirmed task availability are separate conditions.
function emailConfirmedGroups(){
 const w=$('email-table').value;
 const keys=w==='both'?['contract','follow']:(['contract','follow'].includes(w)?[w]:[]);
 // Both Tables means BOTH must contain selected and confirmed tasks.
 if(!keys.length||keys.some(k=>!$(k+'-confirm')?.checked||!state[k].some(t=>t.selected)))return [];
 return keys.map(k=>({w:k,tasks:state[k].filter(t=>t.selected)}));
}
const emailValid=s=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((s||'').trim());
function emailReady(){
 return emailConfirmedGroups().length>0 && emailValid($('email-to').value) &&
  !!$('email-role').value && ($('email-role').value!=='Other'||!!$('role-other').value.trim()) &&
  !!$('email-subject').value.trim() && !!$('email-message').value.trim();
}
// Exposed only to page-local guides, with no changes to shared site components.
window.MCTCommunication={ready:emailReady,groups:emailConfirmedGroups};
const emailFields=['email-to','email-role','role-other','email-subject','email-message'];
function capture(){const w=$('email-table').value;if(!w)return;state.drafts[w]={to:$('email-to').value,role:$('email-role').value,roleOther:$('email-role').value==='Other'?$('role-other').value:'',subject:$('email-subject').value,message:$('email-message').value};save()}
function loadDraft(){const b=$('email-save');if(b){b.textContent='Save Draft';b.classList.remove('re-draft-saved')}const st=$('email-status');if(st){st.textContent='';st.classList.remove('re-draft-success')}const d=state.drafts[$('email-table').value]||{};$('email-to').value=d.to||'';$('email-role').value=d.role||'';$('role-other').value=d.role==='Other'?(d.roleOther||''):'';$('role-other-wrap').hidden=d.role!=='Other';$('email-subject').value=d.subject??'Closing Timeline Update';$('email-message').value=d.message??'Please review the selected tasks and deadlines below.';$('email-result').hidden=true}
$('email-table').onchange=()=>{loadDraft()};emailFields.forEach(id=>$(id).addEventListener('change',capture));emailFields.forEach(id=>$(id).addEventListener('input',()=>{const b=$('email-save');if(b){b.textContent='Save Draft';b.classList.remove('re-draft-saved')} $('email-status').classList.remove('re-draft-success')}));
$('email-save').onclick=()=>{capture();const table=$('email-table').value;const ok=!!table&&!!state.drafts[table];const status=$('email-status');status.textContent=ok?'✓ Draft Saved — '+(table==='contract'?'Table 01':table==='follow'?'Table 02':'Both Tables')+'. Saved in this browser.':'Choose a table before saving.';status.classList.toggle('re-draft-success',ok);const b=$('email-save');b.textContent=ok?'✓ Draft Saved':'Save Draft';b.classList.toggle('re-draft-saved',ok)};
$('email-clear-subject').onclick=()=>{$('email-subject').value='';capture()};$('email-clear-message').onclick=()=>{$('email-message').value='';capture()};
function message(){
 if(!emailReady()){$('email-status').textContent='Confirm the chosen tasks and complete recipient, role, subject and message.';return null}
 capture();const groups=emailConfirmedGroups();
 const tasks=groups.map(g=>(g.w==='contract'?'Closing Timeline Summary':'Follow-Up Summary')+'\n'+
  g.tasks.map((t,i)=>(i+1)+'. '+t.name+' | '+t.days+' days | '+(due(t)||'Set dates')+' | '+(t.done?'Done':'Pending')).join('\n'));
 return $('email-message').value+'\n\n'+tasks.join('\n\n')+'\n\nDates and deadlines must follow the signed contract.';
}
function emailTableData(){
 const groups=emailConfirmedGroups().map(({w,tasks})=>({w,tasks,cols:summaryLabels.map((label,i)=>({label,i})).filter(x=>summaryColumns[w][x.i]),title:w==='contract'?'Closing Timeline Summary':'Follow-Up Summary'}));
 if(!groups.length){$('email-status').textContent='Select and confirm tasks in each chosen table before previewing.';return null}
 return groups;
}
function previewFormattedEmail(){
 if(!emailReady()){$('email-result').hidden=true;$('email-status').textContent='Complete the required recipient details and confirm the selected tasks before Preview Email.';return null}
 capture();const groups=emailTableData();if(!groups)return null;
 const panel=$('email-result');panel.replaceChildren();panel.classList.add('re-email-formatted');
 const intro=el('p',$('email-message').value);intro.style.whiteSpace='pre-wrap';panel.append(intro);
 groups.forEach(data=>{
  panel.append(el('h4',data.title));const table=el('table');table.className='re-summary-table';
  const head=el('tr');data.cols.forEach(c=>{const th=el('th',c.label);th.style.cssText='background:#f5e6bd;color:#17384c;text-align:center;border:1px solid #d6e2e6;padding:6px 8px;font:800 12px Arial,sans-serif;';head.append(th)});table.append(head);
  data.tasks.forEach((task,i)=>{const tr=el('tr');const values=summaryValues(task,i);data.cols.forEach(c=>{const td=el('td',String(values[c.i]));td.style.cssText='text-align:'+(c.i===1||c.i===8?'left':'center')+';border:1px solid #d6e2e6;padding:6px 8px;font:12px Arial,sans-serif;vertical-align:middle;'+(c.i===1||c.i===8?'max-width:280px;overflow-wrap:anywhere;':'');tr.append(td)});table.append(tr)});
  panel.append(table);
 });
 panel.append(el('p','Dates and deadlines must follow the signed contract.'));
 panel.hidden=false;$('email-status').textContent='Formatted email preview — selected tasks and columns only.';return panel;
}
$('email-preview').onclick=()=>{const panel=previewFormattedEmail();if(panel)requestAnimationFrame(()=>panel.scrollIntoView({behavior:'smooth',block:'start'}));};
function copyRichLocally(panel){
 // Legacy clipboard command works in many file:// Chrome sessions when called from a click.
 const holder=document.createElement('div');
 holder.setAttribute('contenteditable','true');
 holder.style.cssText='position:fixed;left:-99999px;top:0;width:800px;opacity:0;pointer-events:none';
 holder.innerHTML=panel.innerHTML;
 document.body.appendChild(holder);
 const selection=window.getSelection(),range=document.createRange();
 const previous=[];
 for(let i=0;i<selection.rangeCount;i++)previous.push(selection.getRangeAt(i).cloneRange());
 let ok=false;
 try{range.selectNodeContents(holder);selection.removeAllRanges();selection.addRange(range);ok=document.execCommand('copy')===true}
 catch(e){}finally{selection.removeAllRanges();previous.forEach(r=>selection.addRange(r));holder.remove()}
 return ok;
}
$('email-copy').onclick=async()=>{
 if(!emailReady()){$('email-status').textContent='Complete the recipient details and confirm every selected table before copying.';return}
 const panel=previewFormattedEmail();if(!panel)return;
 const html='<div>'+panel.innerHTML+'</div>';
 const plain=message();let copied=false;
 try{
  if(navigator.clipboard?.write&&typeof ClipboardItem!=='undefined'){
   await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([html],{type:'text/html'}),'text/plain':new Blob([plain],{type:'text/plain'})})]);copied=true;
  }
 }catch(e){}
 if(!copied)copied=copyRichLocally(panel);
 if(copied){
  $('email-status').textContent='✓ Formatted table copied. Next: Open Email Draft, select its plain-text message body (not your signature), and paste with ⌘ + V.';
  copiedFormatted=true;guideEmail();return;
 }
 $('email-status').textContent='Automatic copy is blocked in this local browser. Select the formatted preview and press ⌘ + C, then paste into Mail.';
 copiedFormatted=false;emailOpened=false;guideEmail();
};
$('email-open').onclick=()=>{if(!emailReady()){$('email-status').textContent='Complete the recipient details and confirm the chosen tables first.';return}const m=message();if(!m)return;location.href='mailto:'+encodeURIComponent($('email-to').value)+'?subject='+encodeURIComponent($('email-subject').value)+'&body='+encodeURIComponent(m)};
function confirmContactDeletion(name){return confirmTemplateAction({title:'Delete Saved Contact',message:'Permanently delete the contact “'+name+'”?',detail:'This removes the saved contact from this browser. Existing email drafts and task tables will not be deleted.',action:'Delete Contact',danger:true});}
function newContact(){['contact-name','contact-email','email-to'].forEach(id=>{const f=$(id);if(f)f.value=''});$('contact-list').value='__new__';$('contact-name').focus();$('email-status').textContent='New contact: enter name and email, then select Save Contact.';}
function renderContactLibrary(){const panel=$('contact-library-items');if(!panel)return;panel.replaceChildren();const names=Object.keys(contacts).sort((a,b)=>a.localeCompare(b));if(!names.length){panel.textContent='No saved contacts yet. Choose + Create New Contact to add your first one.';return}names.forEach(name=>{const line=document.createElement('div');line.className='re-contact-library-row';const info=document.createElement('span');info.textContent=name+' · '+contacts[name];const edit=document.createElement('button');edit.type='button';edit.textContent='Select / Edit';edit.onclick=()=>{$('contact-list').value=name;$('contact-list').dispatchEvent(new Event('change',{bubbles:true}));$('contact-name').focus()};const del=document.createElement('button');del.type='button';del.textContent='Delete';del.className='re-danger';del.onclick=async()=>{if(!await confirmContactDeletion(name))return;const next={...contacts};delete next[name];if(!write(C,next))return;contacts=next;refreshContacts();if($('contact-name').value===name)newContact()};line.append(info,edit,del);panel.append(line)})}
$('contact-new').onclick=newContact;
$('contact-library-toggle').onclick=()=>{const panel=$('contact-library-panel');panel.hidden=!panel.hidden;renderContactLibrary()};
function refreshContacts(){const list=$('contact-list');list.replaceChildren();const opt=el('option','Select');opt.value='';list.append(opt);const fresh=el('option','+ Create New Contact');fresh.value='__new__';list.append(fresh);Object.keys(contacts).sort((a,b)=>a.localeCompare(b)).forEach(name=>{const o=el('option',name);o.value=name;list.append(o)});if(typeof renderContactLibrary==='function')renderContactLibrary()}
$('contact-save').onclick=()=>{const name=$('contact-name').value.trim(),email=$('contact-email').value.trim();if(!name||!email||!email.includes('@')){ $('email-status').textContent='Enter contact name and valid email';return}contacts[name]=email;write(C,contacts);refreshContacts();$('contact-list').value=name;$('email-to').value=email;capture()};
$('contact-list').onchange=()=>{const name=$('contact-list').value;if(name==='__new__'){newContact();return}if(!name){$('contact-name').value='';$('contact-email').value='';return}$('contact-name').value=name;$('contact-email').value=contacts[name]||'';$('email-to').value=contacts[name]||'';capture()};
$('contact-remove').onclick=async()=>{const name=$('contact-list').value;if(!name||!await confirmContactDeletion(name))return;const next={...contacts};delete next[name];if(!write(C,next))return;contacts=next;refreshContacts();$('contact-name').value='';$('contact-email').value=''};

// V11-111: reliably position Step 03 below the sticky shared header.
function navigateToCommunication(){
 const target=document.getElementById('communication');
 if(!target)return;
 const position=()=>{
  const header=document.getElementById('shared-header');
  const offset=(header?header.getBoundingClientRect().height:0)+18;
  const top=window.scrollY+target.getBoundingClientRect().top-offset;
  window.scrollTo({top:Math.max(0,top),behavior:'instant'});
 };
 position();
 requestAnimationFrame(position);
 setTimeout(position,120);
 setTimeout(()=>{position();document.getElementById('email-table')?.focus({preventScroll:true});document.dispatchEvent(new Event('mct-communication-entry'));},300);
}

function updateDays(){
 const a=fmt($('ws-ed').value),b=fmt($('ws-cd').value);
 let calendar='—',business='—';
 if(a&&b){
  calendar=Math.round((b-a)/86400000);
  const cursor=new Date(a),end=new Date(b),step=a<=b?1:-1;
  let n=0;
  while((step>0&&cursor<end)||(step<0&&cursor>end)){
   cursor.setDate(cursor.getDate()+step);
   if(cursor.getDay()!==0&&cursor.getDay()!==6)n+=step;
  }
  business=n;
 }
 $('ws-calendar-days').textContent=calendar;
 $('ws-business-days').textContent=business;
 refreshDailyCounters();
}
['ws-ed','ws-cd'].forEach(id=>$(id).addEventListener('change',updateDays));
['contract','follow'].forEach(w=>{
 const toggle=document.querySelector('[data-summary-toggle="'+w+'"]');
 toggle.onclick=()=>{const box=$(w+'-summary');if(!state[w].some(t=>t.selected)){status('Select at least one task in Table '+(w==='contract'?'01':'02'));return}box.hidden=!box.hidden;toggle.textContent=box.hidden?'Review Results →':'Hide Results ↑';if(!box.hidden)box.scrollIntoView({behavior:'smooth',block:'nearest'})};
 $(w+'-confirm').onchange=()=>{const checked=$(w+'-confirm').checked;summary(w);$(w+'-confirm').checked=checked;document.querySelector('[data-continue="'+w+'"]').disabled=!checked||!state[w].some(t=>t.selected);$(w+'-continue-note').textContent=checked?'Ready for Communication Center.':'Review and confirm this table to continue.'};
 document.querySelector('[data-continue="'+w+'"]').onclick=()=>{if(!state[w].some(t=>t.selected)||!$(w+'-confirm').checked)return;$('email-table').value=w;$('email-table').dispatchEvent(new Event('change',{bubbles:true}));navigateToCommunication();$('email-status').textContent='Table '+(w==='contract'?'01':'02')+' confirmed for preparation.'};
});
refreshContacts();refreshSetup();if(!db.active)status('Create or open a workspace to save your work');
})();

// V11-74: allow clicking anywhere inside either date field to open the native picker.
/* V12-42: Use native date input behavior; avoid reopening the picker on every click. */

/* V11-97: contextual action guidance. Does not override existing business handlers. */
(()=>{
 const $=id=>document.getElementById(id);
 const allowed=['ws-new','ws-open','ws-save','contact-save','email-save','email-preview','email-copy','email-open'];
 const value=id=>($(id)?.value||'').trim();
 const validEmail=v=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
 let lastContactEmail='';
 let lastRecipientAuto='';
 let contactSaved=false;
 let previewed=false;
 let draftSaved=false;
 let copiedFormatted=false;
 let setupSaved=!!$('ws-save')?.classList.contains('re-setup-saved');
 let emailOpened=false;
 const hint=$('next-action-hint');
 function recommend(id,msg){
  allowed.forEach(k=>$(k)?.classList.remove('re-next-action'));
  const button=id&&$(id);
  if(button&&!button.disabled)button.classList.add('re-next-action');
  if(hint)hint.textContent=msg||'';
 }
 function guideEmail(){
  const name=value('contact-name'),contact=value('contact-email'),recipient=value('email-to');
  const w=value('email-table');
  const selectedGroups=w==='both'?['contract','follow']:(w==='contract'||w==='follow'?[w]:[]);
  const counts=selectedGroups.map(k=>({key:k,count:document.querySelectorAll('#'+k+'-rows tr td:first-child input[type=checkbox]:checked').length,confirmed:!!$(k+'-confirm')?.checked}));
  const confirmed=(window.MCTCommunication?.groups()?.length||0)>0;
  const tasks=confirmed?counts.reduce((sum,g)=>sum+g.count,0):0;
  const label=w==='both'?'Both Tables':w==='contract'?'Table 01':w==='follow'?'Table 02':'Selected table';
  const title=$('re-guide-title'),detail=$('re-guide-detail'),icon=$('re-guide-icon'),panel=$('re-guidance'),nextTitle=$('re-guide-next-title');
  if(title)title.textContent=confirmed?label+' · Confirmed':label+' · Not confirmed';
  if(detail)detail.textContent=confirmed?tasks+' task'+(tasks===1?'':'s')+' selected · Ready to prepare email':tasks+' task'+(tasks===1?'':'s')+' selected · Confirm this table before preparing email';
  if(icon)icon.textContent=confirmed?'✓':'ⓘ';
  if(panel)panel.classList.toggle('re-guide-confirmed',confirmed);
  if(nextTitle)nextTitle.textContent='Next step';
  // V11-153: the final Communication Center guide controls action availability.
  if(!w){recommend(null,'NEXT · Choose Table 01, Table 02 or Both Tables.');return}
  if(!confirmed){recommend(null,'Select tasks and confirm at least one of the chosen tables before preparing the email.');return}
  if(!name&&!validEmail(recipient)){recommend(null,'NEXT · Choose a saved contact or enter a recipient email.');return}
  if(name&&!validEmail(contact)&&!validEmail(recipient)){recommend(null,'NEXT · Enter a valid Contact email or Recipient email.');return}
  if(name&&validEmail(contact)&&!contactSaved){recommend('contact-save','Save Contact — keep this recipient for future messages.');return}
  if(!validEmail(recipient)){recommend(null,'Enter a valid Recipient email to prepare the message.');return}
  if(!value('email-subject')||!value('email-message')){recommend(null,'Complete Subject and Message before continuing.');return}
  if(!previewed){recommend('email-preview','Preview Email — review the selected tasks before sending.');return}
  if(!draftSaved){recommend('email-save','Save Draft — preserve this message before opening your email app.');return}
  if(emailOpened){recommend(null,'Email draft opened. In Apple Mail, select only the plain-text message body, press ⌘ + V to paste your formatted table, review and send. Your email signature stays intact.');return}
  if(!copiedFormatted){recommend('email-copy','Copy Formatted Table — preserve the gold header, aligned columns and selected tasks in Apple Mail.');return}
  recommend('email-open','Open Email Draft — replace only the plain-text body with the copied formatted table using ⌘ + V. Keep your signature.');
 }
 function guideSetup(){
  const name=value('ws-name'),ed=value('ws-ed'),cd=value('ws-cd');
  if(name&&value('ws-role')&&ed&&cd&&value('ws-counting')&&!setupSaved){recommend('ws-save','Next: Save Setup / Apply Dates — update your task deadlines.');return}
  if(name&&!value('ws-role')){recommend(null,'Choose My role to continue.');return}
  if(name&&!ed){recommend(null,'Choose an Effective Date to continue.');return}
  if(name&&!cd){recommend(null,'Choose a Closing Date to continue.');return}
  if(name&&ed&&cd&&!value('ws-counting')){recommend(null,'Choose Deadline Counting to continue.');return}
  recommend(null,'Choose or create a workspace, then enter the contract dates.');
 }
 // Auto-fill only when the recipient is blank or still contains the previous automatic value.
 $('contact-email')?.addEventListener('input',()=>{
  const email=value('contact-email'),to=$('email-to');
  if(to&&(!to.value.trim()||to.value.trim()===lastRecipientAuto||to.value.trim()===lastContactEmail)){
   to.value=email;lastRecipientAuto=email;to.dispatchEvent(new Event('input',{bubbles:true}));
  }
  lastContactEmail=email;contactSaved=false;previewed=false;draftSaved=false;copiedFormatted=false;emailOpened=false;guideEmail();
 });
 $('contact-name')?.addEventListener('input',()=>{contactSaved=false;guideEmail()});
 ['email-to','email-role','email-subject','email-message','email-table'].forEach(id=>$(id)?.addEventListener('input',()=>{previewed=false;draftSaved=false;copiedFormatted=false;guideEmail()}));
 $('contact-list')?.addEventListener('change',()=>{contactSaved=true;previewed=false;draftSaved=false;copiedFormatted=false;emailOpened=false;setTimeout(guideEmail,0)});
 $('contact-save')?.addEventListener('click',()=>{if(value('contact-name')&&validEmail(value('contact-email'))){contactSaved=true;guideEmail();$('email-status').textContent='✓ Contact saved. Recipient email is ready.'}});
 $('email-preview')?.addEventListener('click',()=>{if(window.MCTCommunication?.ready?.()&&!$('email-result').hidden){previewed=true;guideEmail()}});
 $('email-save')?.addEventListener('click',()=>{draftSaved=true;emailOpened=false;guideEmail()});
 $('email-open')?.addEventListener('click',()=>{if(window.MCTCommunication?.ready?.()){emailOpened=true;setTimeout(guideEmail,0);}});
 ['email-clear-subject','email-clear-message','contact-remove'].forEach(id=>$(id)?.addEventListener('click',()=>{previewed=false;draftSaved=false;copiedFormatted=false;emailOpened=false;setTimeout(guideEmail,0)}));
 ['ws-name','ws-ed','ws-cd','ws-counting','ws-role'].forEach(id=>$(id)?.addEventListener('input',()=>{setupSaved=false;guideSetup()}));
 $('ws-save')?.addEventListener('click',()=>{if(value('ws-name')&&value('ws-ed')&&value('ws-cd')){setupSaved=true;guideSetup()}});
 ['ws-new','ws-open','ws-clear-dates','ws-delete'].forEach(id=>$(id)?.addEventListener('click',()=>setTimeout(()=>{setupSaved=!!$('ws-save')?.classList.contains('re-setup-saved');guideSetup()},0)));
 $('ws-list')?.addEventListener('change',()=>setTimeout(()=>{setupSaved=!!$('ws-save')?.classList.contains('re-setup-saved');guideSetup()},0));
 // Step 02: a single clearly highlighted next action in each independent table.
 function guideTable(w){
  const section=$(w+'-section');if(!section)return;
  const selected=Array.from(section.querySelectorAll('tbody tr')).filter(tr=>tr.querySelector('td:first-child input[type="checkbox"]')?.checked).length;
  const summary=$(w+'-summary');
  const toggle=section.querySelector('[data-summary-toggle="'+w+'"]');
  const cont=section.querySelector('[data-continue="'+w+'"]');
  const label=section.querySelector('.re-continue label');
  const checked=!!$(w+'-confirm')?.checked;
  [toggle,cont,label].forEach(x=>x?.classList.remove('re-next-action','re-next-confirm'));
  if(!selected)return;
  if(summary?.hidden){toggle?.classList.add('re-next-action');return}
  if(!checked){label?.classList.add('re-next-confirm');return}
  if(cont&&!cont.disabled)cont.classList.add('re-next-action');
 }
 function guideBothTables(){guideTable('contract');guideTable('follow')}
 ['contract','follow'].forEach(w=>{
  const section=$(w+'-section');
  section?.addEventListener('change',()=>setTimeout(guideBothTables,0));
  section?.addEventListener('click',()=>setTimeout(guideBothTables,0));
 });
 // Selection updates the summary without moving the operator's viewport.
 ['contract','follow'].forEach(w=>{
  $(w+'-confirm')?.addEventListener('change',event=>{
   if(!event.target.checked)return;
   setTimeout(()=>{
    const target=document.querySelector('[data-continue="'+w+'"]');
    if(target&&!target.disabled){
     target.scrollIntoView({behavior:'smooth',block:'center'});
     target.classList.add('re-ready-attention');
     setTimeout(()=>target.classList.remove('re-ready-attention'),2400);
    }
   },100);
  });
 });
 // Recalculate after rendering, including selection changes and summary opening.
 const observer=new MutationObserver(()=>{if(!window.__mctGuidePending){window.__mctGuidePending=true;requestAnimationFrame(()=>{window.__mctGuidePending=false;guideBothTables()})}});
 ['contract-rows','follow-rows'].forEach(id=>{if($(id))observer.observe($(id),{childList:true})});
 guideBothTables();
 // Guide the operator at the stage they are working in.
 $('setup')?.addEventListener('focusin',guideSetup);
 $('communication')?.addEventListener('focusin',guideEmail);
 document.querySelectorAll('#contract-section,#follow-section').forEach(section=>section.addEventListener('change',()=>setTimeout(guideEmail,0)));
 $('email-table')?.addEventListener('change',()=>setTimeout(guideEmail,0));
 document.querySelectorAll('[data-continue]').forEach(b=>b.addEventListener('click',()=>{previewed=false;draftSaved=false;copiedFormatted=false;emailOpened=false;setTimeout(guideEmail,0)}));
 guideEmail();
})();

/* V11-105: one active section, completed titles, and one next action. */
(()=>{
 const $=id=>document.getElementById(id);
 const steps=['setup','contract-section','follow-section','communication'];
 let active='setup';
 let emailReviewed=false;
 const chosen=w=>Array.from(document.querySelectorAll('#'+w+'-rows tr')).some(tr=>tr.querySelector('td:first-child input[type="checkbox"]')?.checked);
 const confirmed=w=>chosen(w)&&!!$(w+'-confirm')?.checked;
 const setupDone=()=>!!$('ws-save')?.classList.contains('re-setup-saved') && !!$('ws-name')?.value.trim() && !!$('ws-role')?.value && !!$('ws-ed')?.value && !!$('ws-cd')?.value;
 function update(){
  const done={'setup':setupDone(),'contract-section':confirmed('contract'),'follow-section':confirmed('follow'),'communication':emailReviewed};
  steps.forEach(id=>{
   const section=$(id),heading=section?.querySelector(':scope > h2, :scope > h3');if(!heading)return;
   heading.classList.toggle('re-step-complete',!!done[id]);
   heading.classList.toggle('re-step-current',id===active&&!done[id]);
   heading.classList.toggle('re-step-pending',id!==active&&!done[id]);
   let badge=heading.querySelector('.re-step-badge');if(!badge){badge=document.createElement('span');badge.className='re-step-badge';heading.append(badge)}
   badge.textContent=done[id]?'✓ Completed':id===active?'● Current step':'○ Pending';
  });
  // Never leave highlighted actions in another section while the operator is elsewhere.
  document.querySelectorAll('.re-next-action,.re-next-confirm').forEach(b=>{
   if(!b.closest('#'+active))b.classList.remove('re-next-action','re-next-confirm');
  });
 }
 function setActive(id){active=id;requestAnimationFrame(update)}
 steps.forEach(id=>{
  const sec=$(id);if(!sec)return;
  sec.addEventListener('focusin',()=>setActive(id));
  sec.addEventListener('click',()=>setActive(id));
  sec.addEventListener('change',()=>setTimeout(update,0));
 });
 document.querySelectorAll('.re-nav a').forEach(a=>a.addEventListener('click',()=>{
  const id=a.getAttribute('href')?.slice(1);setActive(id==='tasks'?'contract-section':id);
 }));
 document.querySelectorAll('[data-continue]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>setActive('communication'),50)));
 // Both tables are independent: completing Table 01 never forces Table 02.
 const followHint=document.createElement('p');
 followHint.className='re-optional-note';
 followHint.textContent='Optional: Table 02 can be completed later. You may send Table 01 independently.';
 $('follow-section')?.querySelector(':scope > h3')?.insertAdjacentElement('afterend',followHint);
 $('email-preview')?.addEventListener('click',()=>{if($('email-result')&&!$('email-result').hidden){emailReviewed=true;setTimeout(update,0)}});
 ['email-table','email-message','email-subject'].forEach(id=>$(id)?.addEventListener('input',()=>{emailReviewed=false;setTimeout(update,0)}));
 // A direct path back to confirmation when the email table is not yet confirmed.
 const guide=$('re-guidance');
 if(guide){
  const link=document.createElement('button');link.type='button';link.className='re-return-confirm';link.textContent='Go to table confirmation ↑';
  link.hidden=true;guide.insertAdjacentElement('afterend',link);
  const refresh=()=>{const w=$('email-table')?.value==='follow'?'follow':'contract';link.hidden=confirmed(w)||!chosen(w);link.dataset.target=w};
  link.addEventListener('click',()=>{
   const w=link.dataset.target||'contract';setActive(w+'-section');
   const target=$(w+'-confirm')?.closest('.re-continue');
   target?.scrollIntoView({behavior:'smooth',block:'center'});
   setTimeout(()=>$(w+'-confirm')?.focus({preventScroll:true}),400);
  });
  ['email-table','contract-confirm','follow-confirm'].forEach(id=>$(id)?.addEventListener('change',()=>setTimeout(refresh,0)));
  ['contract-section','follow-section'].forEach(id=>$(id)?.addEventListener('change',()=>setTimeout(refresh,0)));
  refresh();
 }
 setTimeout(update,150);
})();


/* V11-112: a single, visible, contextual instruction; never hide the next action. */
(()=>{
 const $=id=>document.getElementById(id);
 const steps=[['setup','01 · Manage Your Workspaces'],['contract-section','Table 01 · Contract Tasks & Deadlines'],['follow-section','Table 02 · Follow-Up Tasks'],['communication','03 · Communication Center']];
 const notices={
  'setup':'START HERE · Open or create your workspace, enter the dates, then Save Setup / Apply Dates.',
  'contract-section':'NEXT · Select the tasks to share, review the summary, and confirm Table 01.',
  'follow-section':'OPTIONAL · Select and confirm Table 02 when you want to send its follow-up tasks.',
  'communication':'NEXT · Preview the email, save your draft, copy the formatted table, and open your email app.'
 };
 let current='setup';
 const confirmed=w=>!!$(w+'-confirm')?.checked && !!$(w+'-rows')?.querySelector('tr td:first-child input:checked');
 const complete=id=>id==='setup'?!!$('ws-save')?.classList.contains('re-setup-saved') && !!$('ws-role')?.value && !!$('ws-ed')?.value && !!$('ws-cd')?.value:id==='contract-section'?confirmed('contract'):id==='follow-section'?confirmed('follow'):false;
 function refresh(){
  steps.forEach(([id])=>{
   const sec=$(id), heading=sec?.querySelector(':scope > h2,:scope > h3');
   if(!heading)return;
   let strip=sec.querySelector(':scope > .re-step-instruction');
   if(!strip){strip=document.createElement('div');strip.className='re-step-instruction';strip.setAttribute('role','status');heading.insertAdjacentElement('afterend',strip)}
   const done=complete(id);
   strip.textContent=done?'✓ COMPLETED · You can continue to the next step.':notices[id];
   strip.classList.toggle('re-instruction-active',id===current&&!done);
   strip.classList.toggle('re-instruction-done',done);
   strip.classList.toggle('re-instruction-idle',id!==current&&!done);
   heading.classList.toggle('re-step-current',id===current&&!done);
   heading.classList.toggle('re-step-complete',done);
   heading.classList.toggle('re-step-pending',id!==current&&!done);
   const badge=heading.querySelector('.re-step-badge');if(badge)badge.textContent=done?'✓ Completed':id===current?'● START / CONTINUE HERE':'○ Pending';
  });
  ['contract','follow'].forEach(w=>{
   const section=$(w==='contract'?'contract-section':'follow-section');
   let jump=section?.querySelector('.re-jump-confirm');
   if(!jump&&section){
    jump=document.createElement('button');jump.type='button';jump.className='re-jump-confirm';jump.textContent='↓ Review & Confirm This Table';
    section.querySelector('.re-review-bar')?.insertAdjacentElement('afterend',jump);
    jump.addEventListener('click',()=>{
     current=w==='contract'?'contract-section':'follow-section';
     const target=$(w+'-confirm')?.closest('.re-continue');
     target?.scrollIntoView({behavior:'smooth',block:'center'});
     setTimeout(()=>$(w+'-confirm')?.focus({preventScroll:true}),400);
     refresh();
    });
   }
   if(jump){jump.hidden=!section.querySelector('#'+w+'-rows tr td:first-child input:checked')||confirmed(w);}
  });
 }
 function go(id){current=id;refresh()}
 steps.forEach(([id])=>{
  const section=$(id);if(!section)return;
  section.addEventListener('focusin',()=>go(id));
  section.addEventListener('click',()=>go(id));
  section.addEventListener('change',()=>setTimeout(refresh,25));
 });
 ['contract','follow'].forEach(w=>{
  $(w+'-confirm')?.addEventListener('change',()=>{
   go(w==='contract'?'contract-section':'follow-section');
   if(confirmed(w)){
    const b=document.querySelector('[data-continue="'+w+'"]');
    b?.scrollIntoView({behavior:'smooth',block:'center'});
   }
  });
  document.querySelector('[data-continue="'+w+'"]')?.addEventListener('click',()=>{
   if(!confirmed(w))return;
   go('communication');
   const target=$('communication');
   const position=()=>{
    const h=$('shared-header')?.getBoundingClientRect().height||70;
    window.scrollTo({top:Math.max(0,window.scrollY+target.getBoundingClientRect().top-h-18),behavior:'instant'});
   };
   requestAnimationFrame(position);setTimeout(position,170);setTimeout(position,360);
  });
 });
 ['ws-save','ws-open','ws-new'].forEach(id=>$(id)?.addEventListener('click',()=>setTimeout(refresh,60)));
 document.querySelectorAll('.re-nav a').forEach(a=>a.addEventListener('click',()=>{
  const id=a.getAttribute('href')?.slice(1);go(id==='tasks'?'contract-section':id);
 }));
 $('email-preview')?.addEventListener('click',()=>go('communication'));
 refresh();
})();

/* V11-169: visual guidance never changes task selection. */
function updateTaskGuidance(kind){
 const section=document.getElementById(kind==='contract'?'contract-section':'follow-section');
 if(!section)return;
 const boxes=[...section.querySelectorAll('tbody tr td:first-child input[type="checkbox"]')];
 const any=boxes.some(b=>b.checked);
 // Leave every row and checkbox visually neutral until the operator acts.
 section.querySelectorAll('.re-first-task-guide').forEach(el=>el.classList.remove('re-first-task-guide'));
 const toggle=section.querySelector('[data-summary-toggle="'+kind+'"]');
 if(toggle)toggle.classList.toggle('re-next-action',any);
 const review=section.querySelector('.re-review');
 if(review)review.innerHTML=any
 ?'<strong>Next: Open Summary &amp; Review</strong><p>Review only the selected tasks, then confirm this table.</p>'
 :'<strong>Select the tasks you want to share</strong><p>Check the boxes in the Select column. Then open Summary &amp; Review and confirm this table.</p>';
}
document.addEventListener('change',e=>{
 if(e.target.matches('#contract-rows input[type="checkbox"]'))updateTaskGuidance('contract');
 if(e.target.matches('#follow-rows input[type="checkbox"]'))updateTaskGuidance('follow');
});
document.addEventListener('click',e=>{
 if(e.target.closest('[data-select],[data-clear],[data-restore],[data-add]'))
  setTimeout(()=>{updateTaskGuidance('contract');updateTaskGuidance('follow')},0);
});
window.addEventListener('load',()=>{updateTaskGuidance('contract');updateTaskGuidance('follow')});

/* V11-115: after a successful save, move the operator to the next real task. */
(()=>{
 const saveButton=document.getElementById('ws-save');
 const target=document.getElementById('contract-section');
 if(!saveButton||!target)return;
 saveButton.addEventListener('click',()=>{
  if(!saveButton.classList.contains('re-setup-saved'))return; // never advance on invalid or failed save
  const heading=target.querySelector(':scope > h3');
  const instruction=target.querySelector(':scope > .re-step-instruction');
  document.querySelectorAll('.re-guided-next-section').forEach(el=>el.classList.remove('re-guided-next-section'));
  heading?.classList.add('re-guided-next-section');
  if(instruction){instruction.textContent='NEXT STEP · Select the tasks to share in Table 01, review the summary and confirm this table.';instruction.classList.add('re-guided-next-instruction')}
  const badge=heading?.querySelector('.re-step-badge');if(badge)badge.textContent='● CONTINUE HERE';
  // No artificial NEXT button: guide the first unchecked box without selecting it.
  const obsolete=target.querySelector('#re-start-contract');
  if(obsolete)obsolete.remove();
  const guidance=target.querySelector('.re-review');
  if(guidance)guidance.innerHTML='<strong>Select the tasks you want to share</strong><p>Check the boxes in the Select column. Then open Summary &amp; Review and confirm this table.</p>';
  updateTaskGuidance('contract');
  setTimeout(()=>{
   const top=target.getBoundingClientRect().top+window.scrollY-118;
   window.scrollTo({top:Math.max(0,top),behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
  },180);
 });
})();


/* V12-31: Editable new-project field, separate from saved-workspace selection. */
(()=>{
 const $=id=>document.getElementById(id);
 const list=$('ws-list'),name=$('ws-name'),create=$('ws-new'),open=$('ws-open');
 if(!list||!name||!create||!open)return;
 const hint=document.createElement('p');
 hint.id='re-field-guide';hint.setAttribute('role','status');hint.setAttribute('aria-live','polite');
 document.querySelector('#setup .re-dates-priorities-row')?.insertAdjacentElement('afterend',hint);
 const showHint=(message,kind='pending')=>{
   hint.textContent=message;
   hint.dataset.state=kind;
 };
 const refreshHint=()=>{
   const active=!!document.querySelector('#ws-list')?.value && !!document.querySelector('#ws-name')?.value.trim();
   const saved=!!document.querySelector('#ws-save')?.classList.contains('re-setup-saved');
   if(saved){showHint('✓ SETUP COMPLETED · Dates applied. Select Next → to continue.','complete');return}
   if(active){showHint('WORKSPACE CREATED · Complete your role and contract dates, then select Save Setup / Apply Dates.');return}
   showHint('Select an existing workspace or create a new project.');
 };
 const update=()=>{
   const selected=!!list.value && list.value!=='__new__';
   name.readOnly=selected;
   name.classList.toggle('mct-name-locked',selected);
   name.setAttribute('aria-readonly',String(selected));
   name.placeholder=selected?'Selected workspace name':'Type a new workspace name';
   create.textContent='+ Create Workspace';
   refreshHint();
 };
 list.addEventListener('change',()=>setTimeout(update,0));
 create.addEventListener('click',e=>{
   if(list.value && list.value!=='__new__'){
     e.stopImmediatePropagation();
     hint.textContent='To create a new workspace, first choose Select from the list.';
     list.focus();return;
   }
   if(!name.value.trim()){
     e.stopImmediatePropagation();
     hint.textContent='Type a project name in the field, then click Create Workspace.';
     name.focus();return;
   }
   if([...list.options].some(o=>o.value===name.value.trim())){
     e.stopImmediatePropagation();hint.textContent='That name already exists. Select and open it, or choose a different name.';name.focus();return;
   }
   setTimeout(()=>{update();refreshHint();},40);
 },true);
 open.addEventListener('click',()=>setTimeout(()=>{
   update();refreshHint();
 },40));
 $('ws-delete')?.addEventListener('click',()=>setTimeout(update,100));
 ['ws-role','ws-ed','ws-cd','ws-counting'].forEach(id=>{
   $(id)?.addEventListener('input',()=>setTimeout(refreshHint,0));
   $(id)?.addEventListener('change',()=>setTimeout(refreshHint,0));
 });
 $('ws-save')?.addEventListener('click',()=>setTimeout(refreshHint,0));
 $('ws-clear-dates')?.addEventListener('click',()=>setTimeout(refreshHint,0));
 update();
})();

// V11-130: sequential guidance, while retaining independent table email delivery.
(()=>{
 const $=id=>document.getElementById(id);
 const contract=document.querySelector('[data-continue="contract"]');
 const follow=document.querySelector('[data-continue="follow"]');
 const skip=$('follow-skip');
 const go=id=>{
  const target=$(id);if(!target)return;
  const header=document.querySelector('header')?.getBoundingClientRect().height||80;
  window.scrollTo({top:Math.max(0,window.scrollY+target.getBoundingClientRect().top-header-18),behavior:'smooth'});
 };
 const update=()=>{
  const confirmed=!!$('contract-confirm')?.checked && !!document.querySelector('#contract-rows input[type="checkbox"]:checked');
  const followConfirmed=!!$('follow-confirm')?.checked && !!document.querySelector('#follow-rows input[type="checkbox"]:checked');
  skip.hidden=!confirmed || followConfirmed;
  skip.classList.toggle('re-next-action',confirmed && !followConfirmed);
 };
 contract?.addEventListener('click',e=>{
  if(contract.disabled)return;
  e.preventDefault();e.stopImmediatePropagation();
  go('follow-section');
 },true);
 skip?.addEventListener('click',()=>{
  if(skip.hidden)return;
  $('email-table').value='contract';
  $('email-table').dispatchEvent(new Event('change',{bubbles:true}));
  go('communication');
 });
 $('follow-confirm')?.addEventListener('change',()=>setTimeout(update,0));
 document.querySelector('#follow-section')?.addEventListener('change',()=>setTimeout(update,0));
 $('contract-confirm')?.addEventListener('change',()=>setTimeout(update,0));
 document.querySelector('#contract-section')?.addEventListener('change',()=>setTimeout(update,0));
 update();
})();


/* V11-153: unified three-choice Communication Center wizard, validated against real selected and confirmed tasks. */
(()=>{
 'use strict';
 const $=id=>document.getElementById(id);
 const section=$('communication');if(!section)return;
 const note=$('email-wizard-note'),table=$('email-table');
 const valid=s=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((s||'').trim());
 const val=id=>($(id)?.value||'').trim();
 const hidePreview=()=>{$('email-result').hidden=true};
 const ready=()=>!!window.MCTCommunication?.ready();
 const groups=()=>window.MCTCommunication?.groups()||[];
 let reviewed=false,saved=false,copied=false,opened=false;
 let awaitTableChoice=true; // On arrival, ask the operator to review/choose the table, even if preselected.
 let awaitContactChoice=false; // After a deliberate table choice, highlight Saved contact.
 let subjectVisited=false, messageVisited=false;
 // Pre-filled text still needs an explicit review in the guided sequence.
 function resetCompositionReview(){subjectVisited=false;messageVisited=false;}
 const steps={
  'email-table':'NEXT · Choose Table 01, Table 02 or Both Tables.',
  'contact-list':'NEXT · Choose a saved contact or enter a recipient email.',
  'contact-name':'NEXT · Enter the name of the new contact.',
  'contact-email':'NEXT · Enter a valid contact email.',
  'email-to':'NEXT · Enter or confirm the recipient email.',
  'email-role':'NEXT · Select Role / Relationship.',
  'role-other':'NEXT · Specify the role or relationship.',
  'email-subject':'NEXT · Complete the subject.',
  'email-message':'NEXT · Complete the message.',
  'email-preview':'NEXT · Preview Email — review the recipient and the confirmed tasks.',
  'email-save':'NEXT · Save Draft.',
  'email-copy':'NEXT · Copy Formatted Table.',
  'email-open':'NEXT · Open Email Draft, review and send.'
 };
 function guide(){
  const chosen=['contract','follow','both'].includes(table.value);
  const canPreview=ready();
  ['email-preview','email-preview-shortcut'].forEach(id=>{const b=$(id);if(b){b.disabled=!canPreview;b.setAttribute('aria-disabled',String(!canPreview));}});
  const copy=$('email-copy'),open=$('email-open');if(copy)copy.disabled=!(canPreview&&reviewed&&saved);if(open)open.disabled=!(canPreview&&reviewed&&copied);
  section.querySelectorAll('.re-wizard-current,.re-wizard-button').forEach(el=>el.classList.remove('re-wizard-current','re-wizard-button'));
  let target='',message='';
  if(!chosen||awaitTableChoice)target='email-table';
  // Immediately move the yellow guidance from Table to send to Saved contact,
  // regardless of whether tasks have been confirmed yet.
  else if(awaitContactChoice||(!val('contact-list')&&!valid(val('email-to'))))target='contact-list';
  else if(val('contact-list')==='__new__'&&!val('contact-name'))target='contact-name';
  else if(val('contact-list')==='__new__'&&!valid(val('contact-email')))target='contact-email';
  else if(!valid(val('email-to')))target='email-to';
  else if(!val('email-role'))target='email-role';
  else if(val('email-role')==='Other'&&!val('role-other'))target='role-other';
  else if(!val('email-subject')||!subjectVisited)target='email-subject';
  else if(!val('email-message')||!messageVisited)target='email-message';
  else if(!groups().length){
   message=table.value==='both'?'NEXT · Select and confirm tasks in BOTH tables before Preview Email.':'NEXT · Select and confirm tasks in the chosen table before Preview Email.';
  }
  else if(!reviewed)target='email-preview';
  else if(!saved)target='email-save';
  else if(!copied)target='email-copy';
  else if(!opened)target='email-open';
  else message='✓ Message prepared. Review the draft in your email application before sending.';
  const field=$(target);
  if(field){const decorate=['email-preview','email-save','email-copy','email-open'].includes(target)?'re-wizard-button':'re-wizard-current';(field.closest('label')||field).classList.add(decorate)}
  // V11-156: once Message is the guided step and the email is valid, highlight Preview simultaneously.
  if(target==='email-message' && canPreview){
   ['email-preview-shortcut','email-preview'].forEach(id=>$(id)?.classList.add('re-wizard-button'));
  }
  if(target==='email-preview' && canPreview){$('email-preview-shortcut')?.classList.add('re-wizard-button');}
  if(note)note.textContent=message||steps[target]||'';
  const count=groups().reduce((sum,g)=>sum+g.tasks.length,0);
  const counter=$('email-selected-count');if(counter)counter.textContent=count+' confirmed task'+(count===1?'':'s')+' ready to send';
  if(!canPreview)$('email-result').hidden=true;
  const next=$('email-next-shortcut');if(next)next.textContent=canPreview?'NEXT · Preview Email — review selected confirmed tasks.':!chosen?'NEXT · Choose a table to send.':!groups().length?'Preview is locked until the chosen tasks are confirmed.':'Complete recipient, role, subject and message to preview.';
 }
 // Arrival should NEVER erase a selection that came from Table 01 or Table 02.
 document.addEventListener('mct-communication-entry',()=>{awaitTableChoice=true;awaitContactChoice=false;reviewed=false;saved=false;copied=false;opened=false;resetCompositionReview();guide()});
 table.addEventListener('change',()=>{hidePreview();awaitTableChoice=false;awaitContactChoice=!!table.value;reviewed=false;saved=false;copied=false;opened=false;resetCompositionReview();guide()});
 // Do not advance merely because the preselected dropdown received focus.
 // Only an actual selection change advances the guide to Saved contact.

 ['contact-list','contact-name','contact-email','email-to','email-role','role-other','email-subject','email-message'].forEach(id=>{
  const field=$(id);for(const event of ['change','input'])field?.addEventListener(event,()=>{if(id==='contact-list'||id==='email-to')awaitContactChoice=false;if(id==='email-role'){resetCompositionReview();}if(id==='email-subject')subjectVisited=true;if(id==='email-message')messageVisited=true;hidePreview();reviewed=false;copied=false;opened=false;guide();setTimeout(guide,0)})
 });
 ['contract','follow'].forEach(k=>{
  $(k+'-section')?.addEventListener('change',()=>setTimeout(()=>{hidePreview();reviewed=false;guide()},0));
  $(k+'-confirm')?.addEventListener('change',()=>setTimeout(guide,0));
 });
 // A pre-filled subject/message is acknowledged by entering or leaving its field.
 ['email-subject','email-message'].forEach(id=>{
  const field=$(id);field?.addEventListener('focus',()=>{if(id==='email-subject')subjectVisited=true;else messageVisited=true;guide()});
  field?.addEventListener('blur',()=>{if(id==='email-subject')subjectVisited=true;else messageVisited=true;guide()});
 });
 $('email-preview')?.addEventListener('click',()=>{if(ready()){reviewed=true;setTimeout(guide,0)}});
 $('email-save')?.addEventListener('click',()=>{if(ready()&&reviewed){saved=true;setTimeout(guide,0)}});
 $('email-copy')?.addEventListener('click',()=>{if(ready()&&reviewed){copied=true;setTimeout(guide,0)}});
 $('email-open')?.addEventListener('click',()=>{if(ready()){opened=true;setTimeout(guide,0)}});
 ['email-clear-subject','email-clear-message','contact-new','contact-save','contact-remove'].forEach(id=>$(id)?.addEventListener('click',()=>setTimeout(guide,0)));
 const observer=new MutationObserver(()=>setTimeout(()=>{hidePreview();reviewed=false;guide()},0));
 ['contract-rows','follow-rows'].forEach(id=>{const node=$(id);if(node)observer.observe(node,{childList:true})});
 // Print only selected and CONFIRMED groups; Both Tables uses two sections, not an undefined 'both-rows'.
 $('email-pdf')?.addEventListener('click',()=>{
  const chosen=groups();if(!chosen.length){$('email-status').textContent='Confirm the selected tasks first.';return}
  const safe=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const sections=chosen.map(({w,tasks})=>'<h2>'+safe(w==='contract'?'Closing Timeline Summary':'Follow-Up Summary')+'</h2><table><thead><tr><th>TASK / MILESTONE</th><th>DAYS</th><th>DUE DATE</th></tr></thead><tbody>'+tasks.map(t=>'<tr><td>'+safe(t.name)+'</td><td>'+safe(t.days)+'</td><td>'+safe((Array.from(document.querySelectorAll('#'+w+'-rows tr')).find(tr=>tr.querySelector('td:nth-child(3) input')?.value===t.name)?.querySelector('td:nth-child(6) input')?.value)||'Set dates')+'</td></tr>').join('')+'</tbody></table>').join('');
  const page='<!doctype html><html><head><meta charset="utf-8"><title>Closing Timeline</title><style>body{font:15px Arial;margin:38px;color:#163149}h2{color:#805008}table{border-collapse:collapse;width:100%;margin:16px 0 30px}th{background:#f8e7b7}td,th{border:1px solid #cbd7dd;padding:10px}</style></head><body><p>'+safe(val('email-message'))+'</p>'+sections+'<p>Dates and deadlines must follow the signed contract.</p></body></html>';
  const win=window.open('','_blank');if(!win){$('email-status').textContent='The browser blocked the print window.';return}
  win.document.open();win.document.write(page);win.document.close();win.focus();win.onload=()=>win.print();
 });
 guide();
})();

/* V11-139: custom relationship entry; stored in the contact's role field when supported. */
(()=>{const role=document.getElementById('email-role'),wrap=document.getElementById('role-other-wrap'),other=document.getElementById('role-other');if(!role||!wrap)return;function sync(){wrap.hidden=role.value!=='Other';if(wrap.hidden)other.value='';}role.addEventListener('change',sync);sync();})();


/* V11-171: previews are only visible after explicit, valid review. */
(()=>{const panel=document.getElementById('email-result');if(!panel)return;panel.hidden=true;const clear=()=>{panel.hidden=true;panel.replaceChildren()};['email-table','contract-confirm','follow-confirm','email-to','email-role','email-subject','email-message'].forEach(id=>document.getElementById(id)?.addEventListener('input',clear));document.querySelectorAll('#contract-section,#follow-section').forEach(el=>el.addEventListener('change',clear));})();
