/* V11-148: visible, accessible contextual help; does not replace existing button handlers. */
(()=>{
 const help=document.createElement('div');help.id='v148-help';help.setAttribute('role','tooltip');help.hidden=true;
 help.innerHTML='<div class="v148-help-heading"><span class="v148-help-icon">ⓘ</span><strong></strong></div><p></p><small>Help · Move the pointer away to close</small>';
 document.body.appendChild(help);
 let current=null;
 const extra={
 'ws-open':'Reload the selected saved workspace. Its role, dates and task records will be displayed. Use when you need to reopen the saved version.',
 'ws-new':'Create a new, separate workspace. Click Create New Workspace, enter its name, then complete the highlighted fields.',
 'ws-save':'Save the current role, dates and counting method, and update task deadlines. Use after completing the required fields or making changes.',
 'ws-clear-dates':'Remove the dates shown in this form. This does not delete the saved workspace unless you later save the changes.',
 'ws-delete':'Permanently delete the selected workspace after confirmation. Review the project name carefully.',
 'email-preview-shortcut':'Review the recipient, subject, message and selected tasks from Table 01, Table 02, or both before opening an email draft.',
 'email-table':'Choose Table 01, Table 02, or Both Tables. Only tasks selected in each table are included.',
 'ws-counting':'Choose Calendar Days or Business Days. The signed contract controls how deadlines must be counted.'
 };
 const action={add:'Add a new custom task to this table.',select:'Select all tasks in this table for review.',clear:'Uncheck selected tasks without deleting them.',sort:'Reorder tasks by due date.',restore:'Restore the original task list; check before replacing changes.', 'save-table':'Save the current table for later reuse.', 'load-table':'Load a previously saved table.', 'delete-table':'Delete a saved table version after confirmation.', 'summary-toggle':'Show or hide the summary of selected tasks.',continue:'Move to the next stage after confirmation.'};
 function description(el){if(extra[el.id])return extra[el.id];for(const [k,v] of Object.entries(action))if(el.hasAttribute('data-'+k))return v;return el.getAttribute('aria-description')||el.getAttribute('title')||''}
 function label(el){const l=el.closest('label');return (el.tagName==='BUTTON'?el.textContent:(l?.childNodes[0]?.textContent||el.getAttribute('aria-label')||el.id)).trim().replace(/\s+/g,' ').slice(0,80)}
 let hoverTimer=null;
 function position(el){
  const r=el.getBoundingClientRect(),pad=12,gap=12;
  const w=Math.min(330,window.innerWidth-2*pad);
  help.style.width=w+'px';help.style.maxHeight=Math.max(100,window.innerHeight-2*pad)+'px';
  const h=help.getBoundingClientRect().height;
  const candidates=[
   {x:r.right+gap,y:r.top,side:'right'},
   {x:r.left-w-gap,y:r.top,side:'left'},
   {x:r.left,y:r.top-h-gap,side:'top'},
   {x:r.left,y:r.bottom+gap,side:'bottom'}
  ];
  // Favor an adjacent free side, avoiding the field and visible viewport edges.
  const fits=c=>c.x>=pad&&c.x+w<=innerWidth-pad&&c.y>=pad&&c.y+h<=innerHeight-pad;
  const preferred=candidates.find(fits);
  const c=preferred||{x:Math.min(Math.max(r.left,pad),innerWidth-w-pad),y:Math.max(pad,Math.min(r.bottom+gap,innerHeight-h-pad))};
  help.style.left=c.x+'px';help.style.top=c.y+'px';
 }
 function show(el){const d=description(el);if(!d)return;current=el;help.querySelector('strong').textContent=label(el);help.querySelector('p').textContent=d;help.hidden=false;position(el)}
 function hide(){clearTimeout(hoverTimer);hoverTimer=null;help.hidden=true;current=null}
 const els=document.querySelectorAll('.re-main button,.re-main input,.re-main select,.re-main textarea');
 els.forEach(el=>{if(!description(el))return;
  el.addEventListener('mouseenter',()=>{hide();hoverTimer=setTimeout(()=>show(el),420)});
  el.addEventListener('mouseleave',hide);
  el.addEventListener('focus',()=>{hide();show(el)});
  el.addEventListener('blur',hide);
 });
 // Reuse the same positioning logic for the two template-library explanations.
 const libraryHelps=[...document.querySelectorAll('.re-template-pick')].map(section=>({
  section,tip:section.querySelector('.re-library-help'),trigger:section.querySelector('.re-template-controls select')
 })).filter(x=>x.tip&&x.trigger);
 let libTimer=null,activeLibrary=null;
 function hideLibrary(){clearTimeout(libTimer);libTimer=null;libraryHelps.forEach(x=>{x.tip.hidden=true;x.tip.classList.remove('re-help-visible')});activeLibrary=null}
 function positionLibrary(x){
  const r=x.trigger.getBoundingClientRect(),tip=x.tip,pad=12,gap=12;
  tip.style.width=Math.min(390,innerWidth-2*pad)+'px';
  const w=tip.getBoundingClientRect().width,h=tip.getBoundingClientRect().height;
  const options=[{x:r.right+gap,y:r.top},{x:r.left-w-gap,y:r.top},{x:r.left,y:r.top-h-gap},{x:r.left,y:r.bottom+gap}];
  const pos=options.find(p=>p.x>=pad&&p.x+w<=innerWidth-pad&&p.y>=pad&&p.y+h<=innerHeight-pad)
    ||{x:Math.max(pad,Math.min(r.left,innerWidth-w-pad)),y:Math.max(pad,Math.min(r.top-h-gap,innerHeight-h-pad))};
  tip.style.left=pos.x+'px';tip.style.top=pos.y+'px';
 }
 function showLibrary(x){hide();hideLibrary();activeLibrary=x;x.tip.hidden=false;x.tip.classList.add('re-help-visible');positionLibrary(x)}
 libraryHelps.forEach(x=>{
  x.tip.hidden=true;
  x.trigger.addEventListener('mouseenter',()=>{hideLibrary();libTimer=setTimeout(()=>showLibrary(x),420)});
  x.trigger.addEventListener('mouseleave',hideLibrary);
  x.trigger.addEventListener('focus',()=>showLibrary(x));
  x.trigger.addEventListener('blur',hideLibrary);
 });
 window.addEventListener('scroll',()=>{if(current)position(current);if(activeLibrary)positionLibrary(activeLibrary)},true);
 window.addEventListener('resize',()=>{if(current)position(current);if(activeLibrary)positionLibrary(activeLibrary)});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){hide();hideLibrary()}});
})();
