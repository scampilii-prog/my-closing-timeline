/* V12-83: precise alignment to the actual visible right-hand white panel.
   Visual only. No workflow, data, or task logic is changed. */
(()=>{
  const sidebar=()=>document.getElementById('mct-guide-sidebar');
  const main=()=>document.querySelector('.mct-guide-layout > main.shell.re-main');
  function update(){
    const side=sidebar(), content=main();
    if(!side||!content)return;
    if(window.innerWidth<=950){
      side.style.removeProperty('height');side.style.removeProperty('min-height');
      side.style.removeProperty('transform');return;
    }
    const heading=content.querySelector('.mct-workspace-heading');
    const candidates=['#setup','#tasks','#communication','#mct-guide-finish'];
    const visible=candidates.map(s=>content.querySelector(s)).find(el=>el && el.getClientRects().length && getComputedStyle(el).display!=='none');
    if(!heading||!visible)return;
    // Use the true rendered edges of the visible right-hand card, not the
    // surrounding main element, whose padding and margin are different.
    const top=heading.getBoundingClientRect().top;
    const bottom=visible.getBoundingClientRect().bottom;
    const current=side.getBoundingClientRect();
    const previous=parseFloat(side.dataset.mctAlignOffset||'0')||0;
    const naturalTop=current.top-previous;
    const offset=Math.round(top-naturalTop);
    const height=Math.max(0,Math.round(bottom-top));
    if(!Number.isFinite(height)||height<350)return;
    side.style.setProperty('transform',`translateY(${offset}px)`,'important');
    side.style.setProperty('height',`${height}px`,'important');
    side.style.setProperty('min-height','0px','important');
    side.dataset.mctAlignOffset=String(offset);
  }
  let scheduled=false;
  function schedule(){if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;update();});}
  window.addEventListener('load',schedule);
  window.addEventListener('resize',schedule);
  document.addEventListener('click',schedule);
  document.addEventListener('change',schedule);
  function init(){
    schedule();
    const content=main();
    if(content&&window.ResizeObserver)new ResizeObserver(schedule).observe(content);
    if(content&&window.MutationObserver)new MutationObserver(schedule).observe(content,{attributes:true,attributeFilter:['class','style','hidden'],subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
