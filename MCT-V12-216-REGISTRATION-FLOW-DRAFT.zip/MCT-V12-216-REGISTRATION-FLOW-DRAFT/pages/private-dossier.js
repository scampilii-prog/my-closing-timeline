(()=>{'use strict';
const button=document.getElementById('email-pdf');if(!button)return;
const groups={
 'Property & Contract':[['property-address','Property street address'],['property-unit','Unit / Suite'],['property-city','City'],['property-state','State'],['property-zip','ZIP code'],['property-county','County'],['property-mls','MLS number'],['property-parcel','Parcel / Folio ID'],['property-type','Property type'],['property-price','Purchase price'],['property-deposit','Escrow deposit'],['property-contract','Contract / transaction reference'],['property-possession','Possession / keys']],
 'Buyer & Seller':[['buyer-name','Buyer name(s)'],['buyer-phone','Buyer phone'],['buyer-email','Buyer email'],['seller-name','Seller name(s)'],['seller-phone','Seller phone'],['seller-email','Seller email']],
 'Title & Closing Company':[['title-company','Title / closing company'],['title-address','Company address'],['title-contact','Closing officer / responsible person'],['title-phone','Company phone'],['title-direct','Closing officer direct phone'],['title-email','Closing officer email'],['title-file','Title / escrow file number'],['title-attorney','Closing attorney (if applicable)']],
 'Agents & Brokers':[['listing-agent','Listing agent'],['listing-broker','Listing brokerage'],['listing-phone','Listing agent phone'],['listing-email','Listing agent email'],['buyer-agent','Buyer agent'],['buyer-broker','Buyer brokerage'],['buyer-agent-phone','Buyer agent phone'],['buyer-agent-email','Buyer agent email']],
 'Lender & Financing':[['lender','Lender / mortgage company'],['loan-officer','Loan officer'],['loan-phone','Loan officer phone'],['loan-email','Loan officer email'],['loan-type','Financing type'],['loan-approval','Loan approval deadline']],
 'Other Professionals':[['inspector','Inspector / phone'],['appraiser','Appraiser / phone'],['insurance','Insurance contact / phone'],['hoa','HOA / Condo association / manager'],['surveyor','Surveyor / phone'],['attorney','Attorney / phone'],['notary','Notary / RON contact']],
 'Closing & Delivery':[['closing-location','Closing location / address'],['closing-time','Closing time'],['walkthrough','Final walkthrough'],['keys','Keys / access / possession'],['utilities','Utilities / transfer notes'],['closing-instructions','Additional closing instructions']],
 'Private Notes':[['private-notes','Additional notes for private copy']]
};

const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
button.addEventListener('click',e=>{
 e.preventDefault();e.stopImmediatePropagation();
 const sections=Object.entries(groups).map(([title,fields])=>'<section><h2>'+esc(title)+'</h2><table>'+fields.map(([,label])=>'<tr><th>'+esc(label)+'</th><td>&nbsp;</td></tr>').join('')+'</table></section>').join('');
 const doc='<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Private Closing File - Blank Template</title><style>@page{size:letter;margin:14mm}body{font:12px Arial;color:#173149}h1{font-size:22px;border-bottom:3px solid #b99045;padding-bottom:12px}h2{font-size:15px;color:#79511a;margin-top:20px}table{width:100%;border-collapse:collapse}tr{break-inside:avoid}th,td{border:1px solid #cbd6df;padding:9px;text-align:left}th{width:40%;background:#f7f9fa}td{height:22px}p{line-height:1.5}section{break-inside:auto}</style></head><body><h1>Private Real Estate Closing File</h1><p>Blank template — for the operator’s own offline records. Save as PDF on your computer and complete it locally. Do not upload this completed file to the website or send it with the task-only email.</p>'+sections+'<p>Dates and deadlines must follow the signed contract. Keep this document secure.</p></body></html>';
 const w=window.open('','_blank');if(!w){document.getElementById('email-status').textContent='Please allow pop-ups to open the private PDF template.';return}
 w.document.open();w.document.write(doc);w.document.close();w.focus();
 document.getElementById('email-status').textContent='Blank private template opened. Save as PDF on your computer and complete it locally.';
},true);
})();
