/* V12-117: Reuse the existing Review Selected Tasks handler; no duplicate action. */
(() => {
 function start(){
  for(const kind of ['contract','follow']){
   const section=document.getElementById(kind+'-section');
   const cue=section?.querySelector('.mct-review-cue');
   const button=cue?.querySelector('.mct-review-cue-action');
   const heading=section?.querySelector('.mct-table-mode-heading');
   if(!cue||!button||!heading)continue;
   heading.insertBefore(button,heading.querySelector('.mct-fullview-button'));
   button.classList.add('mct-review-fixed-action');
   button.title='Jump to the selected tasks summary';
   const sync=()=>{button.hidden=cue.hidden;};
   new MutationObserver(sync).observe(cue,{attributes:true,attributeFilter:['hidden']});
   sync();
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
