/* V12-59: Clean section titles and explicit accessible step states. */
(()=>{
 'use strict';
 const titles=[['#setup > h2','Manage Your Workspaces'],['#tasks > h2','MY TASKS'],['#contract-section > h3','Contract Tasks & Deadlines'],['#follow-section > h3','Follow-Up Tasks'],['#communication > h2','Communication Center']];
 function cleanTitles(){
  titles.forEach(([selector,title])=>{
   const heading=document.querySelector(selector);
   if(!heading)return;
   if(heading.textContent.trim()!==title){heading.textContent=title;}
   heading.classList.add('mct-clean-title');
  });
 }
 cleanTitles();
 const sidebar=document.getElementById('mct-guide-sidebar');
 if(!sidebar)return;
 sidebar.querySelectorAll('[data-guide-item]').forEach((item)=>{
  const label=item.querySelector('strong');
  if(!label)return;
  const state=document.createElement('span');state.className='mct-step-label';state.setAttribute('aria-live','polite');
  label.after(state);
 });
 function update(){
  sidebar.querySelectorAll('[data-guide-item]').forEach(item=>{
   const state=item.querySelector('.mct-step-label');if(!state)return;
   const done=item.classList.contains('done');const current=item.classList.contains('active');
   const nextText=done?'✓ Completed':current?'● Current step':'';
   const nextClass='mct-step-label '+(done?'mct-state-done':current?'mct-state-current':'mct-state-available');
   if(state.textContent!==nextText)state.textContent=nextText;
   if(state.className!==nextClass)state.className=nextClass;
   const num=item.querySelector('.mct-guide-num');
   if(num){const nextNum=done?'✓':String(Number(item.dataset.guideItem)+1);if(num.textContent!==nextNum)num.textContent=nextNum;}
  });
 }
 update();
 const observer=new MutationObserver(()=>{update();cleanTitles();});
 sidebar.querySelectorAll('[data-guide-item]').forEach(item=>observer.observe(item,{attributes:true,attributeFilter:['class']}));
 // Keep the labels synchronized after the existing workflow changes.
 document.addEventListener('click',()=>queueMicrotask(update));
 document.addEventListener('change',()=>queueMicrotask(update));
})();
