/* V12-109: unobtrusive help on hover, focus and tap. */
(()=>{'use strict';
 const help=[
  ['.re-template-heading strong','Choose an original or saved template. You can also create your own table.'],
  ['.re-column-chooser > summary','Choose which columns appear in the summary sent for review. This does not remove data from your task table.'],
  ['.mct-fullview-button','Expand the table to edit comfortably. The compact table remains fully editable.'],
  ['.re-summary-heading h4','This summary contains only selected tasks. Review it before confirming the table.'],
  ['.re-continue label','Confirm the selected tasks for the Communication Center. This does not send an email.']
 ];
 const pop=document.createElement('div');pop.className='mct-help-pop';pop.hidden=true;document.body.append(pop);
 let current=null;
 function hide(){pop.hidden=true;current=null}
 function show(button,message){current=button;pop.textContent=message;pop.hidden=false;const r=button.getBoundingClientRect();const w=pop.offsetWidth;const left=Math.max(8,Math.min(window.innerWidth-w-8,r.left));pop.style.left=(left+window.scrollX)+'px';pop.style.top=(r.bottom+window.scrollY+7)+'px'}
 function attach(container,selector,message){container.querySelectorAll(selector).forEach(target=>{if(target.dataset.mctHelpAdded)return;target.dataset.mctHelpAdded='1';const b=document.createElement('button');b.type='button';b.className='mct-help-button';b.textContent='?';b.setAttribute('aria-label','Help: '+message);b.setAttribute('aria-expanded','false');target.insertAdjacentElement('afterend',b);b.addEventListener('mouseenter',()=>show(b,message));b.addEventListener('mouseleave',()=>{if(current===b)hide()});b.addEventListener('focus',()=>show(b,message));b.addEventListener('blur',()=>{if(current===b)hide()});b.addEventListener('click',e=>{e.stopPropagation();if(current===b&&!pop.hidden)hide();else show(b,message)});});}
 function refresh(){['contract','follow'].forEach(kind=>{const section=document.getElementById(kind+'-section');if(!section)return;help.forEach(([selector,message])=>attach(section,selector,message));const strip=section.querySelector(':scope > .re-step-instruction');if(strip)strip.hidden=true;const jump=section.querySelector('.re-jump-confirm');if(jump)jump.remove();});}
 document.addEventListener('click',e=>{if(!e.target.closest('.mct-help-button'))hide()});window.addEventListener('scroll',hide,true);window.addEventListener('resize',hide);
 const observer=new MutationObserver(()=>{if(!document.querySelector('.re-summary-heading h4:not([data-mct-help-added])'))return;observer.disconnect();refresh();observer.observe(document.getElementById('tasks')||document.body,{subtree:true,childList:true})});
 function start(){refresh();observer.observe(document.getElementById('tasks')||document.body,{subtree:true,childList:true});}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();