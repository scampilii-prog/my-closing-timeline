/* V12-126: Legacy auto-scroll disabled to prevent competing jumps. Confirmation state is handled by real-estate.js and summary-actions-v12-124.js. */
