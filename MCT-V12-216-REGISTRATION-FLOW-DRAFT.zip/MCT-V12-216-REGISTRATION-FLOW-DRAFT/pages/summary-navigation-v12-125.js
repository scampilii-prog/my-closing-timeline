/* V12-125: Clear summary navigation; no duplicate controls or confirmation required. */
(function(){'use strict';
function start(){
  ['contract','follow'].forEach(function(kind){
    const section=document.getElementById(kind+'-section');
    const summary=document.getElementById(kind+'-summary');
    const toggle=section?.querySelector('[data-summary-toggle="'+kind+'"]');
    if(!section||!summary||!toggle)return;
    const selected=()=>section.querySelectorAll('#'+kind+'-rows > tr > td:first-child input[type="checkbox"]:checked').length;
    function focusSummary(){
      const title=summary.querySelector('.re-summary-heading')||summary;
      const full=section.classList.contains('mct-expanded-table')?section:null;
      if(full){
        const y=full.scrollTop+title.getBoundingClientRect().top-full.getBoundingClientRect().top-56;
        full.scrollTo({top:Math.max(0,y),behavior:'smooth'});
      }else{
        const header=document.getElementById('shared-header');
        const dock=document.getElementById('mct-persistent-dashboard');
        const offset=Math.max(header?.getBoundingClientRect().bottom||0,dock?.getBoundingClientRect().bottom||0)+16;
        window.scrollTo({top:Math.max(0,window.scrollY+title.getBoundingClientRect().top-offset),behavior:'smooth'});
      }
    }
    toggle.onclick=function(){
      if(!selected()){toggle.textContent='↑ Go to Summary';return;}
      if(summary.hidden)summary.hidden=false;
      toggle.textContent='↑ Go to Summary';
      requestAnimationFrame(()=>requestAnimationFrame(focusSummary));
    };
    // Keep the action a navigation command, not a hide/show toggle.
    const labelObserver=new MutationObserver(function(){if(toggle.textContent!=='↑ Go to Summary')toggle.textContent='↑ Go to Summary';});
    labelObserver.observe(toggle,{childList:true,characterData:true,subtree:true});
    toggle.textContent='↑ Go to Summary';
    const actions=section.querySelector('.mct-summary-actions');
    const send=actions?.querySelector('.mct-action-send');
    if(send){
      send.title='Prepare an email in Communication Center; nothing is sent automatically';
      send.setAttribute('aria-label','Prepare selected tasks in Communication Center');
      send.addEventListener('click',function(){
        /* Original V12-124 handler owns navigation; this supplements visible status only. */
        const feedback=actions.querySelector('.mct-action-feedback');
        if(feedback&&selected())feedback.textContent='Opening Communication Center to prepare your email…';
      });
    }
  });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
