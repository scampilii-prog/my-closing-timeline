/* V12-174 · One template picker, contextual save and personal default. */
(function(){function init(){['contract','follow'].forEach(function(w){
 var panel=document.getElementById(w+'-template-library');if(!panel)return;
 var controls=panel.querySelector('.re-template-controls'),utility=panel.querySelector('.re-library-utilities'),form=document.getElementById(w+'-template-new'),picker=document.getElementById(w+'-template-select');
 if(!controls||!utility||!form||!picker)return;
 controls.appendChild(utility);
 var save=form.querySelector('[data-template-save]');if(save)save.textContent='Save Template';
 var set=document.createElement('button');set.type='button';set.className='mct-template-default';set.dataset.setDefault=w;set.textContent='★ Set as My Default';form.appendChild(set);
 var small=document.createElement('span');small.id=w+'-personal-default-note';small.className='mct-default-status';small.textContent='My Default: not set';utility.appendChild(small);
 var restore=utility.querySelector('[data-restore]');if(restore){restore.textContent='↻ Restore My Default';restore.title='Restore your own saved default template';}
 panel.classList.add('mct-template-v170','mct-template-v169');
 });}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();})();
