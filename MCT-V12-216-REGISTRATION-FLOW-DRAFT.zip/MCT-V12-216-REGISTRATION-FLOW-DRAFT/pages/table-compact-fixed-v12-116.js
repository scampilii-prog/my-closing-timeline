/* V12-133: Keep the existing paired table controls visible below the dashboard.
   Uses the table's visible bounds rather than the actions row, which may move
   during summary transitions. No task state or click handlers are changed. */
(() => {
  let scheduled = false;
  function update() {
    scheduled = false;
    const expanded = document.body.classList.contains('mct-table-fullview');
    const dock = document.getElementById('mct-persistent-dashboard');
    const header = document.getElementById('shared-header');
    const top = Math.max(header?.getBoundingClientRect().bottom || 0,
                         dock?.getBoundingClientRect().bottom || 0) + 10;
    for (const kind of ['contract', 'follow']) {
      const section = document.getElementById(kind + '-section');
      const heading = section?.querySelector('.mct-table-mode-heading');
      const table = section?.querySelector('.re-table-wrap');
      if (!section || !heading || !table) continue;
      const tableRect = table.getBoundingClientRect();
      const sectionRect = section.getBoundingClientRect();
      const shouldFix = !expanded && tableRect.top < top &&
        sectionRect.bottom > top + 75 && sectionRect.top < window.innerHeight;
      heading.classList.toggle('mct-compact-fullview-fixed', shouldFix);
      if (shouldFix) {
        heading.style.setProperty('--mct-fullview-top', top + 'px');
        heading.style.setProperty('--mct-fullview-right', Math.max(14, window.innerWidth - sectionRect.right + 12) + 'px');
      } else {
        heading.style.removeProperty('--mct-fullview-top');
        heading.style.removeProperty('--mct-fullview-right');
      }
    }
  }
  function schedule() { if (!scheduled) { scheduled = true; requestAnimationFrame(update); } }
  function start() {
    window.addEventListener('scroll', schedule, {passive:true});
    window.addEventListener('resize', schedule, {passive:true});
    document.addEventListener('click', schedule);
    document.addEventListener('change', schedule);
    const target = document.getElementById('mct-persistent-dashboard');
    if (target && typeof ResizeObserver !== 'undefined') new ResizeObserver(schedule).observe(target);
    schedule();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
