(()=>{'use strict';
const $=id=>document.getElementById(id);const table=$('email-table'),shortcut=$('email-preview-shortcut'),note=$('email-next-shortcut');if(!table||!shortcut)return;
const emailOk=s=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((s||'').trim());
const confirmed=k=>!!$(k+'-confirm')?.checked&&Array.from(document.querySelectorAll('#'+k+'-rows tr')).some(tr=>tr.querySelector('td:first-child input[type=checkbox]')?.checked);
const ready=()=>!!window.MCTCommunication?.ready();
function update(){const w=table.value;const target=ready();shortcut.disabled=!target;shortcut.classList.remove('re-next-action');shortcut.title=target?'Review the complete email and selected tasks before sending.':'Select confirmed tasks and complete recipient, role, subject, and message.';note.textContent=target?'NEXT · Preview Email — review your recipient, message, and selected tasks.':!w?'NEXT · Choose a table to send.':!$('email-role')?.value?'NEXT · Select Role / Relationship.':'Complete any missing recipient details, subject, or message to continue.';
// Communication Center wizard owns its top guidance text.
}
shortcut.addEventListener('click',()=>{if(!ready())return;$('email-preview').click();});
['email-table','email-to','email-role','role-other','email-subject','email-message','contact-list','contact-name','contact-email','contract-confirm','follow-confirm'].forEach(id=>{const el=$(id);el?.addEventListener('change',()=>setTimeout(update,0));el?.addEventListener('input',()=>setTimeout(update,0))});
document.addEventListener('mct-communication-entry',()=>setTimeout(update,100));setTimeout(update,300);
})();