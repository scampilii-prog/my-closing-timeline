# V12-144 · Reglas aisladas de Founding Members

Esta versión agrega `founding-members-policy.mjs` y `tests/founding_policy.test.mjs`. Son reglas de negocio puras y pruebas automatizadas, **no conectadas** a la API PRO ni a la base de datos de producción.

Comprueban: inicio de 90 días; vencimiento exacto; suspensión; extensiones de 30 días hasta 150; rechazo de rondas no aprobadas, duplicadas o inválidas.

**Bloqueo importante:** La validación en memoria NO reemplaza transacciones atómicas de D1. Antes de habilitar registros, implementar concesiones con garantías contra concurrencia y autenticación/autorización en servidor.

Las páginas aprobadas no se modificaron. No subir a Cloudflare ni ejecutar la migración.
