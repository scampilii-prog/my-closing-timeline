# V12-176 — Biblioteca de plantillas

- Eliminada la dependencia de Workspace para crear, guardar, cargar, renombrar y marcar My Default.
- Corregido el campo Template Name, que estaba bloqueado/oculto tras seleccionar Create a New Template.
- Conservadas las bibliotecas independientes de Table 01 y Table 02.
- No se modificaron estilos de resúmenes de email ni de tablas editoras.
- Pendiente: prueba visual y funcional real en Chrome con almacenamiento local.
