/* Source: user-supplied MCT-79 real-estate-admin-test.html; text retained. */
window.MCT_ASK_TIMELINE_V10 = [
  {
    "name": "Benefits and access",
    "questions": [
      {
        "key": "value",
        "question": "What would I gain from a project plan?",
        "answer": "A dedicated timeline gives you one place to review milestones, deadlines and follow-ups for a project. In Real Estate & Closing you can also preview a report with only the tasks you select. Consider a plan if that workflow would help you manage an active project."
      },
      {
        "key": "fit",
        "question": "Which timeline fits my needs?",
        "answer": "What are you organizing first: a real estate closing, a business project, a service job, or something at home? Choose a topic or type what you need. You can also tell me if you have more than one activity to organize."
      },
      {
        "key": "plans",
        "question": "How should I choose a plan?",
        "answer": "Use the listed 21-day trial to see whether the workflow suits one project, if eligible. The 60-day per-project option shown in this preview is meant for a project that needs a longer working window. Compare the access period with your expected finish date, then check included features, project limits and the price on the live site before choosing."
      },
      {
        "key": "trial",
        "question": "How does the free trial work?",
        "answer": "The planned free offer is one 21-day trial per eligible account. Actual registration and access must be confirmed on the live site."
      },
      {
        "key": "longer",
        "question": "What if my project needs more time?",
        "answer": "Estimate how long the project will take, including follow-ups after the main milestone. Compare that window with the access periods shown under Project Access Plans and confirm the current terms before choosing."
      },
      {
        "key": "multiple",
        "question": "Can I organize several projects?",
        "answer": "If your account and the applicable plans support additional projects, use a separate timeline for each activity. For example, pair Real Estate for a closing with Personal & Home for a renovation. Check category availability, project limits and whether each timeline needs separate access before buying."
      },
      {
        "key": "pair",
        "question": "Can I keep work and home projects separate?",
        "answer": "Consider one timeline for professional work and a separate Personal & Home timeline for a renovation or seasonal maintenance. Separate schedules help you see what is due in each. Check whether the available plans allow the additional project and what it costs."
      },
      {
        "key": "buy",
        "question": "How do I move forward with my choice?",
        "answer": "If you have found a timeline that fits, review its access period, features and total price. This downloaded preview cannot take a payment. Compare the access options here and confirm availability on the live site before buying. Consider Personal & Home afterward if you have a separate home project to manage."
      },
      {
        "key": "pay",
        "question": "Can I register or pay here?",
        "answer": "This downloaded preview cannot create accounts, process payments, or verify that the live payment system is active."
      }
    ]
  },
  {
    "name": "Timeline categories",
    "questions": [
      {
        "key": "real",
        "question": "How does Real Estate work?",
        "answer": "Real Estate helps organize contract deadlines, inspections, deposits, follow-ups, and communications. Contract dates always control. A separate Personal & Home timeline can keep a renovation or household maintenance apart from your closings."
      },
      {
        "key": "business",
        "question": "How does Business & Projects help?",
        "answer": "Consider Business & Projects for a launch, internal initiative or recurring work. Use a separate timeline for each project so its milestones, due dates and handoffs are easy to review. If you also manage a renovation or household maintenance, Personal & Home can keep that schedule separate."
      },
      {
        "key": "services",
        "question": "How does Services & Contractors help?",
        "answer": "Consider Services & Contractors to track work from estimate and site visit through installation and final walkthrough. Separate timelines help you see what is pending for each job. Personal & Home may also be useful if you want a separate schedule for your own home."
      },
      {
        "key": "home",
        "question": "How does Personal & Home help?",
        "answer": "Consider Personal & Home for a renovation, seasonal maintenance or recurring household tasks. Keep it separate from your professional work so you can see what is due at home without mixing it with a closing, business project or client job."
      }
    ]
  },
  {
    "name": "Using Ask Timeline",
    "questions": [
      {
        "key": "here",
        "question": "What can I do here?",
        "answer": "Choose from Real Estate, Business & Projects, Services & Contractors, or Personal & Home. Some categories are design previews only."
      },
      {
        "key": "pdf",
        "question": "How do I save a PDF?",
        "answer": "Select the tasks to include, choose View Formatted Table, then Print / Save as PDF. Name the file with your project code. Keep private notes in the copy saved on your device."
      },
      {
        "key": "live",
        "question": "Is this a live assistant?",
        "answer": "Not yet. Ask Timeline currently provides prepared guidance. A conversational AI assistant is planned."
      }
    ]
  }
];
