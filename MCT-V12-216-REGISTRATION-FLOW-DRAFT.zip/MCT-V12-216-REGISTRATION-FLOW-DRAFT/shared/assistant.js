(()=>{'use strict';
const groups=window.MCT_ASK_TIMELINE_V10, panel=document.getElementById('help'),launch=document.getElementById('ask');
if(!groups||!panel||!launch)return;
panel.replaceChildren();panel.classList.add('lia-panel');panel.setAttribute('aria-label','Ask Timeline');
const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt)n.textContent=txt;return n};
const head=el('div','lia-head'),title=el('h3'),ico=el('img');
ico.src='assets/calendar-icon-reference.png';ico.alt='';const titleText=el('span','lia-title-stack');titleText.append(el('span','lia-title-main','Ask Timeline'),el('span','lia-title-sub','Your timeline guide'));title.append(ico,titleText);
const close=el('button','', '×');close.type='button';close.setAttribute('aria-label','Close Ask Timeline');head.append(title,close);
const body=el('div','lia-scroll-body');body.tabIndex=0;body.setAttribute('role','region');body.setAttribute('aria-label','Ask Timeline content, scroll for more');
const intro=el('p','', 'Welcome! Select a question or type your own.');
const heading=el('h4','', 'Explore benefits and plans');
const picker=el('details','lia-picker'),summary=el('summary','', 'Explore common questions…'),list=el('div','lia-question-list');
list.tabIndex=0;list.setAttribute('role','region');list.setAttribute('aria-label','Available questions');
const answer=el('div','lia-result');answer.setAttribute('role','status');answer.setAttribute('aria-live','polite');answer.hidden=true;
function show(q){answer.replaceChildren();answer.hidden=false;answer.append(el('strong','',q.question),el('p','',q.answer));answer.scrollIntoView({block:'nearest',behavior:'smooth'})}
for(const g of groups){list.append(el('strong','lia-group-title',g.name));for(const q of g.questions){const b=el('button','lia-question',q.question);b.type='button';b.addEventListener('click',()=>{summary.textContent=q.question;picker.open=false;show(q)});list.append(b)}}
picker.append(summary,list);
const prompt=el('h4','', 'Or write your question'),field=el('textarea');field.rows=3;field.maxLength=500;field.placeholder='Type your question here…';field.setAttribute('aria-label','Type your question');
const ask=el('button','lia-submit','Ask');ask.type='button';
const note=el('p','lia-note','Guidance only. This preview provides prepared answers, not live AI chat. Verify dates and plan terms before relying on them.');
const controls=el('div','lia-compose');controls.append(field,ask);
body.append(intro,heading,picker,answer,prompt,controls,note);panel.append(head,body);
const all=groups.flatMap(g=>g.questions);
const rules=[[/pdf|print|imprimir/i,'pdf'],[/\b(buy|purchase|checkout|comprar)\b/i,'buy'],[/benefit|worth|beneficio/i,'value'],[/more time|longer|mas tiempo|más tiempo/i,'longer'],[/multiple|several|varios|separat|additional/i,'multiple'],[/free|trial|gratis|gratuito|21.day|21 días/i,'trial'],[/register|sign in|login|cuenta|registr/i,'pay'],[/price|cost|plan|precio|pago/i,'plans'],[/personal|home|hogar|casa|renovat/i,'home'],[/contractor|services|servicios|estimate|presupuesto/i,'services'],[/business|negocio|milestone|hito/i,'business'],[/real estate|closing|contract|cierre|contrato|deadline|fecha/i,'real'],[/project|proyecto|recommend|recomien|empezar|start/i,'fit']];
function query(){const v=field.value.trim();if(!v){field.focus();return}const match=rules.find(([regex])=>regex.test(v));const q=match?all.find(q=>q.key===match[1]):null;
if(q)show(q);else{answer.hidden=false;answer.replaceChildren(el('p','','I can help with timeline categories, access, tasks and PDF reports. Please choose one of the prepared questions.'))}}
ask.addEventListener('click',query);field.addEventListener('keydown',e=>{if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();query()}});
function toggle(open){panel.hidden=!open;launch.setAttribute('aria-expanded',String(open));if(open)summary.focus();else picker.open=false}
close.addEventListener('click',()=>toggle(false));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden){toggle(false);launch.focus()}});
document.addEventListener('pointerdown',e=>{if(!panel.hidden&&!panel.contains(e.target)&&!launch.contains(e.target))toggle(false)});
})();