-- Founding Members: additive schema only. NOT applied to production.
-- Existing users are unchanged. Dates are UTC Unix timestamps.
CREATE TABLE IF NOT EXISTS founding_members (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 started_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 extension_count INTEGER NOT NULL DEFAULT 0 CHECK(extension_count BETWEEN 0 AND 2),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','suspended')),
 created_at TEXT NOT NULL DEFAULT (datetime('now')),
 CHECK(expires_at >= started_at + 90 * 86400)
);
CREATE TABLE IF NOT EXISTS founding_test_rounds (
 user_id TEXT NOT NULL REFERENCES founding_members(user_id) ON DELETE CASCADE,
 round_number INTEGER NOT NULL CHECK(round_number IN (1,2)),
 completed_at INTEGER NOT NULL,
 approved_at INTEGER,
 PRIMARY KEY(user_id,round_number)
);
CREATE TABLE IF NOT EXISTS founding_extension_events (
 user_id TEXT NOT NULL REFERENCES founding_members(user_id) ON DELETE CASCADE,
 round_number INTEGER NOT NULL CHECK(round_number IN (1,2)),
 granted_at INTEGER NOT NULL,
 days_granted INTEGER NOT NULL DEFAULT 30 CHECK(days_granted=30),
 PRIMARY KEY(user_id,round_number)
);
CREATE INDEX IF NOT EXISTS idx_founding_expiry ON founding_members(expires_at);
