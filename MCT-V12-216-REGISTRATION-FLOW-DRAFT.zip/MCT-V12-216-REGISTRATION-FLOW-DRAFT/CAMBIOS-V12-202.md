# V12-202 · Pruebas corregidas

- Se corrigieron cinco scripts de prueba para separar los parámetros de caché (`?v=197`) de las rutas físicas a CSS y JavaScript.
- No se modificó el HTML, CSS ni JavaScript del producto.
- Se conservó `studio.html` y toda la navegación de V12-201.
- Esta versión no certifica pagos, autenticación ni envío de correos en producción.
