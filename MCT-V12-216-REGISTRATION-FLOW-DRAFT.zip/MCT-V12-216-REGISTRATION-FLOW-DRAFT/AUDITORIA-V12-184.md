# V12-184 — Secuencia visual de Communication Center

- Al entrar desde Send Email, **Table to send** se ilumina primero, incluso si la tabla ya estaba preseleccionada por el botón de origen. No se pierde la elección previa.
- Cuando el operador abre o cambia Table to send, la guía avanza a **Saved contact**.
- El siguiente paso sigue siendo Recipient email, Role / Relationship, Subject, Message y Preview Email según la validación existente.
- No se modifican colores de tablas ni resúmenes.
- Revisión: sintaxis de JavaScript y prueba de integridad del ZIP; la comprobación visual en Chrome queda pendiente.
