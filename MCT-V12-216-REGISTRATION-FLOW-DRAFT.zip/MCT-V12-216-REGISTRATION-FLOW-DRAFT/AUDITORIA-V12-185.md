# V12-185 — Orden real de la guía de email

- Al entrar en el paso 4 por Next, Back o la barra lateral, se emite `mct-communication-entry`.
- La guía vuelve a empezar en **Table to send**, incluso cuando existe una tabla preseleccionada.
- El foco o apertura del selector ya no adelanta la guía a **Saved contact**.
- Al cambiar efectivamente la selección de tabla, la guía avanza a **Saved contact**.
- No se modificaron los estilos ni los resúmenes.
- Comprobaciones: sintaxis JavaScript e integridad del ZIP; prueba visual en Chrome pendiente.
