# V12-141 · Founding Members en el menú

- Añadido enlace a `founding-members.html` en el menú compartido de `shared/shell.js`, antes de Plans.
- La página integrada mantiene el header, footer y controles compartidos.
- El antiguo `MCT-FOUNDING-MEMBERS-PILOTO-02/index.html` es un demo separado y no se usa.
- Registro, extensiones y pruebas privadas aún no están implementados; el programa se presenta como vista previa.
- No se modifican las páginas de tareas ni el sitio publicado.
