# V12-210 · Regreso de Payment a Plans

- Payment conserva la opción válida en el enlace Back to Plans & Pricing.
- Plans restaura los selectores desde parámetros válidos; parámetros inválidos no alteran valores predeterminados.
- Checkout y registro continúan desactivados.
