# V12-209 · Claridad de privacidad en la vista previa

Se amplió privacy.html para advertir que los datos de prueba pueden persistir en el almacenamiento del navegador, que no debe usarse información real de terceros y que aún falta aprobar la política definitiva antes del registro. No se activaron servicios ni pagos.
