# V12-168 · Biblioteca compacta de plantillas

- Los controles de plantilla y restauración se agrupan dentro de Choose Your Table para las tablas 01 y 02.
- Save Current as Template permite nombrar y guardar las tareas actuales sin reiniciarlas.
- Las plantillas guardadas aparecen en el selector existente y son independientes para cada tabla.
- Restore Default 6 Tasks sigue usando la confirmación existente.
- Se preservan editores, colores de estado y resúmenes de email de V12-167.
- Las plantillas existentes se guardan en almacenamiento local del navegador, no se sincronizan entre dispositivos.
- Pruebas estáticas y sintaxis, no prueba interactiva en Chrome.
