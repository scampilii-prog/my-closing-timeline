# V12-206 · Protección de la interfaz administrativa

- Eliminada la copia estática `admin-founding-members.html`, que podía servirse públicamente sin autenticación (aunque su API sí estuviera protegida).
- `studio.html` enlaza ahora a `/admin-founding-members`, una ruta dinámica que exige sesión de propietario y bandera de habilitación. El enlace **no funcionará desde un ZIP local**; solo en Cloudflare con el Worker instalado y configurado.
- Añadida prueba de regresión `tests/v12_admin_private_route_test.py`.
- No se han habilitado registro, pagos ni permisos administrativos. No se ha desplegado nada.
- Pendiente antes de producción: verificar rutas, sesión y acceso denegado en Cloudflare; confirmar la duración comercial de la prueba (90 frente a 21 días).
