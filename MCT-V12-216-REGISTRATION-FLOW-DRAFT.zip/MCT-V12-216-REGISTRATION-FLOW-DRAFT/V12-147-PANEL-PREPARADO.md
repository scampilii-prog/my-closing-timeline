# Preparación del panel privado Founding Members

Se añadió `admin-founding-members.html` en la carpeta local de trabajo, sin publicar ni generar otro ZIP. Panel de solo lectura: cinco métricas agregadas y botón de actualización. Consulta `/api/founding/admin-summary`, endpoint previamente preparado y desactivado por defecto.

**BLOQUEO DE PUBLICACIÓN:** La ruta `/admin-founding-members.html` todavía NO está incorporada a `protectedRoute` de `functions/_middleware.js` en el repositorio de producción. Aunque el endpoint valida la sesión de propietario, **no se debe publicar esta página** antes de proteger la ruta, probar sesión vencida y acceso anónimo, y validar la base D1 de pruebas. Tampoco se deben activar flags en producción.

No se almacenan datos en el navegador. No se muestran emails ni información de proyectos. Sin modificaciones a las páginas aprobadas.
