// ISOLATED DRAFT: not connected to a public route or Cloudflare D1.
import { normalizeEmail, createOpaqueToken, sha256Hex } from './security.mjs';
const DAY_MS=86400000;
export async function prepareRegistration({fullName,email,now=Date.now()}) {
  if (typeof fullName !== 'string' || !fullName.trim() || fullName.trim().length>120) throw new TypeError('Invalid name');
  if (!Number.isSafeInteger(now) || now<0) throw new TypeError('Invalid time');
  const token=createOpaqueToken();
  return {fullName:fullName.trim(),emailNormalized:normalizeEmail(email),token,tokenHash:await sha256Hex(token),expiresAt:now+30*60*1000,status:'pending'};
}
// The adapter MUST implement atomic transaction semantics on the server.
// Never return a raw token to logs or persistence; only email it via a trusted provider.
export async function verifyAndActivate({token,now=Date.now(),store}) {
  if (!/^[a-f0-9]{64}$/.test(token)) return {ok:false,reason:'invalid'};
  if (!Number.isSafeInteger(now)||now<0) throw new TypeError('Invalid time');
  if (!store || typeof store.consumeAndActivateAtomically!=='function') throw new TypeError('Transactional adapter required');
  const hash=await sha256Hex(token);
  const result=await store.consumeAndActivateAtomically({tokenHash:hash,now,trialDurationMs:90*DAY_MS});
  if (!result || !['activated','invalid','expired','used','inactive','already-trial'].includes(result)) throw new Error('Invalid adapter result');
  return {ok:result==='activated',reason:result};
}
