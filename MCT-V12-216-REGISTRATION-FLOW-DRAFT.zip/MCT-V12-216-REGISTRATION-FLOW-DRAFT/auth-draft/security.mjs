// OFFLINE FOUNDATION ONLY. Not imported by any live route.
const enc = new TextEncoder();
export function normalizeEmail(value) {
  if (typeof value !== 'string') throw new TypeError('Email required');
  const email=value.trim().toLowerCase();
  if (email.length>254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new TypeError('Invalid email');
  return email;
}
export async function sha256Hex(value) {
  const bytes=await crypto.subtle.digest('SHA-256',enc.encode(value));
  return [...new Uint8Array(bytes)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export function createOpaqueToken() {
  const bytes=new Uint8Array(32);crypto.getRandomValues(bytes);
  return [...bytes].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export function sessionCookie(token,{maxAge=7200}={}) {
  if (!/^[0-9a-f]{64}$/.test(token)) throw new TypeError('Invalid session token');
  if (!Number.isInteger(maxAge)||maxAge<1||maxAge>86400) throw new TypeError('Invalid age');
  return `__Host-mct_session=${token}; Path=/; Max-Age=${maxAge}; Secure; HttpOnly; SameSite=Lax`;
}
export function clearSessionCookie() {
  return '__Host-mct_session=; Path=/; Max-Age=0; Secure; HttpOnly; SameSite=Lax';
}
export function isFresh(expiry,now) {
  return Number.isFinite(expiry)&&Number.isFinite(now)&&expiry>now;
}
