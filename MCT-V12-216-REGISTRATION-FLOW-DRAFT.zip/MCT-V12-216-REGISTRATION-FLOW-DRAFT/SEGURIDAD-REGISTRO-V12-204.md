# V12-204 — Plan técnico de registro seguro (no desplegado)

## Arquitectura elegida
GitHub: repositorio, revisiones y pruebas. Cloudflare Workers: API de autenticación, validación y autorización. Cloudflare D1: estado de cuentas y derechos. Turnstile: desafío con validación obligatoria en servidor. Proveedor de correo transaccional por configurar. Stripe Checkout futuro, exclusivamente después de confirmar precios.

## Flujo
1. Nombre completo, email y teléfono opcional; aviso de privacidad y aceptación de términos.
2. Turnstile validado en Worker con Siteverify; respuesta genérica para impedir enumeración de emails.
3. Email de verificación con token aleatorio de un solo uso, hash en base de datos y vencimiento breve.
4. Al verificar, activación atómica de UNA prueba de 90 días por cuenta, sujeta a las condiciones comerciales finales. La fecha se calcula en servidor; no en el navegador.
5. Elegir actividades sin abrir cuentas nuevas. Los planes y promociones se registran como derechos separados.
6. Cuando existan señales de abuso, verificación adicional o revisión humana; no bloqueo automático por IP.

## Reglas no negociables
- No almacenar contraseñas en texto plano; preferir proveedor de identidad o sesiones seguras con cookies HttpOnly, Secure y SameSite.
- No almacenar IP permanente por defecto; limitar retención y documentar en política de privacidad.
- No usar huellas digitales invasivas como identificador único ni afirmar detección infalible de personas duplicadas.
- No activar pruebas o planes desde parámetros URL, localStorage o controles del navegador.
- No confiar en Turnstile solo en frontend. La clave secreta vive únicamente en Cloudflare Secrets.
- Nunca publicar una ruta administrativa sin autorización verificada en servidor.
- No aceptar datos personales de terceros en los proyectos ni en feedback público.
- Evitar la reactivación de la prueba tras eliminar/recrear una cuenta, sujeto a una política de retención proporcionada y legal.
- Cobros y promociones requieren confirmación del catálogo, pruebas y webhook firmado.

## Preparación para producción
[ ] Confirmar duración final de la prueba (la versión local anuncia 90 días; versiones anteriores documentaron 21 días).
[ ] Elegir proveedor de autenticación y correo; configurar DNS y secretos en Cloudflare.
[ ] Crear base D1 y migración con índices únicos; verificar transacciones y concurrencia.
[ ] Implementar API de registro, verificación, sesión, derechos y cierre de sesión.
[ ] Configurar Turnstile en dominio real y validar tokens del lado del servidor.
[ ] Pruebas de duplicados, concurrencia, expiración, abuso, recuperación y accesibilidad.
[ ] Desplegar en entorno de pruebas; nunca activar cobros desde el ZIP local.

Este documento es una especificación verificable, NO una implementación funcional ni una publicación.
