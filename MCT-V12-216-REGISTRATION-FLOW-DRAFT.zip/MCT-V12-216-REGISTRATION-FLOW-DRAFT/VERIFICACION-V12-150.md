V12-150 · Aviso del Workspace debajo de Effective Date / Closing Date, alineado a la derecha. Estado verde después de guardar. Se conserva la navegación y el resto del sitio.
