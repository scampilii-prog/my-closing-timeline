// Pure policy helpers; not connected to the public site or production D1.
export const DAY = 86400;
export const TRIAL_DAYS = 90;
export const EXTENSION_DAYS = 30;
export const MAX_EXTENSIONS = 2;

export function initialTrial(startedAt) {
  if (!Number.isSafeInteger(startedAt) || startedAt < 0) throw new Error('Invalid start timestamp');
  return { started_at: startedAt, expires_at: startedAt + TRIAL_DAYS * DAY, extension_count: 0, status: 'active' };
}

export function evaluateAccess(membership, now) {
  if (!membership || membership.status !== 'active' || !Number.isSafeInteger(now)) return { canEdit: false, reason: 'inactive' };
  if (now >= membership.expires_at) return { canEdit: false, reason: 'expired' };
  return { canEdit: true, reason: 'active' };
}

export function nextExtension(membership, roundNumber, approvedRounds, grantedRounds) {
  if (!membership || membership.status !== 'active') throw new Error('Inactive membership');
  if (![1, 2].includes(roundNumber)) throw new Error('Invalid round');
  if (!Array.isArray(approvedRounds) || !approvedRounds.includes(roundNumber)) throw new Error('Round not approved');
  if (!Array.isArray(grantedRounds) || grantedRounds.includes(roundNumber)) throw new Error('Already granted');
  if (membership.extension_count >= MAX_EXTENSIONS) throw new Error('Extension limit reached');
  return { expires_at: membership.expires_at + EXTENSION_DAYS * DAY, extension_count: membership.extension_count + 1 };
}
