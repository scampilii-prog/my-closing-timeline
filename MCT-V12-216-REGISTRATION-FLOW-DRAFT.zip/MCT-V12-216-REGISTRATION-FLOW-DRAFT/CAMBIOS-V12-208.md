# V12-208 · Navegación de cuentas en vista previa

Se detectaron enlaces Sign In y Register hacia páginas antiguas del sitio publicado. Se sustituyeron por una página informativa local (`account-preview.html`) sin formularios ni almacenamiento de datos. No se activa registro ni inicio de sesión. Se añadió prueba de regresión. Cloudflare queda pendiente de integración final.
