// PRIVATE owner-only summary, read-only, disabled by default.
// The HMAC validation mirrors functions/_middleware.js in the GitHub repository.
const headers={'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Robots-Tag':'noindex, nofollow'};
const respond=(data,status=200)=>Response.json(data,{status,headers});
const enc=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
const mac=async(secret,value)=>{const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return b64(new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(value))))};
const equal=(a,b)=>{if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let d=0;for(let i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0};
export async function onRequestGet({request,env}){
 if(env.FOUNDING_MEMBERS_ADMIN_ENABLED!=='true')return respond({ok:false,error:'Not available'},404);
 const secret=env.PERSONAL_PRACTICE_PASSWORD;
 if(typeof secret!=='string'||secret.length<12||!env.PRO_DB)return respond({ok:false,error:'Unavailable'},503);
 const cookie=(request.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('mct_owner_session_v2='));
 const match=/^v2\.(\d+)\.([A-Za-z0-9_-]+)$/.exec(cookie?.slice('mct_owner_session_v2='.length)||'');
 const now=Date.now(),lifetime=30*86400*1000;
 if(!match)return respond({ok:false,error:'Owner sign-in required'},401);
 const expiry=Number(match[1]);
 if(!Number.isSafeInteger(expiry)||expiry<=now||expiry>now+lifetime+60000||!equal(match[2],await mac(secret,'v2.'+match[1])))return respond({ok:false,error:'Owner sign-in required'},401);
 try{
  const row=await env.PRO_DB.prepare(`SELECT COUNT(*) AS total,
   SUM(CASE WHEN status='active' AND expires_at>? THEN 1 ELSE 0 END) AS active,
   SUM(CASE WHEN status='active' AND expires_at<=? THEN 1 ELSE 0 END) AS expired,
   SUM(CASE WHEN status='suspended' THEN 1 ELSE 0 END) AS suspended,
   SUM(CASE WHEN extension_count>=1 THEN 1 ELSE 0 END) AS extended,
   SUM(CASE WHEN extension_count=2 THEN 1 ELSE 0 END) AS fully_extended
   FROM founding_members`).bind(Math.floor(now/1000),Math.floor(now/1000)).first();
  return respond({ok:true,summary:{total:row?.total||0,active:row?.active||0,expired:row?.expired||0,suspended:row?.suspended||0,extended:row?.extended||0,fully_extended:row?.fully_extended||0}});
 }catch(_){return respond({ok:false,error:'Unavailable'},503)}
}
