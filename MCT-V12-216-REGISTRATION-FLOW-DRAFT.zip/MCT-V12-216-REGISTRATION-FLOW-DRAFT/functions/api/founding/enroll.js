// Voluntary opt-in for existing verified PRO accounts. OFF by default.
// This is NOT public signup. Cloudflare D1 migration 0009 required in test environment.
const headers={"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer"};
const reply=(data,status=200)=>Response.json(data,{status,headers});
const hash=async token=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(token)))).map(b=>b.toString(16).padStart(2,'0')).join('');
export async function onRequestPost({request,env}){
 if(env.FOUNDING_MEMBERS_ENROLL_ENABLED!=='true')return reply({ok:false,error:'Not available'},404);
 if(!env.PRO_DB)return reply({ok:false,error:'Service unavailable'},503);
 const origin=request.headers.get('Origin');
 if(!origin||origin!==new URL(request.url).origin)return reply({ok:false,error:'Origin not allowed'},403);
 if(!(request.headers.get('Content-Type')||'').toLowerCase().startsWith('application/json'))return reply({ok:false,error:'JSON required'},415);
 let body;try{body=await request.json()}catch{return reply({ok:false,error:'Invalid request'},400)}
 if(body?.joinFoundingMembers!==true||body?.termsAccepted!==true)return reply({ok:false,error:'Explicit consent required'},400);
 const token=(request.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('mct_pro_session='))?.slice(16);
 if(!token||!/^[A-Za-z0-9_-]{32,128}$/.test(token))return reply({ok:false,error:'Sign in required'},401);
 try{
  const db=env.PRO_DB,now=Math.floor(Date.now()/1000);
  const session=await db.prepare('SELECT s.user_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.verified=1').bind(await hash(token),now).first();
  if(!session)return reply({ok:false,error:'Sign in required'},401);
  // INSERT OR IGNORE is atomic for the primary key: repeated requests never restart the trial.
  await db.prepare("INSERT OR IGNORE INTO founding_members(user_id,started_at,expires_at,extension_count,status) VALUES(?,?,?,0,'active')").bind(session.user_id,now,now+90*86400).run();
  const member=await db.prepare('SELECT started_at,expires_at,extension_count,status FROM founding_members WHERE user_id=?').bind(session.user_id).first();
  if(!member)return reply({ok:false,error:'Service unavailable'},503);
  return reply({ok:true,enrolled:true,started_at:member.started_at,expires_at:member.expires_at,extension_count:member.extension_count,status:member.status});
 }catch(_){return reply({ok:false,error:'Service unavailable'},503)}
}
