// Read-only Founding Members status endpoint. Feature flag is OFF by default.
// No user names, email, project data or credentials are returned.
const noStore = {"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer"};
const reply=(data,status=200)=>Response.json(data,{status,headers:noStore});
const enc=new TextEncoder();
const hash=async s=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(s)))).map(b=>b.toString(16).padStart(2,'0')).join('');
export async function onRequestGet({request,env}) {
  if(env.FOUNDING_MEMBERS_STATUS_ENABLED!=='true') return reply({ok:false,error:'Not available'},404);
  if(!env.PRO_DB) return reply({ok:false,error:'Service unavailable'},503);
  const raw=(request.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('mct_pro_session='));
  if(!raw)return reply({ok:false,error:'Sign in required'},401);
  const token=raw.slice('mct_pro_session='.length);
  if(!/^[A-Za-z0-9_-]{32,128}$/.test(token))return reply({ok:false,error:'Sign in required'},401);
  try {
    const session=await env.PRO_DB.prepare('SELECT s.user_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.verified=1').bind(await hash(token),Math.floor(Date.now()/1000)).first();
    if(!session)return reply({ok:false,error:'Sign in required'},401);
    const member=await env.PRO_DB.prepare('SELECT started_at,expires_at,extension_count,status FROM founding_members WHERE user_id=?').bind(session.user_id).first();
    if(!member)return reply({ok:true,enrolled:false});
    const now=Math.floor(Date.now()/1000);
    return reply({ok:true,enrolled:true,started_at:member.started_at,expires_at:member.expires_at,extension_count:member.extension_count,days_remaining:member.status==='active'?Math.max(0,Math.ceil((member.expires_at-now)/86400)):0,can_edit:member.status==='active'&&now<member.expires_at});
  }catch(_){return reply({ok:false,error:'Service unavailable'},503)}
}
