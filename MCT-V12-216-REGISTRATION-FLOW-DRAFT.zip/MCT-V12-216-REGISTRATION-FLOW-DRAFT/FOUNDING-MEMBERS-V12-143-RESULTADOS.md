# V12-143 · Founding Members — migración de prueba

**No ejecutar todavía en Cloudflare.** Se añade una migración SQL aditiva para futuras cuentas Founding Members, rondas y concesiones. No se modifica el backend público ni se habilita el registro. El esquema solo es una base; la lógica de autorización, concesión idempotente de extensiones y control de proyectos sigue pendiente.

## Verificación local
Se probó con SQLite en memoria, creando una tabla `users` ficticia. La migración se ejecutó dos veces, se insertó una membresía ficticia y se verificó que la restricción impide más de dos extensiones. No se consultaron ni copiaron cuentas reales.

## Reglas pendientes antes de producción
- Aplicar una extensión de 30 días únicamente tras aprobar una ronda, en una transacción atómica; impedir concesiones duplicadas.
- Autorizar cada acceso en servidor y verificar fechas de expiración.
- Integrar límites de proyectos y recuperación de acceso.
- Ejecutar pruebas de regresión completas del sitio y del backend en entorno separado.

**La Home, Founding Members y Real Estate Guided se conservan sin cambios.**
