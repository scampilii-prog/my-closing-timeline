-- Diseño propuesto para Cloudflare D1. No ejecutar sin revisión del backend.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS accounts (
 id TEXT PRIMARY KEY,
 full_name TEXT NOT NULL,
 email_normalized TEXT NOT NULL UNIQUE,
 phone_e164 TEXT,
 email_verified_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','suspended','closed'))
);
CREATE TABLE IF NOT EXISTS verification_tokens (
 token_hash TEXT PRIMARY KEY,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 expires_at TEXT NOT NULL,
 consumed_at TEXT
);
CREATE TABLE IF NOT EXISTS entitlements (
 id TEXT PRIMARY KEY,
 account_id TEXT NOT NULL REFERENCES accounts(id),
 kind TEXT NOT NULL CHECK(kind IN ('intro_trial','paid','promotion')),
 starts_at TEXT NOT NULL,
 ends_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS one_intro_trial_per_account ON entitlements(account_id) WHERE kind='intro_trial';
CREATE TABLE IF NOT EXISTS activity_preferences (
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 category TEXT NOT NULL CHECK(category IN ('real-estate','business','services','personal')),
 PRIMARY KEY(account_id,category)
);
-- IMPORTANTE: el índice único por cuenta NO detecta una persona con emails distintos.
-- Resolver abuso con controles proporcionados y revisión, no con IP como identidad.
