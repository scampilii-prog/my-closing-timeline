# V12-191 · Acceso gratuito y Founding Members

Base: V12-190. Cambios agrupados únicamente en Home y founding-members.html.

- Home: nuevo mensaje de acceso gratuito propuesto y vínculo a Founding Members.
- Founding Members: tres tarjetas diferenciadas (90 días para todos, colaboración voluntaria, continuación opcional).
- Eliminada la promesa de extensiones de hasta 60 días.
- Enlaces reales a Real Estate & Closing y Plans & Pricing.
- Se conserva el aviso de privacidad y se aclara que el alta de 90 días aún no está activa en esta versión local.
- No se ha activado ninguna inscripción, pago ni servicio de feedback.
- No se modificaron los componentes compartidos ni las fotografías.
