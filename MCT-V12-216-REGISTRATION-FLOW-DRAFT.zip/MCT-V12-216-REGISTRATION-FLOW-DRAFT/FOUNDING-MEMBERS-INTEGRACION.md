# Founding Members · integración visual V12-136

Esta versión añade `founding-members.html` al sitio completo V12-135 y reutiliza exactamente el header y footer de `shared/shell.js`, el layout compartido y los controles flotantes. No altera el flujo guiado, el registro ni los pagos.

## Qué es
Página informativa pública del programa, no simulador ni formulario operativo.

## Pendiente para lanzamiento
- Registro real, verificación y control de una prueba por cuenta.
- Dos proyectos con permisos y aislamiento en servidor.
- Extensiones +30/+30 sujetas a pruebas privadas objetivas y verificación en servidor.
- Canal privado de feedback con moderación y prevención de datos identificables.
- Revisión legal de privacidad, términos y reseñas.
- Pruebas E2E de seguridad, cuentas, navegación y pagos.

## Privacidad
No se recogen datos en la página. No exigir reseñas públicas. No incluir datos reales de clientes ni compañías.

## Cómo abrir
Descomprimir el ZIP y abrir `founding-members.html`. Los recursos compartidos deben permanecer en sus carpetas.
