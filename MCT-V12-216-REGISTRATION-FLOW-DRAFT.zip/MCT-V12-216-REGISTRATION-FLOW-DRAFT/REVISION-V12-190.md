V12-190: FAQ pregunta 15px, respuesta 14px, interlineado 1.6. Sin cambios funcionales.
