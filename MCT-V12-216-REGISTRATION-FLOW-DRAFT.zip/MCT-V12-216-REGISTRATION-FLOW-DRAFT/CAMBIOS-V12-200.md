# V12-200 · Navegación y Studio

- Home: retirado el acceso destacado a Owner Control Center; el footer conserva el enlace discreto Studio.
- Studio: eliminada la tarjeta duplicada Guided Closing; Real Estate & Closing sigue apuntando al flujo aprobado `real-estate-guided.html`.
- Studio: textos aclarados para distinguir páginas de vista previa de administración real.
- Conservados diseño compartido, enlaces del footer y lógica existente.
- **Seguridad pendiente:** Studio y el panel de Founding Members NO tienen protección garantizada por este ZIP local. Antes de publicar, aplicar autenticación y autorización del lado del servidor y restringir rutas administrativas; esconder un enlace no protege una ruta.
- No se han probado transacciones reales, email ni permisos de producción.
