# V12-199

- Eliminado el botón redundante Back to Home de Help & Contact.
- Conservados header, footer y controles compartidos.
- Sin modificaciones a las otras páginas ni a la lógica de proyectos.
