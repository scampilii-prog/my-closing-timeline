# V12-139 · Home + Real Estate Guided

- Home conserva las cuatro categorías y el enlace a `real-estate-guided.html`.
- Menú compartido: Real Estate & Closings ahora dirige también a `real-estate-guided.html` (cinco pasos).
- `real-estate.html` antiguo se conserva como referencia; no se ha modificado ni borrado.
- Se conservan los componentes y el resto de páginas de V12-138.
- No se ha publicado en GitHub ni Cloudflare.
- No se certifican pruebas completas de flujos de cuenta, email ni backend.
