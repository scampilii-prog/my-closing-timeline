# V12-196 · Footer unificado

Los cuatro enlaces del footer comparten color dorado sin subrayado y hover blanco. Se mantiene foco visible de teclado. No se modifican rutas ni funciones.
