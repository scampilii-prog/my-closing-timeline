# V12-146 — Alta privada voluntaria (desactivada)

Se agregó `functions/api/founding/enroll.js`, un endpoint POST **solo para cuentas PRO existentes, autenticadas y con email verificado**. Requiere consentimiento explícito, mismo origen, JSON y `FOUNDING_MEMBERS_ENROLL_ENABLED=true`. Sin indicador devuelve 404. La inserción `INSERT OR IGNORE` evita reiniciar la prueba por solicitudes repetidas. La prueba comienza con 90 días UTC. **No modifica ni crea usuarios, ni activa extensiones ni acceso a proyectos.**

No está conectado a botones públicos. No habilitar en producción: antes revisar elegibilidad, límites, aprobación del programa, pruebas integradas con D1 y protección frente a abusos. Los datos de cuentas actuales permanecen intactos en esta copia local.
