V12-163 — Conflicto identificado y aislado.
Causa: pages/table-palette-v12-158.css aplicaba color chocolate/crema y amarillo al marcar tareas en AMBOS editores principales, además de afectar los resúmenes.
Corrección: retirar la referencia a esa hoja de estilos en real-estate-guided.html, restaurando los editores a sus estilos anteriores.
Retirada también la hoja duplicada summary-palette-v12-160.css para evitar competencia.
ÚNICO archivo de colores para resultados: pages/summary-only-v12-162.css, restringido a #contract-summary y #follow-summary.
No se modificó JS, datos, botones, fechas ni navegación.
