# V12-207 · Claridad de prueba gratuita en Home

- Home distingue 90 días para todo usuario nuevo de Founding Members opcional.
- Se conserva aviso de que el registro no está activo.
- Se mantiene el enlace a Founding Members como información, no como requisito para la prueba.
- No se modifica backend, precios, registro ni producción.
- Prueba nueva: tests/v12_home_trial_clarity_test.py.
