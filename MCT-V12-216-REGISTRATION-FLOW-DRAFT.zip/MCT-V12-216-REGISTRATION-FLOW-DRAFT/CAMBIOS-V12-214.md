# V12-214 · Contrato local de sesiones y límites de intentos

Se añadió `tests/v12_session_rate_limit_contract_test.py`, prueba SQLite de referencia para sesiones con tokens aleatorios almacenados como hash, vencimiento, revocación, bloqueo por suspensión y borrado en cascada. Incluye una prueba de límite de intentos por ámbito y sujeto, con ventana temporal.

**No es una implementación de producción.** La limitación de intentos de esta prueba no es segura frente a concurrencia distribuida; no se añadieron endpoints, cookies reales ni servicios de email. Para producción faltan transacciones atómicas, controles por IP solo como señal auxiliar (nunca identidad), protección CSRF, cookies HttpOnly/Secure/SameSite, rotación de sesión, limpieza de registros, D1/Workers y auditoría. No se ha modificado la interfaz ni desplegado el sitio.
