V12-164: Se identificaron reglas previas con mayor especificidad, especialmente
pages/table-results-icons-v12-113.css, que imponían el celeste en TASK / MILESTONE.
La hoja nueva usa los ID de sección y de resumen combinados para vencerlas,
sin alterar las tablas principales ni sus alertas Today/Tomorrow.
Closing Timeline Summary: encabezado chocolate uniforme, filas enteras dorado/crema.
Follow-Up Summary: encabezado ciruela uniforme, filas enteras rosa/rosa pálido.
Pruebas: integridad ZIP, referencias CSS, JS sin cambios. Pendiente prueba visual en Chrome.
