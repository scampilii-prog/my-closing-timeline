V12-177: Eliminada la dependencia de db.active al seleccionar o crear plantillas. Conservados los controles y estilos de las tablas y resúmenes. Pendiente validación de flujo en navegador.
