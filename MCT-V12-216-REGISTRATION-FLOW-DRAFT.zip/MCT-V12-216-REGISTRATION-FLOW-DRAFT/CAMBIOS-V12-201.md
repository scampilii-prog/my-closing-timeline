# V12-201 · Studio

- Renombrada `owner-control-center.html` a `studio.html`.
- Actualizado el enlace compartido del footer a `studio.html`.
- Conservados los estilos y las tarjetas existentes.
- Studio es un panel local de revisión, no un acceso administrativo autenticado.
