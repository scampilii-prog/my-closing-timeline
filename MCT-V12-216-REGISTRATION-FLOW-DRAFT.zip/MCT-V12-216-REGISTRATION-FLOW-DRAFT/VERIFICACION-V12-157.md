V12-157: Encabezado chocolate uniforme, todas las filas crema sin alternancia, seleccionadas doradas de lado a lado. Aplicado a Table 01, Table 02 y resúmenes. No se modificó lógica JavaScript.
