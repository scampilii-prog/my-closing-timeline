V12-155: Contraste de Select, casillas de selección y numeral en Table 01 y 02 y ambos resúmenes. Sin cambios de lógica. Revisar en Chrome.
